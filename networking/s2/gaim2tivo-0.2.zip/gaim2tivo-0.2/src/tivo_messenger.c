/*
 * tivo_messenger.c
 * Version: 0.1
 * Date: June 19, 2002
 * Author: Hermanator
 *
 * Description: A multi-purpose message receiver for TIVO.
 *
 * Copyright (C) 2002 by Hermanator <hermanator12002@yahoo.com>
 *
 * This file is part of the gaim2tivo package.
 *
 * gaim2tivo is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include <getopt.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <errno.h>

#include "msgpainter.h"

#define MAXBUF      1024
#define VERSION     "0.1"

/*
 *  LOCALS
 */

static int sockfd=0;


/*
 *  PROTOS
 */

static void usage(char**);
void getout (int);


static void usage(char** argv) {
  printf("tivo_messenger v%s - Part of gaim2tivo package by hermanator\n"
         "Usage: %s [-p <port>] [-t <time>]\n"
         "\t-h\tThis help screen\n"
         "\t-p\tListen on this port number (default 9999)\n"
         "\t-t\tLength of time to display a message (default 10s)\n"
         , VERSION, argv[0]);
  exit(1);
}

void getout (int sig) {
  printf ("Caught signal, standby while exiting... (signo=%d)\n", sig);
  close(sockfd);
  exit(1);
}

int main (int argc, char** argv)  {
  int portnum=9999; /*default*/
  int disptime=10; /*default*/
  struct sockaddr_in self;
  char buffer[MAXBUF];
  int c=0;

  (void) signal (SIGINT, getout);

  while ((c = getopt(argc, argv, "hpt:")) != -1) {
    switch (c) {
    case 'h':
      usage(argv);
      break;
    case 'p':
      portnum = atoi(optarg);
      break;
    case 't':
      disptime = atoi(optarg);
      break;
    default:
      usage(argv);
      exit(1);
    }
  }

  if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 ) {
    perror("Socket");
    exit(errno);
  }
  
  bzero(&self, sizeof(self));
  self.sin_family = AF_INET;
  self.sin_port = htons(portnum);
  self.sin_addr.s_addr = INADDR_ANY;
  
  if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 ) {
    perror("socket--bind");
    exit(errno);
  }
  
  if ( listen(sockfd, 20) != 0 ) {
    perror("socket--listen");
    exit(errno);
  }

  while (1) {
    int clientfd;
    struct sockaddr_in client_addr;
    int addrlen=sizeof(client_addr);
    
    /* accept a connection */
    clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
    printf("%s:%d connected\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));
    
    /* Print out what we received */
    recv(clientfd, buffer, MAXBUF, 0);
    printf("RECEIVED: %s\n", buffer);
    /* startx, starty, fgcolor, bgcolor, time, text */
    msgprint( 0, 15, 25, 13, disptime, buffer );
    
    /* Close data connection */
    close(clientfd);
  }
  
  close(sockfd);
  return 0;

}/*end main*/
