/* This file is originally from embeem's tivovbi 1.03:
 * http://tivo.samba.org/download/mbm 
 *  
 * It has been updated since then to allow the OSD to display 
 * over the Tivo menus
 *
 * This file is part of the gaim2tivo package.
 *
 * gaim2tivo is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/fcntl.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "osd.h"
#include "font.h"

int mpegfd=0;

#define	XSIZE		720	// Pixels available in X direction  684/720
#define YSIZE		480	// Pixels available in Y direction
#define OFFSET_F	8+512	// Fixed offset (Header + Color Palette)
#define	OFFSET_X	80	// Text offset in pixels from left (X)
#define	OFFSET_Y	6	// Text offset in pixels from top  (Y)
 
unsigned char *tivbuffer = 0;

static struct osd cur_osd = {0,0,0};

void DrawString(int cur_x, int cur_y, char *string, int fg, int bg)
{
  int x, ptr;
  char *bits;

  if (!tivbuffer) return;
  while (string[0] != 0) {
    if (string[0] == '\n') {
      cur_x = 0;
      cur_y++;
    } else {

      bits = (char *)&textfont[string[0] * (TEXTFONT_X/8) * TEXTFONT_Y];

      if (!tivbuffer) return;
      if ((cur_x) > MAX_CHAR_X) (cur_x) = 0, (cur_y)++;
      if ((cur_y) > MAX_CHAR_Y) (cur_y) = 0;

      ptr = OFFSET_F+					\
            ((cur_x)*(TEXTFONT_X+1))+OFFSET_X+		\
            ((cur_y)*TEXTFONT_Y+OFFSET_Y)*XSIZE;

      if (!cur_osd.start) cur_osd.start=ptr;	// First write to buffer

      if (ptr < cur_osd.start) {
        cur_osd.len += cur_osd.start-ptr;	// Increase length
        cur_osd.start=ptr;			// Set start to start of char
      }

      for (x = 0; x < TEXTFONT_Y; x++) {
        tivbuffer[(ptr)++] = ((*bits   & 128)?fg:bg);	// Inner-loop for
        tivbuffer[(ptr)++] = ((*bits   &  64)?fg:bg);	//  copying bits from
        tivbuffer[(ptr)++] = ((*bits   &  32)?fg:bg);	//  font array to
        tivbuffer[(ptr)++] = ((*bits   &  16)?fg:bg);	//  screen array
        tivbuffer[(ptr)++] = ((*bits   &   8)?fg:bg);	// This has been
        tivbuffer[(ptr)++] = ((*bits   &   4)?fg:bg);	//  unrolled for 
        tivbuffer[(ptr)++] = ((*bits   &   2)?fg:bg);	//  optimization
        tivbuffer[(ptr)++] = ((*bits++ &   1)?fg:bg);	// If TEXTFONT_X is
        tivbuffer[(ptr)++] = ((*bits   & 128)?fg:bg);	//  changed from (16),
        tivbuffer[(ptr)++] = ((*bits   &  64)?fg:bg);	//  this will need to
        tivbuffer[(ptr)++] = ((*bits   &  32)?fg:bg);	//  be recoded
        tivbuffer[(ptr)++] = ((*bits   &  16)?fg:bg);
        tivbuffer[(ptr)++] = ((*bits   &   8)?fg:bg);
        tivbuffer[(ptr)++] = ((*bits   &   4)?fg:bg);
        tivbuffer[(ptr)++] = ((*bits   &   2)?fg:bg);
        tivbuffer[(ptr)++] = ((*bits++ &   1)?fg:bg);
        tivbuffer[(ptr)]   = bg;

        ptr += XSIZE - TEXTFONT_X;	// Next row (Y), start of current char
      }

      cur_x++;

      if (ptr > cur_osd.start+cur_osd.len)	// Use end of char from length
        cur_osd.len = ptr - cur_osd.start;
    }
    string++;
  }
}

void SetupTextOSD(void)
{
  mpegfd = open("/dev/mpeg0v", O_RDWR);
  tivbuffer = (char *) calloc(1,OFFSET_F + XSIZE * YSIZE);
}

void FreeTextOSD(void)
{
  if (tivbuffer) free(tivbuffer);
  tivbuffer=0;
  close(mpegfd);
}

void ClearOSD(int from_start)
{
  if (!tivbuffer) return;
  if (from_start) {
    cur_osd.start = OFFSET_F;
    cur_osd.len = 0;
  }
  memset(&tivbuffer[cur_osd.start], 0, cur_osd.len);
}

void DrawOSD(void)
{
  if (!tivbuffer) return;
  if (cur_osd.start) {
    cur_osd.start = (cur_osd.start &~7);	// Force start on 8 byte bdy
    cur_osd.len   = (cur_osd.len   &~7)+8;	// Force len   on 8 byte bdy
    cur_osd.buf   = &tivbuffer[cur_osd.start];	// Set buffer based on start

    ioctl(mpegfd, 0x403, &cur_osd);
  }
}
