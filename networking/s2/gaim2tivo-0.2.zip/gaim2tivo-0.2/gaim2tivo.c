/*
 * gaim2tivo.c
 * Version: 0.2
 * Date: June 17, 2002
 * Author: Hermanator
 * 
 * Description: Part of the gaim2tivo package, this is a plugin for gaim to 
 * forward certain gaim events to a hacked tivo, running tivo_messenger (part 
 * of this package). Buddy arrived, departed and IM received events will be 
 * printed to the TV screen.
 *
 * To compile, move this file to plugins dir of your gaim source distribution
 * and type "make gaim2tivo.so".  For more info refer to the README in that
 * directory. You will be able to obtain Gaim at http://gaim.sourceforge.net
 *
 * Copyright (C) 2002 by Hermanator <hermanator12002@yahoo.com>
 *
 * This file is part of the gaim2tivo package.
 *
 * gaim2tivo is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#define GAIM_PLUGINS
#include "gaim.h"

#include <gtk/gtk.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#ifndef _WIN32
#include <unistd.h>
#include <sys/socket.h>
#include <resolv.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <netdb.h>
#else
#include <winsock.h>
#include "win32dep.h"
#endif
#include <errno.h>
#include <sys/stat.h>

#include "pixmaps/cancel.xpm"

/*
 * DEFINES & MACROS
 */
#define GAIM2TIVO_VERSION "0.2"
#define DEFAULT_PORTNUM "9999"

#define MAXTIVOMSGLEN 34
#define MAXMSGLEN 7987
#define MAXSENDBUF 1024
#define MAXSTRLEN 64                /* Max string length for rc option or value */
#define MAXVALUES 10                /* Max values for any rc option */
#define HOSTADDR 0
#define HOSTPORT 1

#ifdef _WIN32
#define DLLEXPORT __declspec( dllexport )
#else
#define DLLEXPORT
#endif


/*
 *  PROTOS
 */

static GtkWidget *tivo_error_dialog(char*, char*);
static void tivosend( char* );
static void save_tivo_prefs();
static void load_tivo_prefs();


/*
 * LOCALS
 */

static char plugin_name[32];

/* Gmodule handle */
static void *handle;

/* Widget handles */
static GtkWidget *tivowin = NULL;
static GtkWidget *hostname_entry = NULL;
static GtkWidget *hostport_entry = NULL;
static GtkWidget *dialogwin = NULL;

/* IM Conversation  */
static char imbuf[MAXMSGLEN];

/* Network */
static char hostname[128]="";
static char hostport[10]=DEFAULT_PORTNUM;
static struct hostent* hent=NULL;
static char buffer[MAXSENDBUF];

/* Event Handlers */

static void tivo_buddy_arrived( struct gaim_connection *gc, void *who ) {
  sprintf( imbuf, "GAIM: %s just arrived!\n", (char*)who );
  tivosend( imbuf );
  debug_printf("%s\n", imbuf);
}

static void tivo_buddy_departed( struct gaim_connection *gc, void *who ) {
  sprintf( imbuf, "GAIM: %s just departed!\n", (char*)who );
  tivosend( imbuf );
  debug_printf("%s\n", imbuf);
}

static void tivo_im_recv( struct gaim_connection *gc, 
                   void **who, 
                   void **message,
                   void *data ) {
  char* tmp;

  tmp = strip_html(*message);
  sprintf( imbuf, "%s: %s", (char*)*who, tmp );
  free(tmp); /* aaaahhh I don't like functions that require you to free mem */
  tivosend( imbuf );
  debug_printf("%s\n", imbuf);
}


/* Required GAIM plugin callbacks */

DLLEXPORT char *gaim_plugin_init(GModule *hndl) {
  handle = hndl;

  /* Register event handlers */
  gaim_signal_connect(handle, event_buddy_signon, tivo_buddy_arrived, NULL);
  gaim_signal_connect(handle, event_buddy_signoff, tivo_buddy_departed, NULL);
  gaim_signal_connect(handle, event_im_recv, tivo_im_recv, NULL);
  load_tivo_prefs();
  
  return NULL;
}

DLLEXPORT char *name() {
  sprintf(plugin_name, "gaim2tivo v%s", GAIM2TIVO_VERSION);
  return plugin_name;
}

DLLEXPORT char *description() {
  return "Enable's you to receive notification of Gaim events,"
    " while whatching TV with your Tivo";
}


/* Configuration Window objects and callbacks */

static void destroy_tivowin() {
  gtk_widget_destroy(tivowin);
  tivowin = NULL;
}

static void entry_callback( GtkEntry *entry, int entrynum ) {
  const gchar *entry_text=0;

  if (entrynum == HOSTADDR)
    strcpy( hostname, entry_text = gtk_entry_get_text(entry) );
  else if (entrynum == HOSTPORT)
    strcpy( hostport, entry_text = gtk_entry_get_text(entry) );
}

DLLEXPORT char *gaim_plugin_config() {
  GtkWidget *frame;
  GtkWidget *vbox;
  GtkWidget *vbox_main;
  GtkWidget *hbox;
  GtkWidget *label;
  GtkWidget *button;
  
  if (tivowin) {
    gtk_widget_show(tivowin);
    return NULL;
  }
  
  /* Create dialog window */
  tivowin = gtk_window_new(GTK_WINDOW_POPUP);
  sprintf(buffer, "Gaim2tivo v%s", GAIM2TIVO_VERSION);
  gtk_window_set_title(GTK_WINDOW(tivowin), buffer);
  gtk_window_set_default_size(GTK_WINDOW(tivowin), 400, 200);
  gtk_signal_connect(GTK_OBJECT(tivowin), "destroy",
                     GTK_SIGNAL_FUNC(destroy_tivowin), NULL);

  /* Vbox to which all is added */
  vbox_main = gtk_vbox_new (FALSE, 0);
  gtk_container_add (GTK_CONTAINER (tivowin), vbox_main);
  gtk_widget_show (vbox_main);

  /* Create frame for window */
  frame = gtk_frame_new(_("Tivo Options"));
  gtk_container_set_border_width(GTK_CONTAINER(frame), 5);
  gtk_container_add(GTK_CONTAINER(vbox_main), frame);
  gtk_widget_show(frame);
  
  /* Vbox to which all hboxes are attached */
  vbox = gtk_vbox_new (FALSE, 0);
  gtk_container_add (GTK_CONTAINER (frame), vbox);
  gtk_widget_show (vbox);

  /* 1st hbox - Host/IP addr */
  hbox = gtk_hbox_new(FALSE, 5);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 5);

  label = gtk_label_new("Tivo Host/IP address:");
  gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);

  hostname_entry = gtk_entry_new();
  gtk_entry_set_max_length (GTK_ENTRY (hostname_entry), 50);
  gtk_signal_connect (GTK_OBJECT (hostname_entry), "changed",
                      GTK_SIGNAL_FUNC (entry_callback),
                      (void*)HOSTADDR);

  gtk_box_pack_start (GTK_BOX (hbox), hostname_entry, FALSE, FALSE, 0);
  gtk_widget_show (hostname_entry);

  /* Port Number */
  hbox = gtk_hbox_new(FALSE, 5);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 5);

  label = gtk_label_new("Port number (default 9999):");
  gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);

  hostport_entry = gtk_entry_new();
  gtk_entry_set_max_length (GTK_ENTRY (hostport_entry), 5);
  gtk_signal_connect (GTK_OBJECT (hostport_entry), "changed",
                      GTK_SIGNAL_FUNC (entry_callback),
                      (void*)HOSTPORT);
  
  gtk_box_pack_start (GTK_BOX (hbox), hostport_entry, FALSE, FALSE, 0);
  gtk_widget_show (hostport_entry);

  /* Close & Save Button */
  button = picture_button(tivowin, _("Close"), cancel_xpm);
  gtk_box_pack_end(GTK_BOX(vbox_main), button, FALSE, FALSE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(save_tivo_prefs), NULL);
  gtk_widget_show (button);

  /* Load values to widgets.. defaults used if resource file was not read */
  gtk_entry_set_text(GTK_ENTRY (hostname_entry), hostname);
  gtk_entry_set_text(GTK_ENTRY (hostport_entry), hostport);

  /* Show all tivowin's widgets */
  gtk_widget_show_all(tivowin);

  return NULL;
}

/* Dialog Window */

static void destroy_tivo_dialog() {
  gtk_widget_destroy(dialogwin);
  dialogwin = NULL;
}

static GtkWidget *tivo_error_dialog(char *message, char *title) {
  GtkWidget *d;
  GtkWidget *label;
  GtkWidget *close;
  
  d = gtk_dialog_new();
  gtk_window_set_policy(GTK_WINDOW(d), FALSE, FALSE, TRUE);
  gtk_widget_realize(d);
  label = gtk_label_new(message);
  gtk_label_set_line_wrap(GTK_LABEL(label), TRUE);
  gtk_widget_show(label);
  gtk_box_pack_start(GTK_BOX(GTK_DIALOG(d)->vbox), label, FALSE, FALSE, 5);
  
  close = picture_button(d, _("Close"), cancel_xpm);
  
  gtk_box_pack_start(GTK_BOX(GTK_DIALOG(d)->action_area), close, FALSE, FALSE, 5);
  
  gtk_container_set_border_width(GTK_CONTAINER(d), 5);
  gtk_window_set_title(GTK_WINDOW(d), title);
  gtk_signal_connect(GTK_OBJECT(close), "clicked", GTK_SIGNAL_FUNC(destroy_tivo_dialog), d);
  
  gtk_widget_show(d);
  gtk_widget_grab_focus(close);
  return d;
}


/* Tivo Connection */

static void tivosend(char* msg) {
  int sockfd;
  struct sockaddr_in dest;
  char errmsg[500];

  if( dialogwin )
    return;
  
  /* Host lookup */
  if( strlen(hostname) <= 0 ) {
    dialogwin=tivo_error_dialog("You must enter your Tivo's hostname or IP in the "
                                "plugin configuration window", "GAIM2TIVO Plugin");
    return;
  }

  hent = gethostbyname( hostname );
  if( hent == NULL ) {
#ifndef _WIN32
    sprintf( errmsg, "Error doing host lookup for %s: %s", hostname, hstrerror(h_errno));
#else
    sprintf( errmsg, "Error doing host lookup for %s: Error #: %d", 
	     hostname, WSAGetLastError());    
#endif
    dialogwin=tivo_error_dialog( errmsg, "GAIM2TIVO Plugin" );
    return;
  }

  if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 ) {
    sprintf( errmsg, "Error creating socket: %s", strerror(errno) );
    dialogwin=tivo_error_dialog( errmsg, "GAIM2TIVO Plugin" );
    return;
  }

  bzero(&dest, sizeof(dest));
  dest.sin_family = AF_INET;
  dest.sin_port = htons(atoi(hostport));
  dest.sin_addr = *(struct in_addr*)hent->h_addr;

  if ( connect(sockfd, (struct sockaddr*)&dest, sizeof(dest)) != 0 ) {
    sprintf( errmsg, "Error connecting to Tivo: %s\n\nMake sure tivo_messenger is running on"
                     " your Tivo, and make sure that \"%s\" is the correct host address for"
                     " your Tivo.", strerror(errno), hostname);
    dialogwin=tivo_error_dialog(errmsg, "GAIM2TIVO Plugin");
    return;
  }

  /* What are we sending? */
  bzero(buffer, MAXSENDBUF);
  if(strlen(msg) > MAXTIVOMSGLEN) {
    strncpy(buffer, msg, MAXTIVOMSGLEN-3);
    strcat(buffer, " ..");
  }
  else
    strcpy(buffer, msg);

  send(sockfd, buffer, sizeof(buffer), 0);
#ifdef _WIN32
  closesocket(sockfd);
#else
  close(sockfd);
#endif
}


/* GAIM2TIVO resource file routines */


static void tivorc_write(FILE *f) {
  fprintf(f, "hostinfo\n{\n");
  fprintf(f, "%s\n", hostname);
  fprintf(f, "%s\n", hostport);
  fprintf(f, "}\n");
}

static void save_tivo_prefs() {
  FILE *f;
  char buf[1024];
  
  if (g_get_home_dir())
    g_snprintf(buf, sizeof(buf), "%s" G_DIR_SEPARATOR_S ".gaim2tivorc", g_get_home_dir());
  else {
    gtk_widget_destroy(tivowin);
    return; /* Dialog needed here */
  }
  if ((f = fopen(buf, "w"))) {
    fprintf(f, "# .gaim2tivorc v%s\n", GAIM2TIVO_VERSION);
    tivorc_write(f);
    fclose(f);
    chmod(buf, S_IRUSR | S_IWUSR);
  }
  gtk_widget_destroy(tivowin);
  tivowin = NULL;
}


static void gaim2tivorc_read_hostinfo(FILE *f, char* hname, char* hport) {
  char buf[1024];
  
  buf[0] = 0;
  debug_printf("Entered gaim2tivorc_read_hostinfo.\n");

  if (!fgets(buf, sizeof(buf), f)) return;
  if (buf[0] == '}') return;
  strncpy(hname, buf, strlen(buf)-1);
  

  if (!fgets(buf, sizeof(buf), f)) return;
  if (buf[0] == '}') return;
  strncpy(hport, buf, strlen(buf)-1);
}


static void load_tivo_prefs() {
  FILE *f;
  char buf[1024]="";
  char ver[5];

  debug_printf("Loading Tivo Prefs\n");

  if (g_get_home_dir()) {
    g_snprintf(buf, sizeof(buf), "%s" G_DIR_SEPARATOR_S ".gaim2tivorc", g_get_home_dir());
    
    if ((f = fopen(buf, "r"))) {
      fgets(buf, sizeof(buf), f);
      sscanf(buf, "# .gaim2tivorc v%s", ver);
      if(strcmp(ver, GAIM2TIVO_VERSION) <= 0)
        debug_printf("Version for gaim2tivorc: %s\n", ver);
      else
        debug_printf("Version for gaim2tivorc is newer than current gaim2tivo plugin.\n");
      while (!feof(f)) {
        fgets(buf, sizeof(buf), f);
        if (strcmp(buf, "hostinfo\n")==0) {
          fgets(buf, sizeof(buf), f); /* swallow { */
          gaim2tivorc_read_hostinfo(f, hostname, hostport);
        }
      }
      fclose(f);
    }/*end if*/
  }
}
