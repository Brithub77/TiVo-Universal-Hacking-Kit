/*
	paltest - a simple test for libosd, displays the color palette.

    Copyright (C) 2002  J. Bordens

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*/

#include <stdio.h>
#include "libosd.h"


void paltest(int colors, color_table palette) {

     //Declare some variables
     osd* osd_ptr;
     int x,y,c,d, pixels, sqrt;

     //Set up some variables.
     //colors = number of pixels wide for a color square
     //sqrt   = the square root of the number of colors
     if (colors == 4)   { pixels = 200; sqrt = 2;  }
     if (colors == 16)  { pixels = 100; sqrt = 4;  }
     if (colors == 256) { pixels = 25;  sqrt = 16; }

     //Initialize the OSD object
     osd_ptr = create_osd(40, 200, 400, 400, colors);

     //Make sure the OSD object was initalized.
     if (!osd_ptr) {
        fprintf(stderr, "Unable to allocate OSD object.\n");
        exit(1);
     }

     //Set the color table for the OSD
     set_color_table(osd_ptr, palette);

     //Draw the image to memory using the 'draw_pixel' function
     for (x=0; x<400; x++)
	for(y=0; y<400; y++) {
	   c=(x / pixels);
	   d=(y / pixels);
	   draw_pixel(osd_ptr, x, y, c + (sqrt * d));
        }

     //Send the osd memory out to the OSD.  This actually displays the image
     draw_osd(osd_ptr);

     //Finish with the OSD, free the memory, and close the connection
     destroy_osd(osd_ptr);

}

void paltest_dc() {

     //Declare some variables
     osd* osd_ptr;
     int x,y,c,d;

     //Set up some variables.
     //colors = number of pixels wide for a color square
     //sqrt   = the square root of the number of colors

     //Initialize the OSD object
     osd_ptr = create_osd(112, 257, 384, 256, 0);

     //Make sure the OSD object was initalized.
     if (!osd_ptr) {
        fprintf(stderr, "Unable to allocate OSD object.\n");
        exit(1);
     }

     //Draw the image to memory using the 'draw_pixel' function
     for (x=0; x<256; x++) {
	int cy,cu,cv,dc;
	cy=128;
	for (y=0; y<256; y+=1) {
	   cu=y;
	   cv=x;
	   dc = build_direct_color(cy,cu,cv);
	   draw_pixel(osd_ptr, x, y, dc);
        }
     }

     //Send the osd memory out to the OSD.  This actually displays the image
     draw_osd(osd_ptr);

     //Finish with the OSD, free the memory, and close the connection
     destroy_osd(osd_ptr);

}


main (int argc, char** argv) {

    printf("%s\n", libosd_version());
    if (argc == 2) {
      if (atoi(argv[1]) == 256) {
	paltest(256, CT_OSD_LIVETV_256);
	return;
      } else if (atoi(argv[1]) == 16) {
	paltest(16,  CT_PRIMARY_16);
	return;
      } else if (atoi(argv[1]) == 4) {
	paltest(4,   CT_PRIMARY_16);
	return;
      } else if (strcmp(argv[1], "direct") == 0) {
	paltest_dc();
	return;
      }
    }
    printf("usage: %s {4, 16, 256}\n", argv[0]);
}

