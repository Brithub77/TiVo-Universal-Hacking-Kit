/*
	libosd - a simple on-screen-display library for the tivo

    Copyright (C) 2002  J. Bordens

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*/

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "libosd.h"

/* Misc functions */

char* libosd_version() {
     return "1.0b - libosd (c) 2002 Jake B.\n";
}

/* OSD functions */
osd*  create_osd (int top, int left, int height, int width, int num_colors) {
    int y;
    osd* osd_ptr;

    //check to make sure the number of colors is valid first.
    //this way we don't bother allocating anything if the color choice is bad
    if(!(num_colors == 0 || num_colors == 4 ||num_colors==16 || num_colors==256))
	return NULL;

    //height must be a multiple of 2, width's multiple is variable
    height= height & ~1;
    if (num_colors == 0 || num_colors == 256)
        width = width & ~3;
    else
	width = width & (~15 >> (num_colors == 16));

    //check to make sure the bitmap size doesn't exceed CS22's capability
    if (top+height > 576) return NULL;
    if (left+width > 720) return NULL;

    //allocate memory for the osd object
    osd_ptr = (osd *) calloc(1, sizeof(osd));

    //make sure memory was allocated
    if (!osd_ptr) return NULL;

    //open the mpeg device
    osd_ptr->mpeg0v = open("/dev/mpeg0v", O_RDWR);

    //make sure mpeg device was opened
    if (osd_ptr->mpeg0v < 0) {
	free(osd_ptr);
	return NULL;
    }

    //the header and the palette
    osd_ptr->buffer_size = 8 + (num_colors * 2);

    if (num_colors==0)
        osd_ptr->buffer_size += (height * width) * 2; //YUV 4:2:2
    else
	if (num_colors==4)
	    osd_ptr->buffer_size += (height * width) / 4;
        else if (num_colors==16)
	    osd_ptr->buffer_size += (height * width) / 2;
	else
            osd_ptr->buffer_size += (height * width);

    //allocate the buffer, and make sure it was allocated alright
    osd_ptr->buffer    = (char *)calloc(1, osd_ptr->buffer_size);
    osd_ptr->scanlines = (char **)calloc(sizeof(char *), height);

    if (!osd_ptr->buffer || !osd_ptr->scanlines) {
	close(osd_ptr->mpeg0v);
	free(osd_ptr);
	return NULL;
    }

    //set the member items for quick access to the osd parameters
    osd_ptr->height = height;
    osd_ptr->width  = width;
    osd_ptr->top    = top;
    osd_ptr->left   = left;
    osd_ptr->color_table_size = num_colors;
    osd_ptr->num_pixels = width * height;

    //build the scanlines array
    for (y=0; y<height; y++) {
        if (num_colors == 0 || num_colors == 256)
	   osd_ptr->scanlines[y] = &osd_ptr->buffer[8+(2*num_colors)+(y*width)];
	else {
	   int n = 4 - (2*(num_colors == 16));
	   osd_ptr->scanlines[y] = &osd_ptr->buffer[8+(2*num_colors)+(y*(width/n))];
	}
    }

    //a whole lot of shifting to set up the cs22 header
    if (num_colors == 0) {
	//this is direct color mode color mode
	int *header = (int *)osd_ptr->buffer;
        header[0] = ((0 & 0x01) << 31) |         //8 bits ea chroma/luma
                    (((width / 4) & 0xFF) << 23) |
                    ((0 & 0x0F) << 19) |         //shade
                    ((1 & 0x01) << 18) |         //hi color
                    (((top/2) & 0x1FF) << 9) |
                    ((left/2) & 0x1FF);
        header[1] = ((0 & 0xFFFF) << 16) |      //link
                    ((1 & 0x01) << 15) |        //direct color
                    (((height / 2) & 0x1FF) << 6) |
                    ((0 & 0x01) << 5) |         //4:2:2 mode
                    ((0 & 0x01) << 1) |         //blend
                    (0 & 0x01); //force trans
    } else {
	//non-direct color mode
	int *header = (int *)osd_ptr->buffer;
        header[0] = ((1 & 0x01) << 31) |                   //color table update
                    ((0 & 0x0F) << 19) |                   //shade
                    (( (num_colors==256) & 0x01) << 18) |  //hi color
                    (((top/2) & 0x1FF) << 9) |
                    ((left/2) & 0x1FF);

	if (num_colors == 256) {
            header[0] = header[0] | (((width / 4) & 0xFF) << 23);
 	} else {
	    int width_multiplier = 16 - ((num_colors == 16) * 8);
            header[0] = header[0] | (((width / width_multiplier) & 0x7F) << 24);
	}
        header[1] = ((0 & 0xFFFF) << 16) |                //link
                    (( (num_colors==4) & 0x01) << 15) |   //color res
                    (((height / 2) & 0x1FF) << 6) |
                    ((0 & 0x01) << 5) |                   //pixel res
                    ((0 & 0x01) << 1) |                   //blend
                    (0 & 0x01); //force trans
    }
    return osd_ptr;
}

void  set_color_table (osd* osd_ptr, color_table ctable) {
    memcpy(&(osd_ptr->buffer[8]), ctable, osd_ptr->color_table_size * 2);
}

void draw_osd(osd* osd_ptr) {
    struct {
	int start;
        int len;
	char *buf;
    } osd_ioctl;

    osd_ioctl.start= 0;
    osd_ioctl.len  = osd_ptr->buffer_size & (~7);
    osd_ioctl.buf  = osd_ptr->buffer;
    ioctl(osd_ptr->mpeg0v, 0x403, &osd_ioctl);
}

void destroy_osd(osd* osd_ptr) {
    close(osd_ptr->mpeg0v);
    free(osd_ptr->scanlines);
    free(osd_ptr->buffer);
    free(osd_ptr);
}

/* Color functions */
int build_direct_color  (int y, int u, int v) {
   char ret[4];
   ret[0]=0;
   ret[1]=y&0xFF;
   ret[2]=u&0xFF;
   ret[3]=v&0xFF;
   return *((int *)ret);
}

short build_color_table_entry (int y, int u, int v, int a) {
   return ((y & 0xFC) << 8) | ((u & 0xF0) << 2) | ((v >> 2) & 0x3C) | (a & 0x03);
}

/* Primitivies */
void draw_pixel(osd* osd_ptr, int x, int y, int color_index) {
    char *pixel;

    if (x<0 || y<0) return;
    if (x>=osd_ptr->width || y >= osd_ptr->height) return;

    if (osd_ptr->color_table_size == 256) {
	*(osd_ptr->scanlines[y]+x)=color_index;
    } else if (osd_ptr->color_table_size == 4) {
	pixel = osd_ptr->scanlines[y]+(x/4);
	*pixel = *pixel & ~(0x3 << (6-(2*(x%4))));
	*pixel = *pixel | (color_index << (6-(2*(x%4))));
    } else if (osd_ptr->color_table_size == 16) {
	pixel = osd_ptr->scanlines[y]+(x/2);
	*pixel= *pixel & ~(0xF << (4-(4*(x%2))));
	*pixel= *pixel | (color_index << (4-(4*(x%2))));
    } else if (osd_ptr->color_table_size == 0) {
	char* luma, *chroma;
	char* cndx=(char *)(&color_index);

	luma   = osd_ptr->scanlines[y]+x;
	chroma = osd_ptr->scanlines[y]+(x+osd_ptr->num_pixels);

	*luma   = cndx[1];
	*chroma = ((x%2)?(cndx[3]):(cndx[2]));
    }
}

