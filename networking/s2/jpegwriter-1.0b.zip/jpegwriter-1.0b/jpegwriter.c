/*
	JpegWriter - display jpegs on your tivo.

    Copyright (C) 2002  J. Bordens

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*/

#include <stdio.h>
#include "jpeglib.h"
#include <setjmp.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <libosd.h>

extern JSAMPLE * image_buffer;	/* Points to large array of R,G,B-order data */
extern int image_height;	/* Number of rows in image */
extern int image_width;		/* Number of columns in image */

#define MAX_WIDTH 700
#define MAX_HEIGHT 460

struct osd {
        unsigned start;
        unsigned len;
        void *buf;
};

int main(int argc, char **argv) {
  struct jpeg_decompress_struct cinfo;
  struct jpeg_error_mgr jerr;

  osd* osd_ptr;

  FILE * infile;		/* source file */
  JSAMPARRAY buffer;		/* Output row buffer */
  int row_stride, x,scanline;	/* physical row width in output buffer */
  int start_row, start_col;
  short colors[256];
  int num_colors = 256;
  char verbose = 0;

  // Display the banner.
  printf("jpegwriter - v1.0b by Jake B.\t\t(c) 2002 Jake B.\n");
  printf("--> TiVo and the TiVo logo are trademarks of TiVo Inc.\n");
  printf("--> Thanks (yet again) to [mbm] for all his help.\n");
  printf("--> libosd: %s\n", libosd_version());

  // Check for the proper number of arguments (1)
  if (argc < 2 || argc > 3) {
     fprintf(stderr, "usage: %s [-dc] <filename.jpg>\n\n", argv[0]);
     exit(1);
  }

  if ((argc == 3) && (strcmp(argv[1], "-dc") == 0)) { num_colors = 0; }
  if ((argc == 3) && (strcmp(argv[1], "-dcv") == 0)) {
	num_colors = 0;
	verbose=1;
  }

  if ((argc == 3) && (strcmp(argv[1], "-v") == 0)) { verbose = 1; }

  if ((infile = fopen(argv[1 + (argc == 3)], "rb")) == NULL) {
    fprintf(stderr, "Error opening file: %s\n", argv[1]);
    return 0;
  }

  // Set up the error handling routine
  if (verbose) fprintf(stderr, "Setting up JPEG Error handler...\n");
  cinfo.err = jpeg_std_error(&jerr);
  jpeg_create_decompress(&cinfo);

  // Get the jpeg data from the file
  if (verbose) fprintf(stderr, "Setting up JPEG library to read from file...\n");
  jpeg_stdio_src(&cinfo, infile);

  // Get the header iformation
  if (verbose) fprintf(stderr, "Reading JPEG header...\n");
  (void) jpeg_read_header(&cinfo, TRUE);

  // Modify the header information as necessary for on screen display
  if (verbose) fprintf(stderr, "Setting up JPEG decoding parameters for %d colors...\n", num_colors);
  cinfo.out_color_space = JCS_YCbCr;
  cinfo.scale_num=1;

  if (num_colors == 0) {
     cinfo.quantize_colors = FALSE;
  } else {
     cinfo.quantize_colors = TRUE;
     cinfo.desired_number_of_colors = 256;
     cinfo.two_pass_quantize = TRUE;
     cinfo.dither_mode = JDITHER_FS;
  }

  // Determine scaling for large images
  for (x=1; x<=8; x=x*2) {
     if ((cinfo.image_width/x) <= MAX_WIDTH &&
         (cinfo.image_height/x) <= MAX_HEIGHT) break;
  }

  // Determine if the image is still to large
  // (case where 1/8 scaling is too little)
  if ((cinfo.image_width/x) > MAX_WIDTH &&
      (cinfo.image_height/x) > MAX_HEIGHT) {
	printf("Image is too big!\n");
	exit(1);
  }

  // Set the scaling
  if (verbose) fprintf(stderr, "Scaling set to 1/%d.\n", x);
  cinfo.scale_denom=x;

  // Start decompressing!
  if (verbose) fprintf(stderr, "Start JPEG decompression...\n");
  (void) jpeg_start_decompress(&cinfo);

  // Create the OSD
  if (verbose) fprintf(stderr, "Creating OSD object...\n");
  start_row = (480 / 2) - (cinfo.output_height / 2);
  start_col = (670 / 2) - (cinfo.output_width / 2) + 50;
  osd_ptr = create_osd(start_row, start_col, cinfo.output_height, cinfo.output_width, num_colors);

  // how many samples per row?  Should be (1 || 3) bytes * row width
  row_stride = cinfo.output_width * cinfo.output_components;

  if (num_colors == 256) {
     //process the color palette
     if (verbose) fprintf(stderr, "Processing color palette...\n");
     for (x=0; x<256; x++) {
        int yval, uval, vval;
        if (x < (cinfo.actual_number_of_colors-1)) {
           colors[x] = build_color_table_entry(cinfo.colormap[0][x],
					       cinfo.colormap[1][x],
					       cinfo.colormap[2][x], 0);
        } else {
           colors[x]=0;
        }
     }
     set_color_table(osd_ptr, colors);
  }

  // Build the array using the jpeg library's memory allocator
  if (verbose) fprintf(stderr, "Allocating JPEG scanline buffer...\n");
  buffer = (*cinfo.mem->alloc_sarray) ((j_common_ptr) &cinfo, JPOOL_IMAGE, row_stride, 1);

  //process all the scanlines and write them to the osd_bitmap buffer
  if (verbose) fprintf(stderr, "Processing scanlines...\n");

  scanline=0;
  while (cinfo.output_scanline < cinfo.output_height) {
    (void) jpeg_read_scanlines(&cinfo, buffer, 1);

    /* Assume put_scanline_someplace wants a pointer and sample count. */
    for (x=0; x<row_stride; x+=cinfo.output_components) {
	if (num_colors == 0) {
	   int y,u,v,dcolor;
	   y=buffer[0][x];
	   u=buffer[0][x+1];
	   v=buffer[0][x+2];
	   dcolor = build_direct_color(y,u,v);
	   draw_pixel(osd_ptr, x/3, scanline, dcolor);
	} else {
	   draw_pixel(osd_ptr, x, scanline, buffer[0][x]);
        }
    }
    scanline++;
  }

  if (verbose) fprintf(stderr, "Drawing the OSD...\n");
  draw_osd(osd_ptr);

  //finish up from the jpeg decompression
  if (verbose) fprintf(stderr, "Finishing up JPEG decompression...\n");
  (void) jpeg_finish_decompress(&cinfo);

  //free up the resources used here.
  if (verbose) fprintf(stderr, "Freeing up the resources...\n");
  jpeg_destroy_decompress(&cinfo);
  fclose(infile);
  destroy_osd(osd_ptr);

  //return
  return 0;
}
