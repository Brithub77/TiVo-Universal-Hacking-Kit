#!/bin/bash

export PATH=/bin:/usr/bin:/var/bin:/hack/bin:/var/hack/bin:/tvbin:/tivo-bin:.

while true
    do
        elseed -e $*
        sleep 5
    done
