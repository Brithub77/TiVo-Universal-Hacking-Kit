/* 
 * Copyright (C) 2002 by Greg Gardner
 * 
 * This file is part of elseed, a caller-id program for your TiVo.
 * 
 * elseed is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * elseed is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA
 *
 * $Id: elseed.c,v 1.10 2003/01/24 20:05:32 greg Exp $
 */

#include "elseed.h"
#include "osd.h"

#define VERSION "0.6.0"

/* loop til we die */
int STOP = FALSE; 

/* incoming caller id flag */
int INC_CID = FALSE;
int saw_name = FALSE;
int saw_nmbr = FALSE;

/* the caller id structure */
caller_id cid;

int osd_x=X_POS_DEFAULT, osd_y=Y_POS_DEFAULT;
int fg_color=FG_COLOR_DEFAULT, bg_color=BG_COLOR_DEFAULT;
int cid_onscreen=CID_ONSCREEN_DEFAULT;
int debug = 0;
int modem_shared = 1;
int exit_after_display = 0;
int vtime = VTIME_DEFAULT;
int yac_conn_timeout = YAC_CONN_TIMEOUT_DEFAULT;
char modem_device[255];
char modem_init[255];
char log_file[255];
char conf_file[255];
yac_listeners YacListeners[MAX_LST];
int nYacListeners = 0;
name_struct name_list[MAX_LST];
int num_name_list = 0;
int skip_name = 0;

/* the main shiznit */
int main (int argc, char *argv[])  {
    int fd, result, c;
    char inbuff[SZ_BUFF], outbuff[SZ_BUFF];
    char *sloc, *eloc;
    struct termios oldtio, newtio;
    struct stat statbuf;

    (void) signal (SIGINT, getout);	/* exit cleanly on ctrl-c */ 

    SetupTextOSD();

    strncpy(modem_device, MODEMDEVICE_DEFAULT, 255);
    strncpy(modem_init, MODEMINIT_DEFAULT, 252);
    strcat(modem_init, "\r\n");
    strncpy(log_file, LOG_FILE_DEFAULT, 255);
    strncpy(conf_file, CONF_FILE_DEFAULT, 255);

    while ((c = getopt(argc, argv, "x:y:b:f:i:d:l:t:v:c:z:DMhen")) != -1) {
        switch (c) {
            case 'x':
                osd_x = atoi(optarg);
                break;
            case 'y':
                osd_y = atoi(optarg);
                break;
            case 'f':
                fg_color = atoi(optarg);
                break;
            case 'b':
                bg_color = atoi(optarg);
                break;
            case 't':
                cid_onscreen = atoi(optarg);
                break;
            case 'd':
                strncpy(modem_device, optarg, 255);
                break;
            case 'i':
                strncpy(modem_init, optarg, 252);
                strcat(modem_init, "\r\n");
                break;
            case 'l':
                strncpy(log_file, optarg, 255);
                break;
            case 'c':
                strncpy(conf_file, optarg, 255);
                break;
            case 'v':
                vtime = atoi(optarg);
                break;
            case 'z':
                yac_conn_timeout = atoi(optarg);
                break;
            case 'M':
                modem_shared = 0;
                break;
            case 'e':
                exit_after_display = 1;
                break;
            case 'n':
                skip_name = 1;
                break;
            case 'D':
                debug = 1;
                break;
            case 'h':
                usage();
            default:
                usage();
        };
    }

    read_conf_file(conf_file);

start:

    fd = open (modem_device, O_RDWR | O_NOCTTY);
    if (fd < 0)  {
        perror (modem_device); 
        exit (-1);
    }

    save_modem_settings(fd, &oldtio, &newtio);

    if (strlen(modem_init) > 2) {
      printf ("Initializing modem...\n");
      write (fd, modem_init, strlen (modem_init));
    }

    memset (&outbuff, 0, SZ_BUFF);			/* init the buff */
    while (STOP == FALSE)  {			/* loop for input */
        if (wait_for_input(fd, 60 * 1000)) {
            //sleep(1); /* For safe keeping so we don't get stuck in a loop */
            if (modem_shared) {
                if (stat("/var/tmp/modemlock", &statbuf) == 0) {
                    /* Tivo has a lock on the modem, don't 
                       do a read, and reopen the port from 
                       scratch after tivo has had its way with it */
                    printf("Tivo's making a call, won't step on his toes\n");
                    while (stat("/var/tmp/modemlock", &statbuf) == 0) {
                        if (STOP == TRUE) {
                            goto end_main_loop;
                        }
                        sleep(10);
                    }
                    close(fd);
                    printf("Restarting...\n");
                    goto start;
                }
            }
            while ((result = read(fd, inbuff, SZ_BUFF - strlen(outbuff) - 1)) > 0) {    /* grab the buff */
                inbuff[result] = 0;			/* mark end of buff */
                strcat (outbuff, inbuff);		/* build our str */
            }
            sloc = outbuff;
            while (sloc != NULL)  {	/* at end of str */
                if ((eloc = strstr (sloc, "\r\n")) != NULL) {
                    if (parse (sloc, eloc - sloc))  {   /* parse it out */
                        map_name();
                        reformat_number();
                        printit();             /* dump output */
                        logit(log_file);       /* log output */
		        sendit();
                        osdit();
                        if (exit_after_display) {
                            goto end_main_loop;
                        }
                        else {
			    if (modem_shared) {
                                close(fd);
                                printf("Restarting...\n");
                                goto start;
                            }
                        }
                    }
                    sloc = eloc + 2;
                }
                else {
                    break;
                }
            }
            memset (outbuff, 0, SZ_BUFF);	/* reset the buff */
        }
    }
    end_main_loop:

    tcsetattr(fd, TCSANOW, &oldtio);  /* set the port back */
    FreeTextOSD();
    printf ("Exited cleanly.\n");
    return (0);
}

void save_modem_settings(int fd, struct termios *oldtio, struct termios *newtio) {
    tcgetattr (fd, oldtio);  /* save current port settings */
	
    memset (newtio, 0, sizeof(*newtio));
    newtio->c_cflag = BAUDRATE | CRTSCTS | CS8 | CLOCAL | CREAD;
    newtio->c_iflag = IGNPAR;
    newtio->c_oflag = 0;

    /* set input mode (non-canonical, no echo,...) */
    newtio->c_lflag = 0;

    newtio->c_cc[VTIME] = vtime;	/* read after x tenths of a second */
    newtio->c_cc[VMIN] = 0;     /* read after x characters */

    tcflush (fd, TCIFLUSH);
    tcsetattr (fd, TCSANOW, newtio);
    return;
}

int wait_for_input(fd, msecs) {
    fd_set rfds;
    struct timeval timeout, *tptr;
    int ret;

    FD_ZERO( &rfds );
    FD_SET( fd, &rfds );
    if ( msecs >= 0 )
    {
        timeout.tv_sec = msecs / 1000;
        timeout.tv_usec = (msecs % 1000) * 1000;
        tptr = &timeout;
    }
    else
        tptr = NULL;

    ret = select( FD_SETSIZE, &rfds, NULL, NULL, tptr );
    return ret > 0;
}

/* parse it out to get the good stuff */
int parse (char *input, int len)  {
    int	ret_val = 0;
    char *dup;

    dup = malloc((len + 1)*sizeof(char));
    strncpy (dup, input, len + 1);
    dup[len] = 0;

    if (debug) {
        printf("DEBUG: %s\n", dup);
    }

    /* printf ("Debug: parse: input = %s\n", input); */

    if (strncmp (dup, "RING", 4) == 0)  {
        printf ("Modem: RING\n");
    }

    if (strncmp (dup, "OK", 2) == 0)  {
        printf ("Modem: OK\n");
    }

    if (strncmp (dup, "ERROR", 5) == 0)  {
        printf ("Modem: ERROR\n");
    }

    /* w00t! caller id info coming in, flip the flag on */
    if (strstr (dup, CID_DATE) != NULL)  {
        memset (&cid, 0, sizeof (caller_id)); /* init struct */
        INC_CID = TRUE;
    }

    /* copy all strings from the end of their flag to null */
    if (INC_CID == TRUE)  {
        if (strstr (dup, CID_DATE) != NULL)  {
            strncpy (cid.date, dup + strlen (CID_DATE), sizeof(cid.date)-1);
        }
        if (strstr (dup, CID_TIME) != NULL)  {
            strncpy (cid.time, dup + strlen (CID_TIME), sizeof(cid.time)-1);
        }
        if (strstr (dup, CID_NAME) != NULL)  {
            saw_name = TRUE;
            strncpy (cid.name, dup + strlen (CID_NAME), sizeof(cid.name)-1);
            if (strlen(cid.name) < 1) {
                strncpy(cid.name, "UNAVAILABLE", sizeof(cid.name)-1);
            }
            if (strlen(cid.name) == 1 && strncmp(cid.name, "O", 1) == 0) {
                strncpy(cid.name, "OUT OF AREA", sizeof(cid.name)-1);
            }
            if (strlen(cid.name) == 1 && strncmp(cid.name, "P", 1) == 0) {
                strncpy(cid.name, "PRIVATE CALLER", sizeof(cid.name)-1);
            }
        }
        if (strstr (dup, CID_NMBR) != NULL)  {
            saw_nmbr = TRUE;
            strncpy (cid.nmbr, dup + strlen (CID_NMBR), sizeof(cid.nmbr)-1);
            if (strlen(cid.nmbr) < 1 || (strlen(cid.nmbr) == 1 && (strncmp(cid.nmbr, "O", 1) == 0 || strncmp(cid.nmbr, "P", 1) == 0))) {
                *(cid.nmbr) = '\0';
            }
        }
        if (strstr (dup, CID_DDN_NMBR) != NULL)  {
            saw_nmbr = TRUE;
            strncpy (cid.nmbr, dup + strlen (CID_DDN_NMBR), sizeof(cid.nmbr)-1);
            if (strlen(cid.nmbr) < 1 || (strlen(cid.nmbr) == 1 && (strncmp(cid.nmbr, "O", 1) == 0 || strncmp(cid.nmbr, "P", 1) == 0))) {
                *(cid.nmbr) = '\0';
            }
        }
        if ((saw_name || skip_name) && saw_nmbr) {
            INC_CID = FALSE;
            saw_name = FALSE;
            saw_nmbr = FALSE;
            ret_val = TRUE;
        }
    }

    free (dup);
    return (ret_val);
}

void osdit() {
    int x;
    char name[SZ_BUFF];			// Buffer for short version of name

    ClearOSD(osd_y==1);			// If line=1, clear to top of screen

    strncpy(name,cid.name,MAX_CHAR_X-strlen(cid.nmbr)-osd_x);

    DrawString(osd_x, osd_y, name, fg_color, bg_color);
    DrawString(MAX_CHAR_X-strlen(cid.nmbr)+1,osd_y,cid.nmbr,fg_color, bg_color);

    for (x=0; x < cid_onscreen; x++) {	// Redraw text every second
      DrawOSD();			// to blindly compete with user
      sleep(1);				// and other OSD issues
    }
    ClearOSD(0);			// Reset our text to transparent
    DrawOSD();				// to at least remove any residue
}

void reformat_number()  {
    if (strlen(cid.nmbr)==10) {		// Reformat 10 digit numbers as
      memcpy(cid.nmbr+9,cid.nmbr+6,4);  //  (800)555-1212
      memcpy(cid.nmbr+5,cid.nmbr+3,3);
      memcpy(cid.nmbr+1,cid.nmbr,3);
      cid.nmbr[0] = '(';
      cid.nmbr[4] = ')';
      cid.nmbr[8] = '-';
      cid.nmbr[13] = '\0';
    }
}

void printit() {
    printf ("--Call Logged--\n");
    printf ("  Date:   %s\n", cid.date);
    printf ("  Time:   %s\n", cid.time);
    printf ("  Name:   %s\n", cid.name);
    printf ("  Number: %s\n\n", cid.nmbr);
}

void sendit ()  {
    char buf[256];
    snprintf(buf, 256, "@CALL%s~%s", cid.name, cid.nmbr);
    send_to_all_listeners(buf);
}

void logit (char *logfile)  {
    FILE	*file;
    time_t	unix_time;
    
    unix_time = time (NULL);

    if ((file = fopen (logfile, "a")) == NULL)  {
        printf ("Failed to write to %s.\n", logfile);
    }  else  {
        fprintf (file, "%s\t%s\t%s\t%s\t%ld\n",
                 cid.date,
                 cid.time,
                 cid.name,
                 cid.nmbr,
                 unix_time);
    }
    fclose (file);
}

void usage() {
    printf("elseed version %s by Greg Gardner\n", VERSION);
    printf("Usage: elseed [options]\n");
    printf("Options:\n");
    printf("    -x N    set x coordinate to N [default %d]\n", X_POS_DEFAULT);
    printf("    -y N    set y coordinate to N [default %d]\n", Y_POS_DEFAULT);
    printf("    -f N    set foreground color to N [default %d]\n", FG_COLOR_DEFAULT);
    printf("    -b N    set background color to N [default %d]\n", BG_COLOR_DEFAULT);
    printf("    -d S    set modem device to S [default '%s']\n", MODEMDEVICE_DEFAULT);
    printf("    -i S    set modem init string to S [default '%s']\n", MODEMINIT_DEFAULT);
    printf("    -l S    set log file to S [default '%s']\n", LOG_FILE_DEFAULT);
    printf("    -c S    set conf file to S [default '%s']\n", CONF_FILE_DEFAULT);
    printf("    -t S    set time CID info is on screen in secs [default %d seconds]\n", CID_ONSCREEN_DEFAULT);
    printf("    -v S    set delay for reading from modem in tenths of a sec [default %d]\n", VTIME_DEFAULT);
    printf("    -z S    set YAC connect timeout in milliseconds [default %d]\n", YAC_CONN_TIMEOUT_DEFAULT);
    printf("    -e      exit after displaying caller-id info [default is off]\n");
    printf("    -n      tells elseed not to look for the caller's name [default is off]\n");
    printf("    -M      turn off modem sharing [default is on]\n");
    printf("    -D      put elseed in debug mode\n");
    printf("    -h      show this help\n");
    exit(0);
}

/* let ya know we're exiting cleanly */
void getout (int sig)  {
    printf ("Caught signal, standby while exiting... (signo=%d)\n", sig);
    STOP = TRUE;
}

void send_to_all_listeners(char *pszString) {
    int nCounter;
    int nSocket;
    struct sockaddr_in RemoteAddress;
    struct pollfd ConnectFD;
    int nReturn;
    int gReturn;
    int gErr, gErrLen = sizeof(gErr);

    RemoteAddress.sin_family = AF_INET;

    for (nCounter = 0; nCounter < nYacListeners; nCounter++) {
        if (-1 == (nSocket = socket(AF_INET, SOCK_STREAM, 0))) {
            if (debug) printf("yac socket() called failed: %d\n", errno);
            return;
        }
        if (-1 == fcntl(nSocket, F_SETFL, O_NONBLOCK)) {
            if (debug) printf("yac fcntl() called failed: %d\n", errno);
            close(nSocket);
            continue;
        }
        RemoteAddress.sin_port = htons(YacListeners[nCounter].nPort);
        memcpy(&RemoteAddress.sin_addr.s_addr, YacListeners[nCounter].ip_addr, 4);
        if (debug) {
            printf("Attempting to send caller id info to %d.%d.%d.%d:%d\n",
               YacListeners[nCounter].ip_addr[0], 
               YacListeners[nCounter].ip_addr[1], 
               YacListeners[nCounter].ip_addr[2], 
               YacListeners[nCounter].ip_addr[3], 
               YacListeners[nCounter].nPort);
        }
        if (-1 == connect(nSocket, (struct sockaddr *) &RemoteAddress, sizeof(RemoteAddress))) {
            if (EINPROGRESS == errno) {
                ConnectFD.fd = nSocket;
                ConnectFD.events = POLLOUT;
                nReturn = poll(&ConnectFD, 1, yac_conn_timeout);
                if (nReturn <= 0) {
                    if (debug) printf("yac poll() returned: %d\n", nReturn);
                    close(nSocket);
                    continue;
                }
                if (!(ConnectFD.revents & POLLOUT)) {
                    if (debug) printf("yac client will block, skipping\n");
                    close(nSocket);
                    continue;
                }
                gReturn = getsockopt(nSocket, SOL_SOCKET, SO_ERROR, &gErr, &gErrLen);
                if (gErr != 0) {
                    if (debug) printf("yac connect() shows error in SO_ERROR: %d\n", gErr);
                    close(nSocket);
                    continue;
                }
            } else {
                if (debug) printf("yac connect() failed: %d\n", errno);
                close(nSocket);
                continue;
            }
        }
        if (debug) printf("sending caller id info to yac client\n");
        if (-1 == send(nSocket, pszString, strlen(pszString) + 1, 0)) {
            if (debug) printf("yac send() failed: %d\n", errno);
            close(nSocket);
            continue;
        }
        close(nSocket);
    }
}

void add_yac_listener(char *ip_addr) {
    char buf2[5];
    char onlyIP[16];
    int nCounter, blen;

    char *pDelim;
    char *pStart;

    if ((pDelim = strchr(ip_addr, ':')) != NULL) {
        int diff = pDelim - ip_addr;
        int length = mymin(diff, 15);
        strncpy(onlyIP, ip_addr, 15);
        onlyIP[length] = 0;
	YacListeners[nYacListeners].nPort = atoi(pDelim + 1);
    }
    else {
        int ipl = strlen(ip_addr);
        int length = mymin(ipl, 15);
        strncpy(onlyIP, ip_addr, 15);
        onlyIP[length] = 0;
        YacListeners[nYacListeners].nPort = 10629;
    }
    // For some reason gethostbyname causes an illegal instruction on a Tivo.
    // Se we get to parse the IP Address ourselves. Whee.
    pStart = onlyIP;
    for (nCounter = 0; nCounter < 4; nCounter++) {
        if (nCounter < 3) {
            pDelim = strchr(pStart, '.');
        }
        else {
            pDelim = onlyIP + strlen(onlyIP);
        }
        if (NULL == pDelim ||
            (pDelim - onlyIP > strlen(onlyIP)) ||
            (pDelim - pStart > 3)) {
            printf("Error in format of YacClient IP address, skipping %s\n", 
                   ip_addr);
            return;
        }
        blen = mymin((pDelim - pStart), 3);
        strncpy(buf2, pStart, blen);
        buf2[blen] = 0;
        YacListeners[nYacListeners].ip_addr[nCounter] = 
            (unsigned char) atoi(buf2);
        pStart = pDelim + 1;
    }
    if (debug) {
        printf("Added yac listener at %d.%d.%d.%d:%d\n", 
               YacListeners[nYacListeners].ip_addr[0], 
               YacListeners[nYacListeners].ip_addr[1], 
               YacListeners[nYacListeners].ip_addr[2], 
               YacListeners[nYacListeners].ip_addr[3], 
               YacListeners[nYacListeners].nPort);
    }
    nYacListeners++;
}

int mymin(int a, int b) {
    return a > b ? b : a;
}

void read_conf_file(char * conf_file) {
    FILE  *fp;
    char  temp[80], *nl;
    int   x=0;

    if ( ( fp = fopen( conf_file, "r" ) ) == NULL ) {
        if (debug) {
            printf("No conf file found at %s\n", conf_file);
        }
        return;
    }

    while( ( fgets( temp, 80, fp ) != 0 ) && ( x < MAX_LST ) ) {
        if( (temp[0] == '\n') || (temp[0] == '#') )
            continue;
        nl = strchr(temp, '\n');
        if (nl != NULL) {
            *nl = 0;
        }
        if (strncasecmp(temp, "map", 3) == 0) {
            if (num_name_list <= MAX_LST) {
                if (strlen(temp) > 4) {
                    strncpy(name_list[x].nmbr, temp + 4, 10);
                    name_list[x].nmbr[11] = 0;
                }
                if (strlen(temp) > 15) {
                    strncpy(name_list[x].name, temp + 15, strlen(temp) - 15);
                    name_list[x].name[strlen(temp) - 15] = 0;
                }
                num_name_list++;
            }
        }
        else if (strncasecmp(temp, "yacclient", 9) == 0) {
            if (strlen(temp) > 10 && nYacListeners < MAX_LST) {
                add_yac_listener(temp + 10);
            }
        }
        if (debug) {
            printf("DEBUG: Read record %s\n", temp);
        }
        x++;
    }

    fclose( fp ); 
}

void map_name() {
    int i=0;
    for ( i = 0 ; i < num_name_list; i++ ) {
        if (!strcmp(cid.nmbr,name_list[i].nmbr) ) {
            strcpy(cid.name,name_list[i].name);
            break;
        }
    }
}
