/* 
 * Copyright (C) 2002 by Greg Gardner
 * 
 * This file is part of elseed, a caller-id program for your TiVo.
 * 
 * elseed is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * elseed is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA
 *
 * $Id: elseed.h,v 1.8 2003/01/24 20:05:32 greg Exp $
 */

/* set this to the correct tty for your modem */
#define MODEMDEVICE_DEFAULT "/dev/cua1"

/* if your modem doesn't respond to this string,
 * then it probably doesn't support caller id
*/
#define MODEMINIT_DEFAULT "AT+VCID=1"

/* nothing fancy, 9600 is fine, we're just doing caller id */
#define BAUDRATE B9600

/* may wanna write your log somewhere else.
 * if so, change it here for now
*/
#define LOG_FILE_DEFAULT "/var/log/elseed.log"	/* log file for caller id info */

/* you might want your conf file elsewhere, too. */
#define CONF_FILE_DEFAULT "/etc/elseed.conf" 

/* this is what my modem (USR 33.6) spits out for caller-id.
 * if yours does something different you wanna change this.
*/
#define CID_DATE "DATE = "
#define CID_TIME "TIME = "
#define CID_NAME "NAME = "
#define CID_NMBR "NMBR = "
#define CID_DDN_NMBR "DDN_NMBR= "

/*
 * you don't wanna muck anything else below here
*/
#define SZ_BUFF 255
#define SZ_NAME 30
#define SZ_NMBR 14
#define MAX_LST 50
#define FALSE 0
#define TRUE 1

#define X_POS_DEFAULT 0
#define Y_POS_DEFAULT 1
#define FG_COLOR_DEFAULT 4
#define BG_COLOR_DEFAULT 13
#define CID_ONSCREEN_DEFAULT 10
/* VTIME_DEFAULT used to be 20. If caller-id isn't working, set this 
   to 20 and recompile and try that */
#define VTIME_DEFAULT 5
#define YAC_CONN_TIMEOUT_DEFAULT 100

#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/select.h>
#include <fcntl.h>
#include <termios.h>
#include <stdio.h>
#include <signal.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <errno.h>
#include <netdb.h>
	
/* caller id structure. leave room for a null character */
typedef struct _caller_id  {
    char	date[5];	/* date - MMDD */
    char	time[5];	/* 24HR time - HHMM */
    char	name[SZ_BUFF];	/* name of person calling */
    char	nmbr[SZ_NMBR];	/* 10 digit phone number - (800)555-1212 */
}  caller_id;

typedef struct _yac_listeners {
    unsigned char ip_addr[4];
    int	          nPort;
} yac_listeners;

typedef struct _numbs {
    char    name[SZ_NAME];  /* name of person calling */
    char    nmbr[SZ_NMBR];  /* 10 digit phone number - (800)555-1212 */
} name_struct;


int parse (char *input, int len);
void save_modem_settings(int fd, struct termios *oldtio, struct termios *newtio);
int wait_for_input(int fd, int msec);
void osdit ();
void reformat_number();
void printit ();
void logit (char *logfile);
void getout (int sig);
void usage();
void sendit ();
void add_yac_listener(char *IPAddress);
void send_to_all_listeners(char *pszString);
int mymin(int a, int b);
void read_conf_file(char * conf_file);
void map_name();
