#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <signal.h>
#include <string.h>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#include <getopt.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <linux/unistd.h>
#include <linux/module.h>
#include "osd.h"

#define  SLEEP_TIME 100000

/* Text Colors Credit John Kemeny <johnkemeny@yahoo.com> */
/* Had to change quite a bit of them though....sigh */

char *newtext2osd_colors[] =
{
   "transparent1",
   "grey",
   "white1",
   "white2",
   "white3",
   "transparent2",
   "red1",
   "green",
   "red2",
   "orange",
   "turquoise",
   "red3",
   "yellow",
   "black1",
   "transparent3",
   "black2",
   ""
};

/****************************************************************************/
int find_colors( char *color )
{
   int count;
   while ( strlen( newtext2osd_colors[ count ] ) > 0 )
   {
      if ( strcmp( newtext2osd_colors[ count ], color ) == 0 )
      {
         break;
      }
      count++;
   }

   if ( strlen( newtext2osd_colors[ count ] ) > 0 )
   {
      return( count );
   }
   else
   {
      return( -1 );
   }
}

/****************************************************************************/
void quit( int x )
{
   fprintf( stderr, "Caught a signal\n" );
   signal( x, NULL );
   ClearOSD();
   DrawOSD();
   FreeTextOSD();
   exit( 1 );
}


/****************************************************************************/
int fchecksum( char *file )
{
   int   csum = 0;
   int   offset;
   FILE  *fp;

   fp = fopen( file, "r" );
   if ( fp == 0 )
   {
      return( 0 );
   }

   offset = 1;
   while( !feof( fp ) )
   {
      csum += ( offset * fgetc( fp ) );
      offset++;
   }
   fclose( fp );

   return( csum );
}


/****************************************************************************/
int checkFile( char *fName, int oldcsum )
{
   int newcsum;

   newcsum = fchecksum( fName );
   if ( oldcsum != newcsum )
   {
      return( 1 );
   }

   return( 0 );
}

/****************************************************************************/
int getRandom( )
{
   FILE *fp;
   char val;

   fp = fopen( "/dev/urandom", "r" );
   if ( fp == 0 )
   {
      return( 0 );
   }
   val = fgetc( fp );
   fclose( fp );

   return( val );
}


/****************************************************************************/
void help()
{
  int     count;

  printf
  ( 
     "Display a File\n"
     "newtext2osd -s seconds -w file -f color -b color -d file\n"
     "Display a Text String\n"
     "newtext2osd -s seconds -f color -b color -x xpos -y ypos -t "
     "\"text\"\n"
     " Wait for Options:\n"
     "  -z\t wait forever (must be killed)\n"
     "  -s\t wait for specified seconds\n"
     "  -m\t wait for specified microseconds\n"
     "  -w\t wait for a file to be removed\n"
     "  -e\t exit without clearing the screen\n"
     " Display Options: \n"
     "  -f\t Foreground color (numeric)\n"
     "  -b\t Background color (numeric)\n"
     "  --fg\t Foreground color (string, see below)\n"
     "  --bg\t Background color (string, see below)\n"
     "  -d\t File to Display (stdin, if not specified)\n"
     "  -r\t Pick a random x and y location\n"
     "  -x\t X Offset\n"
     "  -y\t Y Offset\n"
     "  -t\t Text String\n"
     "\n"
     "  -c\t Clear Screen\n"
     "\n"
     "  Defaults to a (very compact) 40 x 24 Screen Size\n"
     "  --zirak    - Use Zirak's Screen Size\n"
     "  --gardavis - Use GarDavis's Screen Size\n"
     "\n"
     "  \t Specifying -m less than 40000 is probably not very interesting\n"
     "  \t (ie TOO subliminal)\n"
     "\n"
  );
  printf( "Possible Colors : " );
  count = 0;
  while( strlen( newtext2osd_colors[ count ] ) > 0 )
  {
     printf( "%s, ", newtext2osd_colors[ count ] );
     count++;
  }
  printf( "\n" );
  exit( 0 );
}


static struct option long_options[] = 
{
   { "fg", 1, 0, 0 },
   { "bg", 1, 0, 0 },
   { "zirak", 0, 0, 0 },
   { "gardavis", 0, 0, 0 },
   { 0, 0, 0, 0 }
};

/****************************************************************************/
int main(int argc, char **argv)
{
   int           option_index;
   int           temp;
   int           x = 0;
   int           y = 0;
   int           count;
   int           icount = 0;
   int           iterations = 0;
   char          arg;
   int           seconds = 0;
   int           microseconds = 0;
   char          *waitFile = 0;
   int           temp_fg;
   int           temp_bg;
   int           fg = 12;
   int           bg = 5;
   char          *inFile = 0;
   int           waitForever = 0;
   int           exitWithOutClear = 0;
   FILE          *fp = 0;
   FILE          *checkfp;
   char          line[ 80 ];
   char          *ptr;
   char          *text = 0;
   int           loop;
   int           csum;
   int           clear = 0;
   int           random = 0;
   char          clearLine[] =
      "                                        ";
          

   osd_setupaspect( 0 );

   if ( argc == 1 )
   {
      help();
   }

   while ( 1 ) 
   {
       int arg;
       if ( ( arg = getopt_long( argc, argv, "h?zs:w:f:b:d:x:y:t:m:ecr", 
          long_options, &option_index) ) == -1 ) 
       {
          break;
       }
       switch (arg) 
       {
         case '?':
         case 'h': help();
         case 'z': waitForever = 1;                 break;
         case 's': seconds = atoi( optarg );        break;
         case 'm': microseconds = atoi( optarg );   break;
         case 'w': waitFile = optarg;               break;
         case 'f': fg = atoi( optarg );             break;
         case 'b': bg = atoi( optarg );             break;
         case 'd': inFile = optarg;                 break;
         case 'x': x = atoi( optarg );              break;
         case 'y': y = atoi( optarg );              break;
         case 't': text = optarg;                   break;
         case 'e': exitWithOutClear = 1;            break;
         case 'c': clear = 1;                       break;
         case 'r': random = 1;                      break;
         case 0  :
         {
            if ( strcmp( long_options[option_index].name, "fg" ) == 0 )
            {
               temp = find_colors( optarg );
               if ( temp > 0 )
               {
                  fg = temp;
               }
            }

            if ( strcmp( long_options[option_index].name, "bg" ) == 0 )
            {
               temp = find_colors( optarg );
               if ( temp > 0 )
               {
                  bg = temp;
               }
            }
            if ( strcmp( long_options[option_index].name, "zirak" ) == 0 )
            {
               osd_setupaspect( 1 );
            }
            if ( strcmp( long_options[option_index].name, "gardavis" ) == 0 )
            {
               osd_setupaspect( 2 );
            }
            break;
         }
      }
   }

   if ( seconds > 0 )
   {
      microseconds = seconds * 1000000;
      seconds = 0;
   }

   signal( 2, quit );
   signal( 15, quit );
   signal( 11, quit );

   while( 1 )
   {
      SetupTextOSD();
      ClearOSD();

      if ( clear == 1 )
      {
         ClearOSD();

         temp_fg = 12;
         temp_bg = 0;
         x = 0;
         for( loop = 0 ; loop < OSD_MAX_Y ; loop++ )
         {
            DrawString( &x, &loop, clearLine, temp_fg, temp_bg );
         }

         DrawOSD();
         FreeTextOSD();
         exit( 1 );
      }

      loop = 0;

      if ( fp != 0 )
      {
         fclose( fp );
      }

      if ( text )
      {
         if ( random )
         {
            x = getRandom() % OSD_MAX_X;
            y = getRandom() % OSD_MAX_Y;
            if ( ( x + strlen( text ) ) > OSD_MAX_X )
            {
               x -= strlen( text );
               if ( x < 0 )
               {
                  x = 0;
               }
            }
         }

         if ( ( ( x + strlen( text ) ) > OSD_MAX_X ) || ( y > OSD_MAX_Y ) )
         {
            fprintf( stderr, "Text outside screen area\n" );
            exit( 1 );
         }
         // printf( "%d %d\n", x, y );
         DrawString( &x, &y, text, fg, bg );
      }
      else
      {
         if ( inFile == 0 )
         {
            fp = stdin;
         }
         else
         {
            fp = fopen( inFile, "r" );
            if ( fp == 0 )
            {
               printf( "Could not open %s\n", inFile );
               exit( 1 );
            }
            csum = fchecksum( inFile );
         }

         y = -1;
         while ( !feof( fp ) )
         {
            x = 0;
            y++;
            line[ 0 ] = 0;
            fgets( line, 80, fp );
            ptr = strchr( line, '\n' );
            if ( ptr != 0 )
            {
               *ptr = 0;
            }
            if ( strlen( line ) > 0 )
            {
               line[ OSD_MAX_X ] = 0;
               DrawString( &x, &y, line, fg, bg );
            }
         }
      }

      DrawOSD();

      if ( exitWithOutClear )
      {
         exit( 0 );
      }

      loop = 0;
      if ( microseconds > 0 )
      {
         if ( microseconds > SLEEP_TIME )
         {
            iterations = microseconds / SLEEP_TIME;
            if ( iterations == 0 )
            {
               iterations++;
            }
            // Changing the file does not reset the counter, do we do not
            // initialize icount
            for ( ; icount < iterations ; icount++ )
            {
               usleep( SLEEP_TIME );
               if ( text == 0 )
               {
                  if ( checkFile( inFile, csum ) > 0 )
                  {
                     loop = 1;
                     break;
                  }
               }
            }
         }
         else
         {
            usleep( microseconds );
         }
      }
      else if ( waitFile != 0 )
      {
         while( 1 )
         {
            checkfp = fopen( waitFile, "r" );
            if ( checkfp == 0 )
            {
               break;
            }
            if ( text == 0 )
            {
               if ( checkFile( inFile, csum ) > 0 )
               {
                  loop = 1;
                  break;
               }
            }
            usleep( SLEEP_TIME );
         }
      }
      else if ( waitForever != 0 )
      {
         while( 1 )
         {
            usleep( SLEEP_TIME );
            if ( text == 0 )
            {
               if ( checkFile( inFile, csum ) > 0 )
               {
                  loop = 1;
                  break;
               }
            }
         }
      }

      ClearOSD();
      DrawOSD();
      FreeTextOSD();

      if ( loop )
      {
         continue;
      }

      if ( ( fp != 0 ) && ( fp != stdin ) )
      {
         fclose( fp );
      }

      break;
   }

   return 0;
}



