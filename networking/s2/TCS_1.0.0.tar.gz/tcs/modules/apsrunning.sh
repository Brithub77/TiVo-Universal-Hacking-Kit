#!/bin/bash
/var/hack/bin/ps x > /tmp/tcsps.out
/bin/grep elseed /tmp/tcsps.out
/bin/grep tcsd /tmp/tcsps.out
/bin/grep TCS /tmp/tcsps.out
/bin/grep tivoftp /tmp/tcsps.out
/bin/grep tivoweb /tmp/tcsps.out
/bin/grep tivovbi /tmp/tcsps.out
/bin/grep tivocid /tmp/tcsps.out
/bin/grep tnlite /tmp/tcsps.out
/bin/grep yac /tmp/tcsps.out
/bin/grep tserver_mfs /tmp/tcsps.out
exit 0
