set TcsSendKeyLockFile "/tmp/tcssendkey.lock"
set TcsSendKeySourceFile "/tmp/tcssendkey"
