##############################################################################
# TiVo.pm
# Version 1.1
# 3/17/2003
#
# Copyright (c) 2003 TiVo Inc. All Rights Reserved.
#
# This file contains Original Code and/or Modifications of Original Code
# as defined in and that are subject to the TiVo Public Source License
# Version 1.0 (the 'License'). You may not use this file except in
# compliance with the License. Please obtain a copy of the License at
# http://www.tivo.com/developer/tivo_license.asp and read it before
# using this file.
#
# THE ORIGINAL CODE AND ALL SOFTWARE DISTRIBUTED UNDER THE LICENSE ARE
# PROVIDED _AS IS_, WITH ALL FAULTS AND WITHOUT WARRANTY OF ANY KIND,
# EITHER EXPRESS OR IMPLIED.  TIVO HEREBY DISCLAIMS ALL SUCH WARRANTIES
# INCLUDING, BUT NOT LIMITED TO,  WARRANTIES AND/OR CONDITIONS OF FITNESS
# FOR A PARTICULAR PURPOSE, MERCHANTABILITY, AND NON-INFRINGEMENT OF THIRD
# PARTY RIGHTS, EXCLUSIVELY OR RESULTS OBTAINED FROM USE OF THE MATERIAL.
# TIVO MAKES NO WARRANTY OF ANY KIND WITH RESPECT TO FREEDOM FROM PATENT,
# TRADEMARK, OR COPYRIGHT INFRINGEMENT.  Please see the License for
# specific language governing rights and limitations under the License.
#
##############################################################################
##############################################################################

package TiVo;
use 5.006_001;
use strict;
use File::Basename qw();
use FileHandle;

=head1 NOTES

Currently requires these additional modules for full functionality:

 Storable
 IO::File
 MP3::Info
 Image::Magick
 Digest::MD5
 MP3::M3U::Parser
 Ogg::Vorbis::Header::PurePerl

=cut

# Constants for use in QueryServer message
use constant VERSION      => '1';
use constant INTVERSION   => '1.1.0';
use constant INTNAME      => 'TiVoServer BC';
use constant ORGANIZATION => 'TiVo, Inc.';
use constant COMMENT      => ''; 

##
## Generic, overridable interface to dynamic class data
##
##   Autoload will catch any method beginning with an underscore ( _ )
##   and convert the method name to a key value, which is used to
##   access the object's internal DATA hash. Methods written to
##   override interactions with a given key should use lvalue
##   syntax to maintain compatibility with other module internals.
##
sub AUTOLOAD : lvalue {
  my $self = shift;

  no strict 'vars';
  my $param = $AUTOLOAD;

  $param =~ s/^.*:://;

  return unless $param =~ /^_(.+)$/;

  $self->{'DATA'}->{ uc($1) };

}

=head1 TiVo Utility Routines

=head2 TiVo->uri_unescape( $ )

Decodes URI strings per RFC 2396

=cut

sub uri_unescape {
  my $self = shift;
  my $str = shift;

  $str =~ s/\+/ /g;

  $str =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/eg;

  return $str;
}


=head2 TiVo->uri_escape( $ )

Encodes URI strings per RFC 2396

=cut

sub uri_escape {
  my $self = shift;
  my $str = shift || return undef;

  $str =~ s/([^A-Za-z0-9\+\-\/_.!~*'() ])/sprintf("%%%02X", ord($1))/eg;

  $str =~ s/ /+/g;

  return $str;

}




=head2 TiVo->servicename( $ )

Returns the service name (first element of object path) of the object
or passed argument

=cut

sub servicename {
  my $self = shift;

  my $path = shift || $self->_Object || return undef;

  $path =~ /^(\/[^\/]*)/;

  return $1;

}


=head2 TiVo->basename( $ )

Returns the basename (filename) of the object's internal Path
or passed argument

=cut

sub basename {
  my $self = shift;

  my $path = shift || $self->_Path || return undef;

  return File::Basename::basename($path);
}

sub dirname {
  my $self = shift;

  my $path = shift || $self->_Path || return undef;

  return File::Basename::dirname($path);
}


=head2 TiVo->query_container

Returns a data structure (suitable for use with xml_out) which
describes this object in response to a QueryContainer command

=cut

sub query_container {
  my $self = shift;
  my $params = shift;

  my $script_name = $params->_EnvScriptName || "";
  my $title = $self->_Title;
  unless ($title) {
    $title = $self->basename;
    $title =~ s/_/ /g;
  }
  my $details = {
    'Item' => [
      {
        'Details' => {
          'Title'        => $title,
          'ContentType'  => $self->_ContentType,
          'SourceFormat' => $self->_SourceFormat   
        }
      },
      {
        'Links' => {
          'Content' => {
            'Url' => $script_name . $self->_Url
          }
        }
      }
    ]
  };

  return $details;

}


##############################################################################

=head1 TiVo::Server

The core server object for processing requests

=cut

package TiVo::Server;
use base qw(TiVo);

=head2 TiVo::Server->new( % )

Constructor for TiVo::Server. Accepts parameters via argument hash.

=over 4

=item SERVER_NAME

The name of the server.  Appears on TiVo menu displays

=item CACHE_DIR

Directory where cached data (directory lookups, etc.) is stored.

=item IMAGE_DIR

Directory that stores thumbnails and rotated images

=item USE_GALLERY

1 if we're using a gallery, 0 if not.

=item GALLERY_PATH

The path to the gallery albums.

=item GALLERY_LOCATION

The location of the gallery on the TiVo.

=item LOG_HANDLE

Reference to a subroutine that handles logging.  Called when we
want to generate debug output.  The first paramaster is the log level
(either 5 or 6) and the second parameter is the data to be logged.

=back

=cut

sub new {
  my $class = shift;

  my $self = {};
  bless $self, $class;

  my %params = ( @_ );

  $self->_Name = $params{'SERVER_NAME'} || 'TiVo Server';
  $self->_CacheDir = $params{'CACHE_DIR'};
  $self->_ImageDir = $params{'IMAGE_DIR'} || $self->_CacheDir;
  $self->_Logger   = $params{'LOG_HANDLE'};
  $self->_UseGallery = $params{'USE_GALLERY'} || 0;
  $self->_GalleryDir = $params{'GALLERY_PATH'};
  $self->_GalleryLocation = $params{'GALLERY_LOCATION'};

  if ($self->_UseGallery == 1 && $self->_GalleryDir !~ /^.*\/$/)  {
      $self->_GalleryDir = $self->_GalleryDir . "/";
  }
  if ($self->_UseGallery == 1 && $self->_GalleryLocation =~ /^(.*)(\/+)$/)  {
      $self->_GalleryLocation = $1;
  }

  $self->_Services = {};

  return $self;
}

sub log {
  my $self = shift;

  my $logger = $self->_Logger;
#  return unless $logger;

  &{$logger}(@_);
}

=head2 TiVo::Server->load_cache( $ )

Loads the requested object from the external cache.

=cut

sub load_cache {
  my $self = shift;

  my $path = shift || return undef;

  my $cache_dir = $self->_CacheDir || return undef;

  require Storable;
  require Digest::MD5;

  my $cache_name = Digest::MD5::md5_hex($path);

  return eval { Storable::retrieve("$cache_dir/$cache_name") };
}



=head2 TiVo::Server->store_cache( $ )

Stores the given object in the external cache.

=cut

sub store_cache {
  my $self = shift;

  my $object = shift || return undef;
  my $cache_dir = $self->_CacheDir || return undef;

  require Storable;
  require Digest::MD5;

  my $cache_name = Digest::MD5::md5_hex($object->_Object);

  return eval { Storable::store( $object, "$cache_dir/$cache_name" ); };
}



=head2 TiVo::Server->freeze( $ )

Stores the given Object in memory and passes it to the server's current
external cache functions

=cut

sub freeze {
  my $self = shift;

  my $object = shift || return undef;

  return $self->store_cache($object);
}



=head2 TiVo::Server->thaw( $ )

Returns the requested Object from Cache, creating it when necessary

=cut

sub thaw {
  my $self = shift;

  my $path = shift || return undef;
  my $item;

  $item = $self->load_cache($path);

  if( ! defined($item) || $item->expired ) {

    $item = $self->create_object($path);
    $self->freeze($item);

  }

  return $item;

}



=head2 TiVo::Server->create_object( $ )

Creates a new Item or Container object using the full filesystem
path provided.

=cut

sub create_object {
  my $self = shift;

  my $path = shift || return undef;

  $self->log(5, "in create_object - path is $path");
  my $item;


  # Check for '/' special condition
  if ($path eq '/') {

    $item = TiVo::Container::Server->new(
      SERVICE => "/",
      TITLE   => $self->_Name
    ) || return undef;

    my @contents = map { $self->_Services->{ $_ } } keys %{ $self->_Services };
    $item->_Contents = \@contents;

  # Perform filesystem scan
  } else {
    # Check if it's an external URL.
    if ($path =~ /^http:\/\//)  {
      $self->log(6, "creating external URL - path is $path");
      $item = TiVo::Item::HttpStream->new($path);
      return $item || undef;
    }
    my $service = $self->servicename($path);

    return undef unless defined $self->_Services->{$service};
    $service = $self->_Services->{$service};

    $self->log(6, "service is $service.");

    my $useCodeRef = 0;
    my $codeRef = sub {};
    # Special case for gallery files.
    my $gD = "";
    my $gL = $self->_GalleryLocation;
    if ($self->_UseGallery == 1 && $path =~ /^$gL(?:\/)*$/)  {
        $self->log(6, "Got gallery file: GalleryDir is ". $self->_GalleryDir);
        $self->log(6, "server is $self, path is $path");
        $gD = $self->_GalleryDir;
        my $pathToSend = $gD;
        $item = TiVo::Container::Gallery->new(
            PATH => $pathToSend,
            SERVICE => $service,
            GALLERYDIR => $gD,
            GALLERYLOCATION => $gL);
        $self->log(6, "Created gallery item. Entries is " . $item->_Entries);
        if (!$item) {$self->log(6, "Gallery item is null!"); return undef;}
        $self->log(6, "returning item: $item");
        return $item || undef;
    } elsif ( $self->_UseGallery == 1 && $path =~ /^$gL\/(.*)$/)  {
        my $restOfURL = $1;
        $self->log(6, "Got gallery file: GalleryDir is ". $self->_GalleryDir . " and path is " . $path);
        $gD = $self->_GalleryDir;
        my $pathToSend = $gD . $restOfURL;
        
        $path = $pathToSend;
        $codeRef = sub {
            my $self = shift;
            my $gD2 = $$self->_GalleryDir;
            my $gL2 = $$self->_GalleryLocation;
            $gD2 =~ s#^(.*)(?:/)*$#$1#;
            if ($$self->_Path =~ /^(?:$gD2)(.*)$/)  {
                return ($gL2 . "/" . $1);
            }
            return undef;
        };
        $useCodeRef = 1;
    }
    if ($useCodeRef == 0)  { 
        $path = $service->obj_to_path($path);
    }
    $self->log(6, "path is now $path");

    return undef if grep { /^\.\.$/ } split(/\//, $path);

    my @parts = split(/\./, $path);
    my $suffix = uc( pop @parts);

    # Check if it's a playlist-type URL.
    if ($path =~ /^(.*\.m3u)\/(\d+)$/)  {
        my $m3u = $service->path_to_obj($1);
        my $number = $2;
        $self->log(6, "got playlist type - from $m3u, number $number.");
        my $playlistItem = $self->thaw($m3u);
        return undef unless (defined $playlistItem);
        #my @pM3U = @{${$playlistItem->_parsedM3U}};
        #my $songEntry = $pM3U[$number];
        my @entries= @{$playlistItem->trueentries($self)};
        my @songEntry = @{$entries[$number]};
       
        $self->log(6, "songEntry is: @songEntry");
        $self->log(6, "entry 0 is " . $songEntry[0]);
        $self->log(6, "name of file is: " . $songEntry[2]);

        my @parts2 = split(/\./, $songEntry[2]);
        my $suffix2 = uc( pop @parts2);
        my $class = "TiVo::Item::$suffix2";

        $self->log(6, "Returning song with path " . $songEntry[2]);

        $item = eval{ $class->new( $songEntry[2], $service ); } || return undef;
    }
    # Create a directory or M3U container
    elsif( -d $path || $suffix eq "M3U") {
        if ($suffix eq "M3U")  {
            $self->log(6, "Creating new Container::M3U (path is $path)");
            $item = TiVo::Container::M3U->new(
                PATH => $path,
                SERVICE => $service);
        } else {
            $self->log(6, "Creating new Container (path is $path).");
            if ($self->_UseGallery == 1 && $useCodeRef == 1)  {
              $self->log(6, "Container is a gallery object.");
              $item = TiVo::Container::GalleryAlbum->new(
                  PATH => $path,
                  SERVICE => $service,
                  CODEREF => $codeRef,
                  GALLERYDIR => $gD,
                  GALLERYLOCATION => $gL);
            } else {
              $item = TiVo::Container->new(
                  PATH => $path,
                  SERVICE => $service);
            }
            $self->log(6, "New Container created.");
        }
        if (!$item) {return undef;}

    # Create a file item
    } elsif( -r $path ) {
      $self->log(6, "creating file item");

      my $class = "TiVo::Item::$suffix";

      if ($self->_UseGallery == 1 && $useCodeRef == 1)  {
        $self->log(6, "File is a gallery object.");
        $item = eval{ $class->new( $path, $service, $codeRef, $gD, $gL ); } || return undef;
      } else {
        $item = eval{ $class->new( $path, $service ); } || return undef;
      }
      $item->_CacheDir = $self->_CacheDir;
      $item->_ImageDir = $self->_ImageDir;
      $item->_Logger = $self->_Logger;

    }

  }

  $self->log(6, "returning item: $item");

  return $item || undef;

}



=head2 TiVo::Server->add_service( $ )

Adds a TiVo::Container object to the service list for this server.

=cut

sub add_service {
  my $self = shift;
  my $service = shift || return undef;

  $self->_Services->{ $service->_Object } = $service;
  $self->freeze($service);

  $self->log(5, "adding service");

  return $self->_Services->{ $service->_Object };

}



=head2 TiVo::Server->request( $ $ $ )

Processes a client request and returns the output from the appropriate
command method. The return value is a list: first element
is a scalar containing the mime-type of the returned data, second
element is a reference to the data itself. Both scalar refs and
IO::File refs may be returned, so the calling application must check
for and support both types.

=cut

sub request {
  my $self = shift;

  my $params = shift || return undef;
  $self->log(5, "request: params are $params.");

  # Use a passed TiVo::Request object if given or
  # create a TiVo::Request object from arguments if needed
  if( (ref $params) !~ /^TiVo::Request/ ) {

    # See TiVo::Request for the proper syntax of these arguments
    my $script_name = $params;
    my $path_info = shift;
    my $query_string = shift;

    $params = TiVo::Request->new($script_name, $path_info, $query_string);

  }

  # File transfer requested? (binary output)
  if( defined( $params->_EnvPathInfo ) && $params->_EnvPathInfo ) {

    $self->log(5, "Binary transfer requested.");

    my $path_info = $self->uri_unescape($params->_EnvPathInfo);

    my $item = $self->thaw($path_info) || return undef;

    my($headers, $ref) = $item->send($params, $self);
    # Don't cache stuff that has been rotated!
    #if (defined($params->_Rotation) ||
    #     (defined($item->_CurrentRotation) && $item->_CurrentRotation != 0)) {
    if (defined($params->_Rotation))  {
      $self->store_cache($item);
    }

    return ($headers, $ref);

  # Command given? (xml output)
  } else {
    my $path_info = $self->uri_unescape($params->_EnvPathInfo);

    my $command = uc( $params->_Command ) || 'QUERYCONTAINER';

    # Create and eval the method name dynamically
    my $method = "command_$command";
    my $response = eval { $self->$method($params); };

    # Call command_UNKNOWN if the eval failed
    if( !defined $response ) {
      $response = $self->command_UNKNOWN($@);
    }

    # Set the default mime-type to be returned
    my $mime_type = 'text/xml';

    # Check to see if clint requested a different format
    if( defined( $params->_Format ) ) {
      $mime_type = $params->_Format;

      # If text/html was requested, simply display the xml as plaintext
      if( $mime_type eq 'text/html' ) {
        $mime_type = 'text/plain';
      }

    }

    my $xml = $self->xml_out($response) || return undef;

    # Wrap XML with header and footer
    my $return = "<?xml version='1.0' encoding='ISO-8859-1' ?>\n";
    $return .= $xml;
    $return .= "<!-- Copyright (c) 2002 TiVo Inc.-->\n";

    my $headers = {
      'Content-Type'	=> $mime_type,
      'Content-Length'	=> length $return
    };

    return ($headers, \$return );

  }

    my $response = $self->command_QUERYCONTAINER($params);



  return undef;

}



=head2 TiVo::Server->xml_out( $ [$] )

Converts a referenced hash/array data structure to XML. Use array
references to pass keys when order of the resulting XML tags
is important. Keys passed in a hash reference will have no
predictable ordering.

=cut

sub xml_out {
  my $self = shift;

  my $data = shift || return undef;
  my $indent = shift || 0;

  my $return;

  my @keys;

  my $data_type = ref $data;

  # Process each key if the passed reference was a hash
  if( $data_type eq 'HASH' ) {

    foreach my $key ( keys %$data ) {

      # Force undef values to empty strings before printing
      $data->{$key} = "" unless defined($data->{$key});

      my $key_type = ref($data->{$key});

      # Recurse again if the child key is another hash
      if($key_type eq 'HASH') {

        $return .= ' ' x $indent . "<$key>\n";
        $return .= $self->xml_out($data->{$key}, $indent + 2) || "";
        $return .= ' ' x $indent . "</$key>\n";

      # Recurse on each element if the child key is an array
      } elsif($key_type eq 'ARRAY') {

        $return .= ' ' x $indent . "<$key>\n";
        foreach my $item ( @{ $data->{$key} } ) {
          $return .= $self->xml_out($item, $indent + 2) || "";
        }
        $return .= ' ' x $indent . "</$key>\n";

      # Assume the child is a text node otherwise, and print
      } else {
        $return .= ' ' x $indent . "<$key>" . $data->{$key} . "</$key>\n";
      }

    }

  # Recurse on each element if the passed ref is an array
  } elsif( $data_type eq 'ARRAY' ) {

    foreach my $item ( @$data ) {
      $return .= $self->xml_out($item, $indent);
    }

  # What's this? Print it and hope for the best
  } else {
     $return .= "$data\n";
  }

  return $return;

}



=head2 TiVo::Server->command_QUERYSERVER( $ )

Generates response to QueryServer command
Expects to be passed a TiVo::Request object
Returns data structure suitable for use with xml_out

=cut

sub command_QUERYSERVER {
  my $self = shift;
  my $params = shift;

  my $return = {
    'TiVoServer' => {
      'Version'         => $self->VERSION,
      'InternalVersion' => $self->INTVERSION,
      'InternalName'    => $self->INTNAME,
      'Organization'    => $self->_Organization || $self->ORGANIZATION,
      'Comment'         => $self->_Comment || $self->COMMENT
    }
  };

  return $return;

}



=head2 TiVo::Server->command_QUERYCONTAINER( $ )

Generates response to QueryContainer command
Expects to be passed a TiVo::Request object
Returns data structure suitable for use with xml_out

=cut

sub command_QUERYCONTAINER {
  my $self = shift;
  my $params = shift;

  $self->log(5, "command_QUERYCONTAINER: params are $params");

  my $container = $params->_Container;

  # Return service containers unless otherwise requested
  $container = '/' unless defined $container;

  my $object = $self->thaw($container) || return undef;

  my @list;

  if( defined($params->_Recurse) && uc($params->_Recurse) eq 'YES' ) {

    # Explode the content list and get a recursive flat list of objects
    @list = @{ $object->explode($self) };

  } else {

    # Take the top-level list of objects and remove any subfolder list refs
    $self->log(6, "about to get contents.");
    @list = @{ $object->contents($self) };
    $self->log(6, "got contents.");

    @list = grep { ref($_) ne 'ARRAY' } @list;

    $self->log(6, "got rid of objects in contents.");
  }

  # Apply any requested filters
  if( defined($params->_Filter) ) {
    $self->log(6, "filtering...");

    my %types;
    my @filters;

    if( $params->_Filter =~ /,/ ) {
      @filters = split(/,/, $params->_Filter);
    } else {
      @filters = ( $params->_Filter );
    }

    # Construct a list of every possible matching type instead
    # of matching against each object's SourceFormat individually
    my $possible_types =  $object->_Service->_MediaTypes;
    $possible_types->{'FOLDER'} = 'x-container/folder';

    foreach my $filter ( @filters ) {

      my($major, $minor) = split(/\//, $filter);

      $major = $major || '*';
      $minor = $minor || '*';

      # Compare the filter to each supported MediaType for this service
      foreach my $supported ( keys %$possible_types ) {

        my($s_major, $s_minor) =
          split(/\//, $possible_types->{$supported});

        if( ( $major eq $s_major || $major eq '*' ) &&
            ( $minor eq $s_minor || $minor eq '*' )
          ) {

          $types{"$s_major/$s_minor"} = 1;

        }

      }

    }

    @list = grep { defined( $types{$_->_SourceFormat} ) } @list;
  }

  my $total_duration = 0;

  $self->log(6, "doing duration stuff.");
  # Check for any audio files that passed the Filter and sum their Duration
  foreach ( @list ) { 
    if( defined($_->_Duration) ) {
      $total_duration += $_->_Duration;
    }
  }

  # Perform any requested sorts. Currently incomplete, only supports Random
  # and Type,Title
  if( defined( $params->_SortOrder ) ) {

    if( uc($params->_SortOrder) eq 'RANDOM' ) {

      # Remove RandomStart from the object list before sorting
      my $start;
      if( defined( $params->_RandomStart ) ) { 

        my $prefix = $params->_EnvScriptname;

        my $short_start = $params->_RandomStart;
        $short_start =~ s/^$prefix//;

        foreach my $i ( 0 .. $#list ) {

          next unless defined $list[$i]->_Url;
          next unless $list[$i]->_Url eq $short_start;

          $start = splice(@list, $i, 1);
          last;

        }

      }

      srand( $params->_RandomSeed ) if defined $params->_RandomSeed;

      my $i;
      if (scalar(@list) > 0)  {
        for( $i = @list; --$i; ) {
          my $j = int rand ( $i + 1 );
          next if $i == $j;
          @list[$i,$j] = @list[$j,$i];
        }
      }

      # Reattach RandomStart as the first object
      unshift(@list, $start) if defined $start;

    } else {

      @list = sort {
        return -1 if (ref $a) =~ /^TiVo::Container/ && (ref $b) =~ /^TiVo::Item/;
        return 1 if (ref $b) =~ /^TiVo::Container/ && (ref $a) =~ /^TiVo::Item/;
	if ($a->_Track && $b->_Track) {
	  return $a->_Track <=> $b->_Track;;
	}
        return lc($a->_Title) cmp lc($b->_Title);
      } @list;
    }

  }


  my $count = scalar @list || 0;

  # Anchor defaults to first item
  my $anchor_pos = 0;

  if( defined($params->_AnchorItem) ) {

    my $prefix = $params->_EnvScriptname;

    my $short_anchor = $params->_AnchorItem;
    $short_anchor =~ s/^$prefix//;

    foreach my $i ( 0 .. $#list ) {

      next unless defined $list[$i]->_Url;
      next unless $list[$i]->_Url eq $short_anchor;

      $anchor_pos = $i + 1;
      last;

    }

    # Adjust the anchor position if a positive or negative offset is given
    if( defined( $params->_AnchorOffset ) ) {

      my $anchor_offset = $params->_AnchorOffset || 0;
      $anchor_pos += $anchor_offset;

    }

  }

  # Trim return list, if requested
  if( defined($params->_ItemCount) ) {

    my $count = $params->_ItemCount;

    # Wrap the pointer if a negative count is requested
    if( $count < 0 ) {

      $count *= -1;
 
      # Jump to end of list if no Anchor is provided 
      if( defined($params->_AnchorItem) ) {
        $anchor_pos -= $count + 1;
      } else {
        $anchor_pos = $#list - $count + 1;
      }

    }

    # Check for under/overflow
    if( $anchor_pos >= 0 && $anchor_pos <= $#list ) {

      @list = splice(@list, $anchor_pos, $count);

    } else {

      $anchor_pos = 0;
      undef @list;

    }

  }

  # Build description of each item to be returned
  my @children;
  foreach my $child ( @list ) {
    push(@children, $child->query_container($params));

  }

  my $return = {
    'TiVoContainer' => [
      { 'Details' => {
        'Title'         => $object->_Title,
        'ContentType'   => $object->_ContentType || 'x-container/folder',
        'SourceFormat'  => $object->_SourceFormat || 'x-container/folder',
        'TotalItems'    => $count,
        'TotalDuration' => $total_duration
      } },
      { 'ItemStart' => $anchor_pos },
      { 'ItemCount' => scalar @children || 0 },
      \@children
    ]
  };

  return $return;

}



=head2 TiVo::Server->command_UNKNOWN( $ )

Generates response to Unknown commands
Expects to be passed a TiVo::Request object
Returns data structure suitable for use with xml_out

=cut

sub command_UNKNOWN {
  my $self = shift;
  my $params = shift;

  return {};

}


##############################################################################

=head1 TiVo::Container

Attaches TiVo methods to a particular directory

=cut

package TiVo::Container;
use base qw(TiVo);


=head2 TiVo::Container->new( % )

Generic TiVo::Container constructor
Accepts parameters via an argument hash.
Expects to be passed a full pathname and either a string describing
the service prefix (if this container is to be a service) or another
TiVo::Container object (if this container is to be a subdirectory
of an existing service). 

=cut

sub new {
  my $class = shift;

  my $self = {};
  bless $self, $class;

  my %params = ( @_ );

  my $service = $params{'SERVICE'} || return undef;
  $self->_Path = $params{'PATH'};

  # This container is an M3U playlist.
  if ( (ref $service) =~ /^TiVo::Container::M3U/) {
    $self->_Object = $service->path_to_obj($self->_Path) || return undef;
    $self->_Service = $service;
  # This container is a Gallery.
  } elsif( (ref $self) =~ /^TiVo::Container::Gallery$/)  {
    $self->_Service = $service;
    $self->_GalleryDir = $params{'GALLERYDIR'} || return undef;
    $self->_GalleryLocation = $params{'GALLERYLOCATION'} || return undef;
    my $gD = $params{'GALLERYDIR'};
    $gD =~ s#^(.*)(?:/)*$#$1#;
    if ($self->_Path =~ /^(?:$gD)(.*)$/)  {
        $self->_Object = $self->_GalleryLocation . $1;
    }
  } elsif( (ref $self) =~ /^TiVo::Container::GalleryAlbum$/)  {
    $self->_Service = $service;
    $self->_GalleryDir = $params{'GALLERYDIR'};
    $self->_GalleryLocation = $params{'GALLERYLOCATION'};
    my $localCR = $params{'CODEREF'};
    $self->_Object = &$localCR(\$self) || return undef;
  # This container is a subdirectory
  } elsif( (ref $service) =~ /^TiVo::Container/ ) {

    $self->_Object = $service->path_to_obj($self->_Path) || return undef;
    $self->_Service = $service;

  # This container is a service container
  } else {

    $self->_Object = $service;
    $self->_Service = $self;

  }

  # Set folder title, if provided
  $self->_Title = $params{'TITLE'};

  # Defaults common to all Containers
  $self->_SourceFormat = 'x-container/folder';
  $self->_Url = '?Command=QueryContainer&Container=' .
                 $self->uri_escape( $self->_Object );

  # Call class-specific init method
  $self->init || return undef;

  return $self;

}



=head2 TiVo::Container->init( )

Generic TiVo::Container initialization

=cut

sub init {
  my $self = shift;

  $self->_ContentType = 'x-container/folder';

  unless ($self->_Title) {
     my $title = $self->basename;
     $title =~ s/_/ /g;

     $self->_Title = $title;
  }

  return 1;

}

=head2 TiVo::Container->path_to_obj( $ )

Converts the given pathname to an object path relative to the
current service

=cut

sub path_to_obj {
  my $self = shift;
  my $path = shift || return undef;

  my $service_p = $self->_Path;
  my $service_o = $self->_Object;

  $path =~ s/^$service_p/$service_o/;

  return $path;

}




=head2 TiVo::Container->obj_to_path( $ )

Converts the given object path (relative to the current service) to
a full filesystem pathname

=cut

sub obj_to_path {
  my $self = shift;
  my $path = shift || return undef;

  my $service_p = $self->_Path;
  my $service_o = $self->_Object;

  $path =~ s/^$service_o/$service_p/;

  return $path;

}



=head2 TiVo::Container->contents( $ )

Returns the contents of a TiVo::Container directory as a list ref
of Item and Container objects.

=cut

sub contents {
  my $self = shift;
  my $server = shift;
  $server->log(5, "TiVo::Container->contents (generic)");

  return $self->_Contents if defined $self->_Contents;

  my @contents;

  local *DIR;
  opendir(DIR, $self->_Path) || return undef;

  # Schwartzian transform to sort the list by dir/file then alphabetically
  my @entries =
    map { $_->[0] }
       sort { $a->[1].$a->[0] cmp $b->[1].$b->[0] }
          map { [ $_, !-d ] }
            readdir(DIR);

  closedir(DIR);

  if ($server->_UseGallery == 1 && $server->_GalleryLocation =~ /^(.*)\/(.*?)$/)  {
      $server->log(6, "checking for gallery: 1 is $1, 2 is $2, dirname is " . $self->_Service->path_to_obj($self->_Path));
      if ($self->_Service->path_to_obj($self->_Path) eq $1)  {
          @entries = ($2, @entries);
      }
  }

  foreach my $file (@entries) {
    next if $file =~ /^\./;

    if( defined $server ) {
      $server->log(6, "Server is defined.");

      my $object_path = $self->_Object . "/" . $file;
      $server->log(6, "Thawing object $object_path...");
      my $child = $server->thaw($object_path) || next;
      $server->log(6, "Thawed object $object_path...");

      push(@contents, $child);

    } else {
      $server->log(6, "Server is not defined.\n");

      my $full_path = $self->_Path . "/" . $file;

      if( -d $full_path ) {

        my $child = TiVo::Container->new(
          PATH => $full_path,
          SERVICE => $self->_Service
        ) || next;

        push(@contents, $child);

      } elsif( -r $full_path ) {

        my @parts = split(/\./, $full_path);
        my $suffix = uc( pop @parts);
  
        my $class = "TiVo::Item::$suffix";
        my $child = eval{ $class->new( $full_path, $self->_Service ); } || next;

        push(@contents, $child);

      }

    }
  }

  # Cache the new information we just built
  $self->_Contents = \@contents;
  $server->freeze($self) if defined $server;

  return \@contents;

}

=head2 TiVo::Container->explode( $ )

Converts the single-directory Container and Item list format of an
object's contents() to a recursive list of all Containers and Items.

=cut

sub explode {
  my $self = shift;
  my $server = shift;

  my $list = $self->contents($server);

  my @return;

  foreach my $item ( @$list ) {

    if( (ref $item) =~ /^TiVo::Container/ ) {

      # Fetch the most current copy of this item from Cache
      $item = $server->thaw($item->_Object) || next;

      push(@return, $item);
      push(@return, @{ $item->explode($server) } );

    } else {

      push(@return, $item);

    }

  }

  return \@return;

}



package TiVo::Container::Server;
use base qw(TiVo::Container);

=head2 TiVo::Container::Server->init( )

Defines a Server psuedo-container which overrides the generic init
method. Sets content types unique to a Server container;

=cut

sub init {
  my $self = shift;

  $self->_Object = "/";
  $self->_Service = "/";

  $self->_ContentType = 'x-container/tivo-server';

  $self->_Title = $self->_Title || "TiVo Server";

  return 1;

}



# TiVo::Container extension
package TiVo::Container::Music;
use base qw(TiVo::Container);

=head2 TiVo::Container::Music->init( )

Defines a Music container which overrides the generic init
method. Sets content and media types unique to a 'Music'
container.

=cut

sub init {
  my $self = shift;

  $self->_ContentType = 'x-container/tivo-music';

  # Media types accepted for this container.
  # When creating a handler for a new media type, be sure to
  # register it with the appropriate service via:
  #   $service->_MediaTypes->{'NewSuffix'} = 'mime/type';
  #
  $self->_MediaTypes = {
    'MP3'  => 'audio/mpeg',
    'WAV'  => 'audio/wav',
    'PLS'  => 'audio/scpls',
    'M3U'  => 'audio/mpegurl',
    'OGG'  => 'audio/x-ogg'
  };

  $self->_Title = $self->_Title || "Music";

  return 1;
}



# TiVo::Container extension
package TiVo::Container::Photos;
use base qw(TiVo::Container);

=head2 TiVo::Container::Photos->init( )

Defines a Photo container which overrides the generic init
method. Sets content and media types unique to a 'Photos'
container.

=cut

sub init {
  my $self = shift;

  $self->_ContentType = 'x-container/tivo-photos';

  # Media types accepted for this container.
  # When creating a handler for a new media type, be sure to
  # register it in the appropriate service with:
  #   $service->_MediaTypes->{'NewSuffix'} = 'mime/type';
  #
  $self->_MediaTypes = {
    'JPG'  => 'image/jpeg',
    'PNG'  => 'image/png',
    'GIF'  => 'image/gif'
  };

  $self->_Title = $self->_Title || "Photos";

  return 1;

}




##############################################################################
=head1 TiVo::Item

Attaches TiVo methods to a particular file

=cut


package TiVo::Item;
use base qw(TiVo);

=head2 TiVo::Item->new( $ $ & $ $ )

Constructor for generic TiVo::Item
Expects to be passed a full pathname and a TiVo::Container service
to pull container information from
If it is passed a code segment, that part is done in the middle instead of
stuff having to do with the service.  The GalleryDir and GalleryLocation
are passed after that.

=cut

sub new {
  my $class = shift;

  my $self = {};
  bless $self, $class;

  $self->_Path = shift || return undef;
  $self->_Service = shift || return undef;

  # use the file suffix to determine file type
  my @parts = split(/\./, $self->_Path);
  my $suffix = uc( pop @parts);

  # Skip this file if the service doesn't claim to support it
  return undef unless defined $self->_Service->_MediaTypes;

  $self->_SourceFormat = $self->_Service->_MediaTypes->{$suffix} || return undef;

  my $codeRef = shift;
  if (not $codeRef)  {
    $self->_Object = $self->_Service->path_to_obj($self->_Path) || return undef;
  } else {
    $self->_GalleryDir = shift;
    $self->_GalleryLocation = shift;
    $self->_Object = &$codeRef(\$self);
  }
  $self->_Url = $self->uri_escape($self->_Object);

  # Contruct ContentType from SourceFormat
  my $content_type = $self->_SourceFormat;
  $content_type =~ s/\/.*$/\/\*/;

  $self->_ContentType = $content_type;

  # Call class-specific init method
  $self->init || return undef;

  return $self;

}


=head2 TiVo::Item->init( )

Generic TiVo::Item initialization

=cut

sub init {
  my $self = shift;

  return 1;

}



=head2 TiVo::Item->send( )

Generic TiVo::Item file transfer

=cut

sub send {
  my $self = shift;

  require IO::File;

  my $handle = IO::File->new($self->_Path);

  my $headers = {
    'Content-Type'	=> $self->_SourceFormat,
    'Content-Length'	=> $self->_SourceSize
  };

  return($headers, $handle);

}

######################################################################
# TiVo::Container extension

package TiVo::Container::Gallery;
use base qw(TiVo::Container);

sub init {
    my $self = shift;

    my $gD = $self->_GalleryDir;
    $self->_ContentType = 'x-container/folder';
    # TODO - make title a configuration option?
    #$self->_Title = 'Gallery';
    if ($self->_GalleryLocation =~ /^.*\/(.*?)$/)  {
        my $newTitle = $1;
        $newTitle =~ s/_/ /g;
        $self->_Title = $newTitle;
    }

    $self->_Entries = [];
    $self->_LastEntry = "FAIL";
    my @entries = ();
    if ($self->_Path =~ /^(?:$gD)(?:\/)*$/)  {
        # We have the root-level gallery.  This should always be true.
        $self->_LastEntry = "LOOP1";
        open ALBUMDB, ($gD . "/albumdb.dat");
        while(<ALBUMDB>)  {
            $self->_LastEntry = "LOOP2";
            if (/^a:(\d+).*?{(.*)}\S*$/)  {
                $self->_LastEntry = "LOOP3";
                my $numAlbums = $1;
                my $data = $2;
                my $i;
                for ($i = 0; $i < $numAlbums; $i++)  {
                    $self->_LastEntry = "LOOP4";
                    if ($data =~ /^.*?"(.*?)"(.*)$/)  {
                        @entries = (@entries, $1);
                        $data = $2;
                        $self->_LastEntry = $1;
                    }
                }
            }
        }
        close ALBUMDB;
    
    } else {
        return undef;
    }
    $self->_Entries = \@entries;

    return 1;
}

sub query_container {
  my $self = shift;
  my $params = shift;

  my $script_name = $params->_EnvScriptName || "";

  my $details = {
    'Item' => [
      {
        'Details' => {
          'Title'        => $self->_Title,
          'ContentType'  => $self->_ContentType,
          'SourceFormat' => $self->_SourceFormat,
	  'LastChangeDate'=> $self->_LastChangeDate,
        }
      },
      {
        'Links' => {
          'Content' => {
            'Url'      => $script_name . $self->_Url,
          }
        }
      }
    ]
  };

  return $details;

}

sub contents {
    my $self = shift;
    my $server = shift;

    $server->log(5, "gallery contents() called.");

    return $self->_Contents if defined $self->_Contents;

    $server->log(6, "result not cached.");

    $server->log(6, "self->_Object is " . $self->_Object . ", self->_Path is " . $self->_Path);
    my $gD = $self->_GalleryDir;
    my $gL = $self->_GalleryLocation;

    if ($self->_Path =~ /^(?:$gD)(?:\/)*$/)  {
        $server->log(6, "self->_LastEntry is " . $self->_LastEntry);
        my $entryRef = $self->_Entries;
        my $entry;
        my @contents = ();
        foreach $entry (@$entryRef)  {
            $server->log(6, "Entry: $entry");
            my $child = $server->thaw($gL . "/" . $entry);
            push (@contents, $child);
        }

        $self->_Contents = \@contents;
        $server->freeze($self) if defined $server;

        return \@contents;
    }

    return 1;
}

######################################################################
# TiVo::Container extension
package TiVo::Container::GalleryAlbum;
use base qw(TiVo::Container);

sub init {
    my $self = shift;

    my $gD = $self->_GalleryDir;
    $self->_ContentType = 'x-container/folder';
    $self->_Entries = [];
    $self->_LastEntry = "FAIL";
    open ALBUMDAT, ($self->_Path . "/album.dat");
    while(<ALBUMDAT>)  {
        my $data = $_;
        if (/^.*?"fields".*?"title".*?"(.*?)"(.*)/)  {
            # TODO - can use $restOfData to get more information about album.
            my $restOfData = $2;
            $self->_Title = $1;
        }
    }
    close ALBUMDAT;

    my @entries = ();
    $self->_LastEntry = "LOOP1";
    open PHOTOSDAT, ($self->_Path . "/photos.dat");
    while(<PHOTOSDAT>)  {
        $self->_LastEntry = "LOOP2";
        if (/^a:(\d+).*?{(.*)}\S*$/)  {
            $self->_LastEntry = "LOOP3";
            my $numPhotos = $1;
            my $data = $2;
            my $i;
            for ($i = 0; $i < $numPhotos; $i++)  {
                $self->_LastEntry = "LOOP4";
                if (($i != $numPhotos - 1 && $data =~ /.*?"albumitem"(.*?)("albumitem".*)$/) ||
                    ($i == $numPhotos - 1 && $data =~ /.*?"albumitem"(.*)$/))  {
                    my $curEntry = $1;
                    if ($i != $numPhotos - 1)  {
                        $data = $2;
                    }
                    if ($curEntry =~/^.*?"name".*?"(.*?)".*?"type".*?"(.*?)"/) {
                        @entries = (@entries, "$1.$2");
                        $self->_LastEntry = "$1.$2";
                    }
                }
            }
        }
    }
    close PHOTOSDAT;

    $self->_Entries = \@entries;

    return 1;
}

sub query_container {
  my $self = shift;
  my $params = shift;

  my $script_name = $params->_EnvScriptName || "";

  my $details = {
    'Item' => [
      {
        'Details' => {
          'Title'        => $self->_Title,
          'ContentType'  => $self->_ContentType,
          'SourceFormat' => $self->_SourceFormat,
	  'LastChangeDate'=> $self->_LastChangeDate,
        }
      },
      {
        'Links' => {
          'Content' => {
            'Url'      => $script_name . $self->_Url,
          }
        }
      }
    ]
  };

  return $details;

}

sub contents {
    my $self = shift;
    my $server = shift;

    $server->log(5, "galleryalbum contents() called.");

    return $self->_Contents if defined $self->_Contents;

    $server->log(6, "result not cached.");

    $server->log(6, "self->_Object is " . $self->_Object . ", self->_Path is " . $self->_Path);
    my $gD = $self->_GalleryDir;
    my $gL = $self->_GalleryLocation;

    $server->log(6, "self->_LastEntry is " . $self->_LastEntry, ", self->_GalleryLocation is $gL");
    my $entryRef = $self->_Entries;
    my @contents = ();
    my $entry;
    foreach $entry (@$entryRef)  {
        $server->log(6, "Entry: $entry");
        my $child = $server->thaw($self->_Object . "/" . $entry);
        push (@contents, $child);
    }

    $self->_Contents = \@contents;
    $server->freeze($self) if defined $server;

    return \@contents;
}


######################################################################
# TiVo::Container extension
# TBD - Fix this!

package TiVo::Container::M3U;
use base qw(TiVo::Container);

sub init {
  my $self = shift;

  $self->log(6, "M3U->init() called.");

  require MP3::M3U::Parser;

  my $m3u = MP3::M3U::Parser->new(-file => $self->basename,
				  -path => $self->dirname,
				  -type => "file");

  $self->log("basename is " . $self->basename . ", dirname is " . $self->dirname);

  #if (!defined $m3u) {
  #  print "not defined!";
  #}

  return undef unless defined $m3u;

  my $parsed_m3u = $m3u->parse();
  $self->log("p_m3U is: " . $parsed_m3u);

  return undef unless $parsed_m3u;

  my $basename = $self->basename;
  $basename =~ s/.m3u$//i;

  $self->_parsedM3U = \$parsed_m3u->{$basename};

  $self->log(6, "parsedM3U is: " . ((${$self->_parsedM3U}) ? (${$self->_parsedM3U}) : "undefined!"));

  my %info = $m3u->info();

  return undef unless %info;

  $self->log(6, "got info.");

  $self->_info = \%info;
  $self->log(6, "still have info.");

  # Give this a nice name

  my $pretty_name = $basename;
  $pretty_name =~ s/_/ /g;


  $self->_Title = $pretty_name;
  $self->_ContentType = "x-container/playlist";
  $self->_SourceFormat = "audio/mpegurl";

  # Get timestamps and size if the file referenced by Path exists
  if( stat($self->_Path) ) {

    $self->_SourceSize = -s $self->_Path;

    my $change_date = ( stat(_) )[9];
    my $access_date = ( stat(_) )[8];

    $change_date = sprintf("0x%x", $change_date);
    $access_date = sprintf("0x%x", $access_date);

    # *nix does not seem to have a portable "creation date" stamp.
    # Using last change date, instead.
    $self->_CreationDate = $change_date;
    $self->_LastChangeDate = $change_date;
    $self->_LastAccessDate = $access_date;
  }
  $self->log(6, "About to get duration...");
  $self->_Duration = $info{"ttime"};
  if ($self->_Duration == 0) {
    $self->_Duration = -1;
  }
  $self->log(6, "M3U parsed - duration is " . $self->_Duration);

  return 1;
}


sub query_container {
  my $self = shift;
  my $params = shift;

  my $script_name = $params->_EnvScriptName || "";

  my $details = {
    'Item' => [
      {
        'Details' => {
          'Title'        => $self->_Title,
          'ContentType'  => $self->_ContentType,
          'SourceFormat' => $self->_SourceFormat,
	  'LastChangeDate'=> $self->_LastChangeDate,
        }
      },
      {
        'Links' => {
          'Content' => {
            'Url'      => $script_name . $self->_Url,
          }
        }
      }
    ]
  };

  return $details;

}

sub trueentries {
  my $self = shift;
  my $server = shift;

  $server->log(5, "M3U trueentries() called.");

  return $self->_TrueEntries if defined $self->_TrueEntries;

  $server->log(6, "result not cached.");

  $self->contents($server);
  return $self->_TrueEntries;
}

sub contents {
  my $self = shift;
  my $server = shift;

  $server->log(5, "M3U contents() called.");

  return $self->_Contents if defined $self->_Contents;

  $server->log(6, "result not cached.");

  my @contents;
  my @pM3U = @{${$self->_parsedM3U}};
  $server->log(6, "got pM3U");

  my $count = 0;
  my $entry;
  $server->log(6, "pM3U has " . scalar(@pM3U) . " entries.");
  $self->_TrueEntries = [];
  $server->log(6, "te is: " . @{$self->_TrueEntries});
  foreach $entry (@pM3U)  {
    my @entry = @$entry;
    $server->log(6, "Top of entry loop.  Entry is " . $$entry[0] . " ". $$entry[1] . " " . $$entry[2]);

    if ($$entry[2] !~ /^\// && $$entry[2] !~ /^http:\/\//)  {
        # Filename doesn't start with '/' or 'http://', so it's a relative path.
        # TODO - add ability to use strings like '../Song.mp3'
        $server->log(6, "Using relative path!  From " . $$entry[2] . " to " . $self->dirname() . '/' . $$entry[2]);
        $$entry[2] = $self->dirname() . '/' . $$entry[2];
    }
    my $relativePath = $self->_Service->path_to_obj($$entry[2]);
    $server->log(6, "relativePath is " . $relativePath);
    my $child = $server->thaw($relativePath);
    # TODO - use a ref or something to determine the class of $child.
    if ($$entry[2] =~ /^http:\/\//)  {
        $child->_Title = $$entry[0];
    } else {
      $server->log(6, "thawed ok.");
      $server->log(6, "self's url is " . $self->_Url .  ", count is " . $count . ", self's path is " . $self->_Path . ", child is " . $child);
      $child->_Url = $self->path_to_obj($self->_Path . "/" . $count);
      $server->log(6, "going to set trueentries.");
      my @entryToUse = ($$entry[0], $$entry[1], $$entry[2]);
      $self->_TrueEntries->[$count] = \@entryToUse;
      $count++;
    }
    #$child->_Url = $self->_Url . "/" . $count;
    $server->log(6, "Adding entry: count is $count, name is " . $$entry[2] . ", url is " . $child->_Url);
    
    push (@contents, $child);
  }

  # Cache the result.
  $self->_Contents = \@contents;
  $server->freeze($self) if defined $server;

  return \@contents;

}


######################################################################
# TiVo::Item extension

package TiVo::Item::MP3;
use base qw(TiVo::Item);


=head2 TiVo::Item::MP3->init( )

Overrides generic init method for TiVo::Item and includes MP3
specific fields

=cut

sub init {
  my $self = shift;

  require MP3::Info;

  my $tag = MP3::Info::get_mp3tag($self->_Path);
  my $info = MP3::Info::get_mp3info($self->_Path);

  return undef unless defined $info;

  $self->_SourceBitRate = sprintf("%d", $info->{'BITRATE'} * 1000) || 0;
  $self->_SourceSampleRate = sprintf("%d", $info->{'FREQUENCY'} * 1000) || 0;
  $self->_Duration = sprintf("%d", ( $info->{'SECS'} * 1000 )) || 0;

  $self->_Genre = $tag->{'GENRE'} || "";
  $self->_Artist = $tag->{'ARTIST'} || "";
  $self->_Album = $tag->{'ALBUM'} || "";
  $self->_Year = $tag->{'YEAR'} || "";
  $self->_Track = $tag->{TRACKNUM};
  $self->_Title = $tag->{'TITLE'} || $self->basename;

  # Get timestamps and size if the file referenced by Path exists
  if( stat($self->_Path) ) {

    $self->_SourceSize = -s $self->_Path;

    my $change_date = ( stat(_) )[9];
    my $access_date = ( stat(_) )[8];

    $change_date = sprintf("0x%x", $change_date);
    $access_date = sprintf("0x%x", $access_date);

    # *nix does not seem to have a portable "creation date" stamp.
    # Using last change date, instead.
    $self->_CreationDate = $change_date;
    $self->_LastChangeDate = $change_date;
    $self->_LastAccessDate = $access_date;
  }

  return 1;

}



=head2 TiVo::Item::MP3->query_container

Returns a data structure suitable for use with xml_out which
describes this object in response to a QueryContainer command

=cut

sub query_container {
  my $self = shift;
  my $params = shift;

  my $script_name = $params->_EnvScriptName || "";
  my $track_name = $self->_Title;

  $track_name =~ s/_/ /g;
  $track_name =~ s/%20/ /g;

  if ($self->_Track) {
    $track_name = sprintf("%d.  %s", $self->_Track, $track_name);
  }

  my $details = {
    'Item' => [
      {
        'Details' => {
          'Title'        => $track_name,
          'ContentType'  => $self->_ContentType,
          'SourceFormat' => $self->_SourceFormat,
          'ArtistName'   => $self->_Artist,
          'SongTitle'    => $self->_Title,
          'AlbumTitle'   => $self->_Album,
          'AlbumYear'    => $self->_Year,
	  'AlbumTrack'   => $self->_Track,	      
          'MusicGenre'   => $self->_Genre,
          'Duration'     => $self->_Duration,
	  'RecordLabel'  => '',
        }
      },
      {
        'Links' => {
          'Content' => {
            'Url'      => $script_name . $self->_Url,
            'Seekable' => 'Yes'
          }
        }
      }
    ]
  };

  return $details;

}



=head2 TiVo::Item::MP3->send( $ )

TiVo::Item send extension supporting MP3 seeking

=cut

sub send {
  my $self = shift;
  my $params = shift;
  my $server = shift;

  require IO::File;

  my $handle = IO::File->new($self->_Path);
  my $length = $self->_SourceSize;

  if( defined $params->_Seek ) {

    my $seek_ms = $params->_Seek;
    my $seek_offset = sprintf("%d", ( $seek_ms / $self->_Duration ) * $self->_SourceSize );

    seek($handle, $seek_offset, 0);

    $length = $length - $seek_offset;
  }

  my $headers = {
    'Content-Type'		=> $self->_SourceFormat,
    'Content-Length'		=> $length,
    'TivoAccurateDuration'	=> $self->_Duration
  };

  return($headers, $handle);

}


=head1 TiVo::Item::HttpStream

TiVo::Item extension - for external URLs (Internet radio)

=cut

package TiVo::Item::HttpStream;
use base qw(TiVo::Item);

sub new {
  my $class = shift;
  my $self = {};
  bless $self, $class;

  $self->_Url = shift || return undef;
  $self->init || return undef;

  return $self;
}

sub init {
  my $self = shift;

  $self->log(5, "In init for HttpStream: " . $self->_Url);

  $self->_Title = 'testing stream';
  $self->_ContentType = 'audio/mpeg';
  $self->_SourceFormat = 'audio/mpeg';

  return 1;
}

sub query_container {
  my $self = shift;
  my $params = shift;

  my $details = {
    'Item' => [
      {
        'Details' => {
          'Title'       => $self->_Title,
          'ContentType' => $self->_ContentType,
          'SourceFormat'=> $self->_SourceFormat,
        }
      },
      {
        'Links' => {
          'Content' => {
            'Url'       => $self->_Url,
            'Seekable'  => 'No',
            'AcceptsParams' => 'No',
          }
        }
      }
    ]
  };

  return $details;
}



package TiVo::Item::OGG;
use base qw(TiVo::Item);

=head2 TiVo::Item::OGG->init( )

Overrides generic init method for TiVo::Item and includes OGG
specific fields

=cut

sub init {
  my $self = shift;

  my $oggfile = $self->_Path;

  require Ogg::Vorbis::Header::PurePerl;

  my $ogg = Ogg::Vorbis::Header::PurePerl->new($oggfile) ||
    return undef;

  my $info = $ogg->info();;
  my $comments = $ogg->comment_tags();

  $self->_SourceBitRate = 0;
  $self->_SourceSampleRate = 0;
  $self->_Duration = 0;

  $self->_SourceBitRate = sprintf("%d", $info->{bitrate_nominal} * 1000) || 0;
  $self->_SourceSampleRate = sprintf("%d", $info->{rate} * 1000) || 0;

  $self->_Duration = sprintf("%d", ( $info->{length} * 1000 )) || 0;

  ($self->_Title) =  $ogg->comment('title');
  ($self->_Genre) =  $ogg->comment('genre');
  ($self->_Artist) = $ogg->comment('artist');
  ($self->_Year) =   $ogg->comment('year');
  ($self->_Album) =  $ogg->comment('album');
  ($self->_Track) =  $ogg->comment('tracknumber');

  # Get timestamps and size if the file referenced by Path exists
  if( stat($self->_Path) ) {

    $self->_SourceSize = -s $self->_Path;

    my $change_date = ( stat(_) )[9];
    my $access_date = ( stat(_) )[8];

    $change_date = sprintf("0x%x", $change_date);
    $access_date = sprintf("0x%x", $access_date);

    # *nix does not seem to have a portable "creation date" stamp.
    # Using last change date, instead.
    $self->_CreationDate = $change_date;
    $self->_LastChangeDate = $change_date;
    $self->_LastAccessDate = $access_date;
  }
  return 1;
}

=head2 TiVo::Item::OGG->query_container

Returns a data structure suitable for use with xml_out which
describes this object in response to a QueryContainer command

=cut

sub query_container {
  my $self = shift;
  my $params = shift;

  my $script_name = $params->_EnvScriptName || "";

  my $details = {
    'Item' => [
      {
        'Details' => {
          'Title'        => $self->_Title,
          'ContentType'  => $self->_ContentType,
          'SourceFormat' => $self->_SourceFormat,
          'ArtistName'   => $self->_Artist,
          'SongTitle'    => $self->_Title,
          'AlbumTitle'   => $self->_Album,
          'MusicGenre'   => $self->_Genre,
          'Duration'     => $self->_Duration
        }
      },
      {
        'Links' => {
          'Content' => {
            'Url'      => $script_name . $self->_Url,
            'Seekable' => 'No'
          }
        }
      }
    ]
  };

  return $details;
}

=head2 TiVo::Item::OGG->send( $ )

TiVo::Item send extension supporting OGG seeking

We need to convert the ogg stream to an MP3 stream on the fly...
could be fun!

=cut

sub send {
  my $self = shift;
  my $params = shift;
  my $server = shift;

  require IO::File;

  my $filepath = $self->_Path;
  my $handle = IO::File->new("ogg123 -q -d wav $filepath -f - | lame --silent -f  -b 320 - - 2>/dev/null |");

  my $length = $self->_SourceSize;

### Seeking not supported on .ogg yet
#  if( defined $params->_Seek ) {
#
#    my $seek_ms = $params->_Seek;
#    my $seek_offset = sprintf("%d", ( $seek_ms / $self->_Duration ) * $self->_SourceSize );
#
#    seek($handle, $seek_offset, 0);
#
#    $length = $length - $seek_offset;
#  }

  my $headers = {
    'Content-Type'		=> 'audio/mpeg',
    #'Content-Length'		=> $length,
    'TivoAccurateDuration'	=> $self->_Duration
  };

  return($headers, $handle);
}

# TiVo::Item extension
package TiVo::Item::JPG;
use base qw(TiVo::Item);

=head2 TiVo::Item::JPG->init( )

Overrides generic init method for TiVo::Item and includes JPG
specific fields

=cut

sub init {
  my $self = shift;

  require Image::Magick;

  $self->log(5, "Calling JPG init with path: " . $self->_Path);

  my $img = new Image::Magick;
  $img->Read($self->_Path);

  return undef unless defined $img;

  my($width, $height, $depth) = $img->Get('width', 'height', 'depth');

  $self->_SourceWidth = $width || 0;
  $self->_SourceHeight = $height || 0;
  $self->_SourceColors = $depth || 0;

  my $pretty_name = $self->basename;
  $pretty_name =~ s/_/ /g;

  $self->_Title = $pretty_name;

  # Keep a persistent variable of how much the accumulated rotation is.
  $self->_CurrentRotation = 0;

  # Get timestamps and size if the file referenced by Path exists
  if( stat($self->_Path) ) {

    $self->_SourceSize = -s $self->_Path;

    my $change_date = ( stat(_) )[9];
    my $access_date = ( stat(_) )[8];

    $change_date = sprintf("0x%x", $change_date);
    $access_date = sprintf("0x%x", $access_date);

    # *nix does not seem to have a portable "creation date" stamp.
    # Using last change date, instead.
    $self->_CreationDate = $change_date;
    $self->_LastChangeDate = $change_date;
    $self->_LastAccessDate = $access_date;

  }

  return 1;

}



=head2 TiVo::Item::JPG->query_container

Returns a data structure suitable for use with xml_out which
describes this object in response to a QueryContainer command

=cut

sub query_container {
  my $self = shift;
  my $params = shift;

  my $script_name = $params->_EnvScriptName || "";

  my $details = {
    'Item' => [
      {
        'Details' => {
          'Title'          => $self->_Title,
          'ContentType'    => $self->_ContentType,
          'SourceFormat'   => $self->_SourceFormat,
          'LastChangeDate' => $self->_LastChangeDate
        }
      },
      {
        'Links' => {
          'Content' => {
            'Url' => $script_name . $self->_Url
          }
        }
      }
    ]
  };

  return $details;

}



=head2 TiVo::Item::JPG->send( )

TiVo::Item send extension supporting image transforms

=cut

sub send {
  my $self = shift;
  my $params = shift;
  my $server = shift;

  my $path = $self->_Path;
  my $mime_type = $self->_SourceFormat;


  if ( defined($params->_Rotation) ) {
    my $rotation = $params->_Rotation;
    
    if ($rotation != 0 &&
         (abs($rotation) == 90 ||
          abs($rotation) == 180 ||
          abs($rotation) == 270)) {
      $server->log(6, "info for image: $path");
      $server->log(6, "got rotation of $rotation");
      $server->log(6, "current rotation was " . $self->_CurrentRotation);
      $self->_CurrentRotation = $self->_CurrentRotation + $rotation;

      $server->log(6, "current rotation is now " . $self->_CurrentRotation);
      if ($self->_CurrentRotation >= 360) {
        $self->_CurrentRotation = $self->_CurrentRotation - 360;
      }
      if ($self->_CurrentRotation < 0) {
        $self->_CurrentRotation = $self->_CurrentRotation + 360;
      }
      $server->log(6, "current rotation (after mod) is now " . $self->_CurrentRotation);
    }
  }

  my $filename = $self->basename;

  # Use filename suffix to determine image format
  $filename =~ s/\.(.+?)$//;
  my $suffix = $1;
  my $source_suffix = $suffix;

  # Check for support if a specific format was requested
  if( defined( $params->_Format ) ){

    my $found = 0;

    foreach my $type ( keys %{ $self->_Service->_MediaTypes } ) {

      next unless defined $type;

      if( $self->_Service->_MediaTypes->{$type} eq $params->_Format ) {

        $found = 1;
        $suffix = $type;
        $mime_type = $params->_Format;
        last;

      }

    }

    # Fail if an unavailable format was requested
    return undef unless $found;
  }

  $suffix = uc($suffix);

  if( defined( $params->_Width ) ||
      defined( $params->_Height ) ||
      defined( $params->_PixelShape ) ||
      ($self->_CurrentRotation != 0) ||
      ( uc($suffix) ne uc($source_suffix) ) ) {

    # Use MD5 to hash the filename
    require Digest::MD5;

    my $cache_name = Digest::MD5::md5_hex($path);

    my $string = "";
    $string .= "_H" . $params->_Height if defined($params->_Height);
    $string .= "_W" . $params->_Width if defined($params->_Width);
    $string .= "_S" . $params->_PixelShape if defined($params->_PixelShape);
    $string .= "_R" . $self->_CurrentRotation if ($self->_CurrentRotation != 0);

    # Append transform data to filename
    $cache_name .= $string;

    $server->log(6, "Handing out image with rotation: " . $self->_CurrentRotation );

    my $cache_dir = $self->_ImageDir || '/tmp';
    my $cache_path = "$cache_dir/$cache_name.$suffix";

    # Send cached image directly, if it exists
    if( -f $cache_path ) {

      $path = $cache_path;

    # Otherwise, use Image::Magick to perform requested transforms
    } else {

      require Image::Magick;

      my $width = $self->_SourceWidth;
      my $height = $self->_SourceHeight;
      my $ratio = 1;

      # Calculate the pixel scaling ratio
      if( defined( $params->_PixelShape ) ) {

        my( $xscale, $yscale ) = split(/:/, $params->_PixelShape);

        if( $yscale > $xscale ) {
          $width *= $yscale / $xscale;
        } elsif ( $xscale > $yscale ) {
          $height *= $xscale / $yscale;
        }

      }

      # Calculate the scaling ratio if a new Width or Height is specified
      if( defined( $params->_Width ) || defined( $params->_Height ) ) {
  
        my $s_width = 0;
        my $s_height = 0;
	my $oddRotation = ($self->_CurrentRotation == 90 || $self->_CurrentRotation == 270) ? 1 : 0;
  
        if( defined( $params->_Width ) ) {
	  $s_width = $params->_Width;

          if ($oddRotation == 1) {
              $s_width = $s_width / $self->_SourceHeight;
          } else {
              $s_width = $s_width / $self->_SourceWidth;
          }
        }

        if( defined( $params->_Height ) ) {

          $s_height = $params->_Height;
	  if ($oddRotation == 1)  {
	    $s_height = $s_height / $self->_SourceWidth;
	  } else {
	    $s_height = $s_height / $self->_SourceHeight;
	  }
        }

        $ratio = $s_width < $s_height ? $s_width : $s_height;

      }

      my $img = new Image::Magick;
      $img->Read($self->_Path);


      if( $ratio ) {
	$img->Scale(width => $width * $ratio,
		    height => $height * $ratio);
      }

      my $rotateAmount = $self->_CurrentRotation;
      if ($rotateAmount != 0) {
        $img->Rotate(degrees => $rotateAmount);
      }

      $img->Write(filename => $cache_path);
      $path = $cache_path;

    }

  }

  require IO::File;

  my $handle = IO::File->new($path);
  my $length = -s $path;

  my $headers = {
    'Content-Type'	=> $mime_type,
    'Content-Length'	=> $length
  };

  return($headers, $handle);

}



# TiVo::Item extension
package TiVo::Item::GIF;
use base qw(TiVo::Item::JPG);

# TiVo::Item extension
package TiVo::Item::PNG;
use base qw(TiVo::Item::JPG);

##############################################################################

=head1 TiVo::Request

Stores information about a given command request which needs to be
passed from object to object

=cut

package TiVo::Request;
use base qw(TiVo);

=head2 TiVo::Request->new( $ $ $ )

Constructor for TiVo::Request.

Expects to be passed three strings:

=over 4

=item Script Name

The path and name of the CGI/server as requested in the URI
This is the same string provided by the web server in the
$SCRIPT_NAME environment variable

=item Path Info

The path information appended after the CGI/server in
the URI, but before the paramater list.
This is the same string provided by the web server in the
$PATH_INFO environment variable

=item Query String

The key/value query string appended to the end of the URI
This is the same string provided by the web server in the
$QUERY_STRING environment variable

=back

=cut

sub new {
  my $class = shift;

  my $self = {};
  bless $self, $class;

  $self->_EnvScriptName = shift;
  $self->_EnvPathInfo = shift;
  $self->_EnvQueryString = shift;

  # Parse the query_string, if provided
  if( defined($self->_EnvQueryString) ) {
    $self->parse ( $self->_EnvQueryString );
  }

  return $self;

}



=head2 TiVo::Request->parse( $ )

Trim, split, and decode a standard CGI query string. The key/value
pairs are stored in the object's internal DATA hash

=cut

sub parse {
  my $self = shift;
  my $query = shift;

  # Skip the query if it doesn't contain anything useful
  if( defined($query) && $query =~ /[=&]/ ) {

    # remove everything before the '?' and replace '+' with a space
    $query =~ s/.*\?//;
    $query =~ s/\+/ /g;

    my @pairs = split(/&/, $query);

    foreach my $pair ( @pairs ) {

      my($key, $value) = split(/=/, $pair, 2);

      if( defined($key) ) {

        # Escape each key and value before storing
        $key = $self->uri_unescape($key);
        $self->{'DATA'}->{ uc($key) } = $self->uri_unescape($value);

      }

    }

  }

}



1;
