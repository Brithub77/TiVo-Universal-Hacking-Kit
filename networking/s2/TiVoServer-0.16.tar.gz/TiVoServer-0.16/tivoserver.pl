#!/usr/bin/perl -w


package TiVoServer;

our $VERSION = 0.16;

use strict;
use FindBin;
use lib $FindBin::Bin;

use base qw(Net::Server::PreFork);
use Sys::Hostname;
use Data::Dumper;
use TiVo;

## Find my hostname
my $HOST = Sys::Hostname::hostname();

## Package Globals.

my $DEBUG = 0;
my $PACKET;
my $SERVER;

### run the server
TiVoServer->run( port => '2190/udp',
		 port => '2190/tcp'
             );
exit;

=head1 NAME

TiVoServer - Class that implements TiVo Music & Photo protocol

=head1 SYNOPSIS

Execute the following command to start the tivoserver

  ./tivoserver.pl --conf_file=tivoserver.conf

=head1 REQUIREMENTS

This code uses a number of CPAN modules:

  Net::Server        - Used to provide server framework
  MP3::Info          - Used to parse MP3 tags
  MP3::M3U::Parser   - Used to parse M3U files
  Config::IniFiles   - Used to parse PLS files
  Ogg::Vorbis::Header::PurePerl - Used to parse OGG files

=head1 CONFIG FILE

You will need to modify the default config file B<tivoserver.conf> to
find photos and MP3 files on your system.  The following config
entries are used:

=over 4

=item tivo_name

Specify the name of the server.  This name will show up in the TiVo
Music&Photo menu.  Default is "My Server".  Because of limitations in
the Net::Server configuration code you must use underscore (_) for spaces.

=item tivo_cache_dir

Temporary directory to hold cached tivo data.  The server current
user must be able to write to this directory.

=item tivo_image_cache_dir

Temporary directory to store thumbnail images.  The server current
user must be able to write to this directory.

=item tivo_mp3_name

Defines the name that will appear in the TiVo's 'Music & Photos' menu.
Substitute an underscore (_) for spaces in the name.

=item tivo_mp3_path

The directory containing your music files .mp3, .ogg, and .m3u files are 
supported.

=item tivo_photo_name

Defines the name that will appear in the TiVo's 'Music & Photos' menu.
Substitute an underscore (_) for spaces in the name.

=item tivo_photo_path

The directory containing the images you wish to publish.

=item tivo_use_gallery

1 if you have the Gallery program (http://gallery.sourceforge.net) and you
would like to include your albums, 0 otherwise.

=item tivo_gallery_path

If tivo_use_gallery is 1, this is the path where your albums are stored.

=item tivo_gallery_location

This is the location that the albums will show up on the TiVo.

=item tivo_debug_level

Set to 5 or 6 to get detailed debugging information in the log file.

=back


=cut

### set up some server parameters

sub configure_hook {
  my $self = shift;

  # setup defaults
  $self->{tivo_name} = "My Server";
  $self->{tivo_cache_dir} = "/tmp/tivo";
  $self->{tivo_image_cache_dir} = "/tmp/tivo/images";

  $self->{tivo_mp3_name} = "My Music";
  $self->{tivo_mp3_path} = "/media/tunes";

  $self->{tivo_photo_name} = "My Photos";
  $self->{tivo_photo_path} = "/media/photos";

  $self->{tivo_use_gallery} = 0;
  $self->{tivo_gallery_path} = "/var/www/albums";
  $self->{tivo_gallery_location} = "/Photos/gallery";
}

### pull some data out of the config file
sub post_configure_hook {
  my $self = shift;
  my $conf = $self->{server}->{conf_file_args};

  $self->log(4, Dumper($conf)) if ($DEBUG);

  foreach my $argval (@{$conf}) {
    $argval =~ m/^(.*?)=(.*)$/;
    my ($arg, $val) = (lc($1), $2);

    if ($arg =~ /^tivo/) {
      
      # replace underscores when attribute ends with _name
      $val =~ s/_/ /g if ($arg =~ /_name$/);

      $self->log(4, "adding $arg, $val");
      $self->{$arg} = $val;
    }
  }
  # Sanity tests
  mkdir($self->{tivo_cache_dir}, 0775) unless (-d $self->{tivo_cache_dir});

  unless (-w $self->{tivo_cache_dir}) {
    die "Cannot write to cache directory '" . $self->{tivo_cache_dir} . "'\n";
  }

  mkdir($self->{tivo_image_cache_dir}, 0775) unless (-d $self->{tivo_image_cache_dir});

  unless (-w $self->{tivo_image_cache_dir}) {
    die "Cannot write to image cache directory '" . $self->{tivo_image_cache_dir} . "'\n";
  }

  ### TBD more sanity tests here.

  ### Construct fixed UDP packet
  $PACKET = $self->generate_packet();

  # generate an anonymous subroutine that calls the logger

  my $debug_level = $self->{tivo_debug_level};

  my $logger_ref = sub { my $level = shift; 
                         return if ($debug_level < $level);
                         my $msg = shift; 
                         $self->log(4, "=> " . $msg);
                       };


  ### Construct TiVo objects
  $SERVER = TiVo::Server->new( SERVER_NAME => $self->{tivo_name},
			       CACHE_DIR   => $self->{tivo_cache_dir},
                   IMAGE_DIR   => $self->{tivo_image_cache_dir},
                   USE_GALLERY => $self->{tivo_use_gallery},
                   GALLERY_PATH => $self->{tivo_gallery_path},
                   GALLERY_LOCATION => $self->{tivo_gallery_location},
			       LOG_HANDLE  => $logger_ref,
                   );

  if ($self->{tivo_mp3_path}) {
    ### TBD split on path??
    my $mp3 = TiVo::Container::Music->new( PATH => $self->{tivo_mp3_path},
					   SERVICE => "/Music",
					   TITLE => $self->{tivo_mp3_name});
    $SERVER->add_service( $mp3);
  }

  if ($self->{tivo_photo_path}) {
    ### TBD split on path ??
    my $photo = TiVo::Container::Photos->new( PATH => $self->{tivo_photo_path},
					      SERVICE => "/Photos",
					      TITLE => $self->{tivo_photo_name});
    $SERVER->add_service( $photo);
  }

  $self->log(4, Dumper($SERVER)) if ($DEBUG);
}


=head1 SERVER OPERATION

After reading it's configuration file the tivoserver listens for
connections on port 2190.  The server responds to TiVo broadcasts on
UDP port 2190.  It also includes a built-in HTTP server that
implements the Music & Photo protocol.

=cut

sub process_request {
  my $self = shift;
  my $prop = $self->{server};

  # UDP requests
  if ($prop->{udp_true} ){
    my $msg = $prop->{udp_data};

    $prop->{client}->send($PACKET, 0);
    return;
  }

  # TCP/HTTP requests
  ## TCP connection
  ## send udp packet back to host??

  ### read the first line of response
  my $line = <STDIN>;
  $line =~ s/[\r\n]+$//;

  $self->log(0, $line);

  unless( $line =~ /^ (\w+) \ + (\S+) \ + (HTTP\/1.\d) $ /x ){
    ### ummm, this might be a UDP over tcp thing?
    $prop->{client}->send($PACKET, 0);
    return;
    #return $self->http_error(400, "Bad request");
  }

  my ($method,$req,$protocol) = ($1,$2,$3);

  ### read in other headers
  $self->read_headers || return $self->http_error(400, "Strange headers");

  ### do we support the type
  unless( $method =~ /GET|POST|HEAD/ ){
    return $self->http_error(400, "Unsupported Method");
  }

  ### can we read that request
  unless( $req =~ m%^ (?:http://[^/]+)? (.*) $%x ){
    return $self->http_error(400, "Malformed URL");
  }
  $ENV{REQUEST_URI} = $1;

  ### parse out the uri and query string
  my $uri = '';
  $ENV{QUERY_STRING} = '';
  if( $ENV{REQUEST_URI} =~ m%^ ([^\?]+) (?:\?(.+))? $%x ){
    $ENV{QUERY_STRING} = defined($2) ? $2 : '';
    $uri = $1;
  }

  ### clean up uri
  if( $uri=~/[\ \;]/ ){
    return $self->http_error(400, "Malformed URL");
  }
  $uri =~ s/%(\w\w)/chr(hex($1))/eg;
  1 while $uri =~ s|^\.\./+||; # can't go below doc root

  ### at this point the uri should be ready to use
  $uri = "$uri";

  my $path_info = "";

  if ($uri =~ m,^/TiVoConnect,) {
    $path_info = $uri;
    $uri = "/TiVoConnect";
    $path_info =~ s,^/TiVoConnect,,;
  }

  $self->log(0, "URI is $uri");
  $self->log(0, "QS is " . $ENV{QUERY_STRING});

  my ($headers, $data) = $SERVER->request($uri, $path_info, $ENV{QUERY_STRING});

  $self->log(0, Dumper([$headers, $data])) if ($DEBUG);

  if (defined($headers)) {
    # Print the recommended headers
    print $self->http_status(200, 'Ok');

    foreach ( keys %$headers ) {
      print "$_: ", $headers->{$_}, "\r\n" if $headers->{$_};
    }
    print "\r\n";

    # If the returned data is a scalar ref, simply print it out
    if( ref $data eq 'SCALAR' ) {
      print $$data;

      # If it's a filehandle ref, read from the file
    } elsif( ref $data eq 'IO::File' ) {
      my $block;
      while( $data->read($block, 1024) ) {
	print $block;
      }

      # Close file
      undef $data;
    }
  } else {
    return $self->http_error(404, "file not found");
  }

  return;
}


#
# Format the TiVo UDP packet format.
#

sub generate_packet {
  my $self = shift;
  my $identity = $self->{tivo_name} || $HOST;

  my $osrel = `uname -r`;
  chomp($osrel);
  $osrel =~ s/-/./g;

  my $packet = <<EOF;
TiVoConnect=1
Machine=$HOST
Identity=$HOST
Method=Broadcast
Platform=pc/$^O-$osrel
Services=TiVoMediaServer:2190/http
EOF

  return $packet;
}

#
# read a set of http_headers
#

sub read_headers {
  my $self = shift;

  $self->{headers} = {};

  while(<STDIN>){
    s/[\r\n]+$//;
    last unless length $_;
    unless( /^([\w\-]+) :[\ \t]+ (.+) $/x ){
      return 0;
    }
    my $key = "HTTP_" . uc($1);
    $key =~ tr/-/_/;
    $self->{headers}->{$key} = $2;
  }
  return 1;
}

sub content_type {
  my $type = shift;
  return "Content-type: $type\r\n";
}

sub http_error{
  my $self = shift;

  $self->http_status(@_);

  print "\r\n";
  $self->log(0, join(' ', @_));
  #,shift();
}

sub http_status {
  my $self = shift;
  my $number = shift;
  my $msg    = shift || '';

  return "HTTP/1.0 $number $msg\r\n";
}


1;
