#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/fcntl.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "osd.h"
#include "font.h"

int TextItalic=0;
int mpegfd=0;

unsigned char *tivbuffer = 0;

static int pad=1;
static struct osd new_osd, cur_osd = {0,0,0};

#define LINE(y) ((y)*26*720)+18588
#define POS(x,y) LINE(y)+(*cur_x)*17

static void resize_buf(struct osd *osd,int start,int end) {
  if (!osd->start || start < osd->start) {
    if (osd->start) osd->len += osd->start - start;
    osd->start=start;
  }

  if (end > osd->start + osd->len)
    osd->len = end - osd->start;
}

static void togglebits(char bits, int *ptr, int on, int off)
{
  static unsigned char shift[] = { 128, 64, 32, 16, 8, 4, 2, 1 };
  int x;

  for (x = 0; x < 8; x++) {
    if (bits & shift[x]) tivbuffer[*ptr] = on;
    else if (off > 0)    tivbuffer[*ptr] = off;
    (*ptr)++;
  }

  for (x=0; x<pad; x++) tivbuffer[(*ptr)++] = off;

  (*ptr)-=pad; 
}

void DrawChar(int *cur_x, int *cur_y, char c, int fg, int bg)
{
  int x;
  int ptr = POS(*cur_x,*cur_y);
  char *bits = &textfont[c * 52];

  if (!tivbuffer) return;
  if ((*cur_x) > 32) (*cur_x) = 1, (*cur_y)++;
  if ((*cur_y) > 15) (*cur_y) = 1;

  pad = 1;

  for (x = 0; x < 26; x++) {
    togglebits(*(bits++), &ptr, fg, bg);
    togglebits(*(bits++), &ptr, fg, bg);
    ptr += 720 - 16;
    if (TextItalic  && (x%2)==0) {
      ptr--;
      pad++;
    }
  }

  (*cur_x)++;

  resize_buf(&cur_osd,LINE(*cur_y),ptr);
  resize_buf(&new_osd,LINE(*cur_y),ptr);
}

void DrawString(int *cur_x, int *cur_y, char *string, int fg, int bg)
{
  if (!tivbuffer) return;
  while (string[0] != 0) {
    if (string[0] == '\n') {
      (*cur_x) = 1;
      (*cur_y)++;
    } else {
      DrawChar(cur_x, cur_y, string[0], fg, bg);
    }
    string++;
  }
}

void rollupbuf(int dest, int source, int lines)
{
  if (!tivbuffer) return;
  memcpy(&tivbuffer[LINE(dest)], &tivbuffer[LINE(source)], lines * 26 * 720);
  memset(&tivbuffer[LINE(dest+lines)],0,1 * 26 * 720);

  resize_buf(&cur_osd,LINE(dest),LINE(dest+lines+1));

  new_osd.start = LINE(dest);
  new_osd.len = (lines+1) * 720 * 26;
}

void SetupTextOSD(void)
{
  mpegfd = open("/dev/mpeg0v", O_RDWR);
  tivbuffer = (char *) calloc(1,520 + 720 * 480);
}

void FreeTextOSD(void)
{
  if (tivbuffer) free(tivbuffer);
  tivbuffer=0;
  close(mpegfd);
}

void ClearOSD(void)
{
  if (!tivbuffer) return;
  memset(&tivbuffer[cur_osd.start], 0, cur_osd.len);
  memset(&new_osd,0,sizeof(struct osd));
}

void DrawOSD(void)
{
  if (!tivbuffer) return;
  if (cur_osd.start) {
    cur_osd.start = (cur_osd.start &~7);
    cur_osd.len   = (cur_osd.len   &~7)+8;
    cur_osd.buf   = &tivbuffer[cur_osd.start];

    ioctl(mpegfd, 0x403, &cur_osd);
    memcpy(&cur_osd,&new_osd,sizeof(struct osd));
  }
}
