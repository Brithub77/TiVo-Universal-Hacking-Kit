#ifndef OSD_H
#define OSD_H

struct osd {
	unsigned start;
	unsigned len;
	void *buf;
};
extern int mpegfd;

extern unsigned char *tivbuffer;

extern int TextItalic;

extern void rollupbuf (int dest, int source, int lines);

extern void DrawChar(int *cur_x, int *cur_y, char c, int fg, int bg);
extern void DrawString(int *cur_x, int *cur_y, char *string, int fg, int bg);

extern void SetupTextOSD(void);
extern void FreeTextOSD(void);
extern void ClearOSD(void);
extern void DrawOSD(void);

#endif
