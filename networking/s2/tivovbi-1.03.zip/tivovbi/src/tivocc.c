#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <signal.h>
#include <string.h>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <linux/unistd.h>
#include <linux/module.h>
#include "osd.h"

_syscall5(int, query_module, const char *, name, int, which, void *, buf, size_t, bufsize, size_t *, ret);

////////////////// commandline //////////////////////

#define TEXT_MODE        (1<<0)
#define OSD_MODE         (1<<1)
#define DECODE_CC        (1<<2)
#define DECODE_XDS       (1<<3)
#define SETTIME          (1<<4)
#define ISATERM          (1<<5)
#define TRANS            (1<<6)

int flags = 0;
int debug = 0;

////////////////// OSD //////////////////////
#define CCNONE     -3
#define CCTEXTMODE -2
#define CCPOPUPNB  -1
#define CCPOPUP     0
#define CCPAINTON   1

int CUR_X, CUR_Y;
int CC_stat = CCNONE;
char CC_buf[255];
char *CC_ptr = CC_buf;
unsigned lastcap=0;

void drawchar(char c)
{
  if (c < 2) return;
  
  if (flags & OSD_MODE && CC_stat != CCNONE && CUR_Y != -1)
    DrawChar(&CUR_X, &CUR_Y, c, 4, (flags&TRANS)?5:13);

  if (CC_ptr - CC_buf > sizeof(CC_buf) - 1) {        // buffer overflow
    CC_ptr = CC_buf;
    memset(CC_buf, 0, sizeof(CC_buf));
  }
  *(CC_ptr++) = (c==14)?'/':c; //swap a '/' for musical note
}

void draw()
{
  if (CC_ptr != CC_buf && flags & TEXT_MODE) {
    if (*(CC_ptr-1) == '\n')
       *(CC_ptr-1) = 0;
    
    printf("%s%s\n", CC_buf, (TextItalic && flags&ISATERM)?"\33[m":"");
  }
  lastcap = time(NULL);

  CC_ptr = CC_buf;
  memset(CC_buf, 0, sizeof(CC_buf));

  if (flags & OSD_MODE) DrawOSD();
  if (TextItalic) TextItalic = 0;
}

////////////////// CC //////////////////////

int CC_last = 0;
char CC_mode = 0;
int CC_row[] = { 11, -1, 1, 2, 3, 4, 12, 13, 14, 15, 5, 6, 7, 8, 9, 10 };
char specialchar[] = { '�', '�', '�', '�', '*', '�', '�', 14, '�', ' ', '�', '�', '�', '�', '�', '�' };

int CCdecode(char b1, char b2)
{
  int x;
  int data = (b2 << 8) + b1;

  if (b1 & 0x60)                // text
  {
    if (!debug && CC_stat == CCNONE) return 0;
    if (debug > 3) {
      printf("\33[33;1m%c%c\33[m",b1,b2);
      fflush(stdout);
    }

    drawchar(b1);
    drawchar(b2);

    if (CC_stat > 0 && flags & OSD_MODE) DrawOSD();

  //codes are always transmitted twice (apparently not, ignore the second occurance)
  } else if ((b1 & 0x10) && (b2 > 0x1F) && (data != CC_last)) {
    #define CURRENT ((b1 & 0x08)>>3)

    if (CC_mode != CURRENT && CC_stat != CCNONE) {
      if (debug && CC_ptr != CC_buf) draw();
      CC_stat = CCNONE;
      return 0;
    }

    if (CC_stat == CCNONE || CUR_Y == -1) {
      if (CC_ptr != CC_buf) {
        if (debug) printf("%s(debug) %s%s\n",(flags&ISATERM)?"\33[36m":"", CC_buf, (flags&ISATERM)?"\33[m":"");
        CC_ptr = CC_buf;
        memset(CC_buf, 0, sizeof(CC_buf));
      }

      if (CC_mode != CURRENT) return 0;
    }
    
    if (b2 & 0x40) {                //preamble address code (row & indent)
      CUR_Y = CC_row[((b1 << 1) & 14) | ((b2 >> 5) & 1)];

      if (debug > 3) printf("<< preamble %d >>\n",CUR_Y);

      //we still have something in the text buffer
      if (CC_ptr != CC_buf) {
        *(CC_ptr++) = '\n';
        if (TextItalic) {
          if (flags && ISATERM)
            CC_ptr += sprintf(CC_ptr,"\33[m");
          TextItalic = 0;
        }
      }

      CUR_X = 1;
      if (b2 & 0x10)                //row contains indent flag
        for (x = 0; x < ((b2 & 0x0F) << 1); x++) {
          CUR_X++;
          *(CC_ptr++) = ' ';
        }
    } else { // !(b2 & 0x40)
      if (debug > 3) printf("<< %02x >>\n", b1 & 0x7);
      switch (b1 & 0x07) {
        case 0x00:                //attribute
          if (debug > 1)
            printf("<<A: %d>>\n", b2);
          break;
        case 0x01:                //midrow or char
          switch (b2 & 0x70) {
            case 0x20:                //midrow attribute change
              switch (b2 & 0x0e) {
                case 0x00:        //italics off
                  TextItalic = 0;
                  //drawchar(' ');
                  if (flags&ISATERM)
                    CC_ptr += sprintf(CC_ptr,"\33[m ");
		  else
		    *(CC_ptr++) = ' ';
                  break;
                case 0x0e:        //italics on
                  drawchar(' ');
                  TextItalic = 1;
                  if (flags&ISATERM)
                    CC_ptr += sprintf(CC_ptr,"\33[36m");
                  break;
                default:
                  if (debug > 1)
                    printf("<<D: %d>>\n", b2 & 0x0e);
              }
              if (b2 & 0x01) {        //underline
                //TextUnderline = 1;
              } else {
                //TextUnderline = 0;
              }
              break;
            case 0x30:                //special character..
              //transparent space
              if ((b2 & 0x0f) == 9) {
                CUR_X++;
                *(CC_ptr++) = ' ';
              } else {
                drawchar(specialchar[b2 & 0x0f]);
              }
              break;
          }
          break;
        case 0x04:                //misc
        case 0x05:                //misc + F
          if (debug > 3) printf("<< misc %02x >>\n", b2);
          switch (b2) {
            case 0x20:                //resume caption (new caption)
              if (flags & OSD_MODE && CC_stat != CCPOPUP)
                ClearOSD();
              CC_stat = CCPOPUP;
              break;

            case 0x21:                //backspace
              CUR_X--;
              break;
              
            case 0x25 ... 0x27:        //2-4 row captions
              if (CC_stat==CCPOPUP) ClearOSD();
              CC_stat = b2 - 0x23;
              if (CUR_Y<CC_stat) CUR_Y = CC_stat;
              break;

            case 0x29:                //resume direct caption
              CC_stat = CCPAINTON;
              break;

            case 0x2A:                //text restart
              draw();
              /* FALL */
            case 0x2B:                //resume text display
              CC_stat = CCTEXTMODE;
              break;

            case 0x2C:                //erase displayed memory
              lastcap=0;
              if (flags & OSD_MODE) { // && CC_stat == CCPAINTON) {
                //see if we can cheat and reuse the current buffer
                if (CC_stat > CCPOPUP || CC_ptr == CC_buf) {
                  ClearOSD();
                  draw();
                } else { //new buffer
                  unsigned char * old=tivbuffer;
                  tivbuffer = (char *) calloc(1,520 + 720 * 480);
                  DrawOSD();
                  free(tivbuffer);
                  tivbuffer=old;
                }
              }
              break;

            case 0x2D:                //carriage return
              draw();
              CUR_X = 1;
              if (flags & OSD_MODE) {
                if (CC_stat>CCPAINTON)
                  rollupbuf(CUR_Y - CC_stat + 1 , CUR_Y - CC_stat + 2, CC_stat - 1);
                else
                  CUR_Y++;
             }
             break;

            case 0x2F:                //end caption + swap memory
              draw();
              /* FALL THROUGH TO 0x2E */

            case 0x2E:                //erase non-displayed memory
              if (debug && CC_ptr != CC_buf)
                printf("%s (debug) %s%s\n", (flags&ISATERM)?"\33[35m":"",CC_buf,(flags&ISATERM)?"\33[m":"");
              if (flags & OSD_MODE) ClearOSD();

              CUR_X = 1;
              CUR_Y = -1;
              
              CC_ptr = CC_buf;
              memset(CC_buf, 0, sizeof(CC_buf));
          }
          break;
        case 0x07:                //misc (TAB)
          for (x = 0; x < (b2 - 0x20); x++)
            CUR_X++;
          break;
      }
    }
  }
  CC_last = data;
  return 0;
}

////////////////// XDS //////////////////////

int XDS_mode = 0, XDS_type = 0, XDS_length = 0;
char XDS_checksum = 0;
char XDS[8][25][34];
char XDS_new[8][25][34];

char *VCHIP[2][8] = {
  {"(NOT APPLICABLE)", "G", "PG", "PG-13", "R", "NC-17", "X", "(NOT RATED)"},        //MPAA format
  {"(NOT RATED)", "TV-Y", "TV-Y7", "TV-G", "TV-PG", "TV-14", "TV-MA", "(NOT RATED)"}
};

char *XDS_modes[] = {
  "CURRENT",                        //01h-02h current program
  "FUTURE ",                        //03h-04h future program
  "CHANNEL",                        //05h-06h channel
  "MISC.  ",                        //07h-08h miscellaneous
  "PUBLIC ",                        //09h-0Ah public service
  "RESERV.",                        //0Bh-0Ch reserved
  "UNDEF. ",
  "INVALID",
  "INVALID",
  "INVALID"
};

int XDSdecode(char b1, char b2)
{
  if (b1 < 0x0F) {                // start packet 
    XDS_length = 0;
    XDS_mode = b1 >> 1;                //every other mode is a resume
    XDS_type = b2;
    XDS_checksum = b1 + b2;
    return 0;
  }

  XDS_checksum += b1 + b2;
  
  if (b1 == 0x0F) {        // eof (next byte is checksum)
    //validity check
    if (!XDS_length || XDS_checksum & 0x7F) {
      if (debug > 3 && !XDS_length) {
        printf("%s%% XDS CHECKSUM ERROR (ignoring)%s\n",(flags&ISATERM)?"33[33m":"",(flags&ISATERM)?"\33[m":"");
      } else {
        XDS_mode = XDS_type = 0;
        return 1;
      }
    }

    //check to see if the data has changed.
    if (strncmp(XDS[XDS_mode][XDS_type],XDS_new[XDS_mode][XDS_type],XDS_length - 1)) {
      char *XDS_ptr = XDS[XDS_mode][XDS_type];
      XDS_ptr[XDS_length] = 0;
      memcpy(XDS[XDS_mode][XDS_type], XDS_new[XDS_mode][XDS_type], XDS_length);

      //nasty hack: only print time codes if seconds are 0
      if (XDS_mode == 3 && XDS_type == 1 && !(XDS_new[3][1][3] & 0x20)) return 0;
      if (XDS_mode == 0 && XDS_type == 2 &&  (XDS_new[0][2][4] & 0x3f)>1) return 0;

      printf("%s%% %s ",(flags&ISATERM)?"\33[33m":"", XDS_modes[XDS_mode]);

      switch ((XDS_mode << 9) + XDS_type + 0x100) {
          // cases are specified in 2 bytes hex representing mode, type.
          // XDS_ptr will point to the current class buffer

        case 0x0101:                //current program identification number
        case 0x0301:                //future
          {
            char * mon[] = { "0", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
                             "Aug", "Sep", "Oct", "Nov", "Dec", "13", "14", "15"};
            printf("AIR DATE: %s %2d %d:%02d:00",
                 mon[XDS_ptr[3] & 0x0f], XDS_ptr[2] & 0x1f,
                 XDS_ptr[1] & 0x1f, XDS_ptr[0] & 0x3f);

            //Program is tape delayed
            if (XDS_ptr[3] & 0x10) printf(" TAPE");
          }
          break;
        case 0x0102:                //current program length
        case 0x0302:                //future
          printf("DURATION: %d:%02d:%02d of %d:%02d:%02d",
                 XDS_ptr[3] & 0x3f, XDS_ptr[2] & 0x3f,
                 XDS_ptr[4] & 0x3f, XDS_ptr[1] & 0x3f,
                 XDS_ptr[0] & 0x3f, 0);
          break;
        case 0x0103:                //current program name
        case 0x0303:                //futyre
          printf("   TITLE: %s", XDS_ptr); break;
        case 0x0104:                //current program type
        case 0x0304:                //future
          // for now just print out the raw data
          // requires a 127 string array to parse
          // properly and isn't worth it.
          printf("   GENRE:");
          {
            int x;
            for (x = 0; x < XDS_length; x++)
              printf(" %02x", XDS_ptr[1]);
          }
          break;
        case 0x0105:                //current program rating
        case 0x0305:                //future
          printf("  RATING: %s", VCHIP[(XDS_ptr[0] & 0x08) >> 3][XDS_ptr[1] & 0x07]);
          if (XDS_ptr[0] & 0x20) printf(" DIALOGUE");
          if (XDS_ptr[1] & 0x08) printf(" LANGUAGE");
          if (XDS_ptr[1] & 0x10) printf(" SEXUAL");
          if (XDS_ptr[1] & 0x20) printf(" VIOLENCE");

          //raw output for verification.
          if (debug > 1)
            printf(" (%02x %02x)", XDS_ptr[0], XDS_ptr[1]);
          break;
        case 0x0106:                //current program audio services
        case 0x0306:                //future
          // requires table, never actually seen it used either
          printf("   AUDIO: %02x %02x", XDS_ptr[0], XDS_ptr[1]);
          break;
        case 0x0109:                //current program aspect ratio
        case 0x0309:                //future
          // requires table, rare
          printf("  ASPECT: %02x %02x", XDS_ptr[0], XDS_ptr[1]);
          break;
        case 0x0110 ... 0x0117: //program description
          printf(" DESCRIP: %s", XDS_ptr); break;
        case 0x0501:                //channel network name
          printf(" NETWORK: %s", XDS_ptr); break;
        case 0x0502:                //channel network call letters
          printf("CALLSIGN: %s", XDS_ptr); break;
        case 0x0701:                //misc. time of day
          {
#define TIMEZONE        (XDS[3][4][0]&0x1f)
#define DST                ((XDS[3][4][0]&0x20)>>5)
            struct tm tm = {
              0,                //sec
              (XDS_ptr[0] & 0x3F),        //min
              (XDS_ptr[1] & 0x1F),        //hour
              (XDS_ptr[2] & 0x1F),        //day
              (XDS_ptr[3] & 0x1f) - 1,        //month
              (XDS_ptr[5] & 0x3f) + 90,        //year
              0,                //day of week
              0,                //day of year
              0,                //DST
            };

            // if your copy crashes here
            // compile with libc.so from tivo

            time_t time_t = mktime(&tm);
            char *timestr;

            if (flags & SETTIME) {
              //1 sec encoding delay
              struct timeval tv = { time_t + 1, 0 };
              struct timezone tz = { 0, 0 };
              settimeofday(&tv, &tz);
            }
            time_t -= ((TIMEZONE - DST) * 60 * 60);
            timestr = ctime(&time_t);
            timestr[strlen(timestr) - 1] = 0;

            printf("CUR.TIME: %s ", timestr);
            if (XDS[3][4][0]) {
              printf("UTC-%d", TIMEZONE);
              if (DST) printf(" DST");
            } else
              printf("UTC");
          }
          break;
        case 0x0704:                //misc. local time zone
          printf("TIMEZONE: UTC-%d", XDS_ptr[0] & 0x1f);
          if (XDS_ptr[0] & 0x20) printf(" DST");
          break;
        default:
          printf("UNKNOWN CLASS %d TYPE %d", (XDS_mode << 1) + 1, XDS_type);
          if (debug > 1) {
            int x;
            printf("\nDUMP:\n");
            for (x = 0; x < XDS_length; x++)
              printf(" %02x %c", XDS_ptr[x], XDS_ptr[x]);
            printf("\n");
          } else {
            printf(" (please report)");
          }
      }
      if (debug > 1) printf(" (%d)", XDS_length);
      if (flags&ISATERM)
        printf("\33[m\n");
      else
        printf("\n");
    }
    XDS_mode = XDS_type = 0;
  } else if (XDS_length < 34) {
    XDS_new[XDS_mode][XDS_type][XDS_length++] = b1;
    XDS_new[XDS_mode][XDS_type][XDS_length++] = b2;
  }
  return 0;
}

int kmem_fd;

void decodebuffer(int decode(char, char), void *Buffer, void *Tail, int *old_tail)
{
  int new_tail, x;
  char buf[256];
  lseek(kmem_fd, (off_t) Tail, SEEK_SET);
  read(kmem_fd, &new_tail, 4);

  /* buffer wrapped, read rest of line */
  if (*old_tail > new_tail) {
    lseek(kmem_fd, (off_t) (Buffer + *old_tail), SEEK_SET);
    read(kmem_fd, &buf, 256 - *old_tail);
    for (x = 0; x < (256 - *old_tail); x += 2)
      decode(buf[x] & 0x7F, buf[x + 1] & 0x7F);
    *old_tail = 0;
  }

  /* normal read */
  x = new_tail - *old_tail;
  if (x > 0) {
    lseek(kmem_fd, (off_t) (Buffer + *old_tail), SEEK_SET);
    read(kmem_fd, &buf, x);
    for (x = 0; x < (new_tail - *old_tail); x += 2)
      decode(buf[x] & 0x7F, buf[x + 1] & 0x7F);
  }
  *old_tail = new_tail;
}

void help()
{
  printf("tivovbi [ -t | -o ] [ -c ] [ -x ]\n"
         " DISPLAY MODE: \n"
         "  -t\ttext output\n"
         "  -o\tOSD display\t(requires -c)\n"
         " DECODE: \n"
         "  -x\tXDS data\t(requires -t)\n"
         "  -T\tset clock\t(requires -x)\n"
         "  -c1\tCC1 data\n"
         "  -c2\tCC2 data\n"
         "  -d\tDEBUG MODE\t(requires -t)\n");
  
  exit(0);
}

void quit(int x)
{
  signal(x,NULL);
  if (x==2)
    printf("===== tivovbi 1.03 =====\nprogrammed by mbm@linux.com\n");
  if (x==11) printf("\33[1;33m(tivovbi) Segmentation violation: Please send a bug report.\33[m\n");
  if (flags & TEXT_MODE) {
    struct termios  termios_tty;
    tcgetattr(0, &termios_tty);
    termios_tty.c_lflag |= (ECHO|ICANON);
    tcsetattr(0, TCSANOW, &termios_tty);
  }
  if (flags & OSD_MODE) {
    ClearOSD();
    DrawOSD();
    FreeTextOSD();
  }
  close(kmem_fd);
  exit(0);
}

int main(int argc, char **argv)
{
  int x, cc_tail, xds_tail;
  size_t bufsize, ret;

  void *caption1Tail;                //symbol address
  void *caption1Buffer;                //symbol address
  void *ccbuf, *xdsbuf;

  while (1) {                        //commandline parsing
    int arg;
    if (-1 == (arg = getopt(argc, argv, "h?otcxdT12C"))) break;
    switch (arg) {
      case '?':
      case 'h': help();
      case 'x': flags |= DECODE_XDS; break;
      case 'c': flags |= DECODE_CC;  break;
      case 't': flags |= TEXT_MODE;  break;
      case 'o': flags |= OSD_MODE;   break;
      case 'T': flags |= SETTIME;    break;
      case 'C': flags |= TRANS;      break;
      case '1': CC_mode = 0; break;
      case '2': CC_mode = 1; break;
      case 'd': debug++;     break;
    }
  }

  if (!(flags & (TEXT_MODE | OSD_MODE) && flags & (DECODE_CC | DECODE_XDS)))
    help();
  if ((!(flags & TEXT_MODE) &&  (flags & DECODE_XDS || debug)) 
      || (flags & OSD_MODE  && !(flags & DECODE_CC))
      || (flags & SETTIME   && !(flags & DECODE_XDS))) {
          printf("invalid option combination\n");
          help();
          
  }

  if (flags & TEXT_MODE) {
    if (isatty (fileno(stdout))) {
      struct termios  termios_tty;
      tcgetattr(fileno(stdin), &termios_tty);
      termios_tty.c_lflag &= ~(ECHO|ICANON);
      tcsetattr(fileno(stdin), TCSANOW, &termios_tty);
      flags |= ISATERM;
    }
  } else if ((ret = fork())) {
    return (printf("pid is %d\n", ret)<0);
  }


  signal( 2,quit);
  signal(15,quit);
  signal(11,quit);

  if (flags & OSD_MODE) {
    SetupTextOSD();
    CUR_X = CUR_Y = -1;
  }

  /* symbol lookup */
  {
    struct module_info   *modinfo;
    struct module_symbol *stab, *sym;

    modinfo = malloc(bufsize = 1024);
    query_module("pxmpegdecode", QM_INFO, modinfo, bufsize, &ret);
    caption1Buffer = (void *)modinfo->addr + 0xda04;
    caption1Tail   = (void *)modinfo->addr + 0xd9c0;
    free(modinfo);

    stab = malloc(bufsize = 1024);
    while (query_module("pxmpegdecode", QM_SYMBOLS, stab, bufsize, &ret))
      if (errno == ENOSPC) {
        stab = realloc(stab, bufsize = ret);
        continue;
      } else {
        perror("query_module");
        exit(1);
      }

    sym = stab;

    for (x = ret; x > 0; sym++, x--)
      if (!strcmp((char *) (sym->name + (unsigned long) stab), "caption1Tail"))
        caption1Tail = (void *) sym->value;
      else if (!strcmp((char *) (sym->name + (unsigned long) stab), "caption1Buffer"))
        caption1Buffer = (void *) sym->value;
    free(stab);
  }

  //cheap trick but mmap won't work on these
  kmem_fd = open("/dev/kmem", O_RDONLY);

  lseek(kmem_fd, (off_t) caption1Buffer, SEEK_SET);
  read(kmem_fd, &ccbuf, 4);
  read(kmem_fd, &xdsbuf, 4);

  lseek(kmem_fd, (off_t) caption1Tail, SEEK_SET);
  read(kmem_fd, &cc_tail, 4);
  read(kmem_fd, &xds_tail, 4);

  //cheap trick to go back to the begining of the buffer
  //useful for debugging
  //xds_tail = (xds_tail++)&0xFF;

  while (1) {
    int ret=-1;
    char c;
    struct timeval tv = { 0, 10000 };
    int vidstat0, vidstat1;
    fd_set rfds;
    FD_ZERO(&rfds);
    FD_SET(0, &rfds);

    if (flags & TEXT_MODE && select(FD_SETSIZE, &rfds, NULL, NULL, &tv) > 0 && (ret = read(fileno(stdin), &c, 1)) == 1 && c == 'q')
            quit(2);
    else if (ret<0) //prevent race condition when terminal is dropped
            usleep(10000);

    if (flags & DECODE_CC)  decodebuffer(&CCdecode, ccbuf, caption1Tail, &cc_tail);
    if (flags & DECODE_XDS) decodebuffer(&XDSdecode, xdsbuf, caption1Tail + 4, &xds_tail);
    if (flags & OSD_MODE) {
      //no comment ;)
      vidstat1 = ioctl(mpegfd,0x3fd,0);
      if (lastcap && (vidstat1 - vidstat0 > 100000 || vidstat0 - vidstat1 > 100000 || time(NULL) - lastcap > 10)) {
        unsigned char * old=tivbuffer;
        tivbuffer = (char *) calloc(1,520 + 720 * 480);
        DrawOSD();
        free(tivbuffer);
        tivbuffer=old;
        lastcap=0;
      }
      vidstat0 = vidstat1;
    }
  }
  return 0;
}
