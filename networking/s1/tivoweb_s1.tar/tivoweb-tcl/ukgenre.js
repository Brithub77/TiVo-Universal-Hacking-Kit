var categoriesval = new Array()
categoriesval[0] = 1006
categoriesval[1] = 1009
categoriesval[2] = 1011
categoriesval[3] = 1000
categoriesval[4] = 1001
categoriesval[5] = 1002
categoriesval[6] = 1003
categoriesval[7] = 1004
categoriesval[8] = 1005
categoriesval[9] = 1012
categoriesval[10] = 1013
categoriesval[11] = 1007
categoriesval[12] = 1008
categoriesval[13] = 1014
categoriesval[14] = 1010
categoriesval[15] = 1015

var categories = new Array()
categories[0] = "Films"
categories[1] = "Sports"
categories[2] = "Action and Adventure"
categories[3] = "Arts and Living"
categories[4] = "Children"
categories[5] = "Comedy"
categories[6] = "Daytime"
categories[7] = "Documentary"
categories[8] = "Drama"
categories[9] = "Educational"
categories[10] = "Mystery and Thriller"
categories[11] = "News and Business"
categories[12] = "Science, Natural World, Tech."
categories[13] = "Sci-Fi and Fantasy"
categories[14] = "Talk Shows"
categories[15] = "Western"

var subcategories = new Array()
subcategories[1] = "Action and Adventure"
subcategories[2] = "Adult"
subcategories[3] = "Animals"
subcategories[4] = "Animation"
subcategories[5] = "Anthology"
subcategories[6] = "Art"
subcategories[7] = "Auto"
subcategories[8] = "Auto Maintenance"
subcategories[9] = "Award Show"
subcategories[10] = "Ballet"
subcategories[11] = "Baseball"
subcategories[12] = "Basketball"
subcategories[13] = "Beauty"
subcategories[14] = "Bicycle"
subcategories[15] = "Billiards"
subcategories[16] = "Biopic"
subcategories[17] = "Boating"
subcategories[18] = "Bodybuilding"
subcategories[19] = "Bowling"
subcategories[20] = "Boxing"
subcategories[21] = "Business and Financial"
subcategories[22] = "Children"
subcategories[24] = "Collectibles"
subcategories[25] = "Comedy"
subcategories[26] = "Computers"
subcategories[27] = "Cookery"
subcategories[28] = "Courtroom"
subcategories[29] = "Crime"
subcategories[30] = "Crime Drama"
subcategories[31] = "Curling"
subcategories[32] = "Dance"
subcategories[33] = "Docudrama"
subcategories[34] = "Documentary"
subcategories[35] = "Drama"
subcategories[36] = "Educational"
subcategories[37] = "Electronics"
subcategories[38] = "Family"
subcategories[39] = "Fantasy"
subcategories[40] = "Fashion"
subcategories[41] = "Fishing"
subcategories[42] = "American Football"
subcategories[43] = "French"
subcategories[44] = "Fundraiser"
subcategories[45] = "Game Show"
subcategories[46] = "Golf"
subcategories[47] = "Gymnastics"
subcategories[48] = "Health and Fitness"
subcategories[49] = "Historical"
subcategories[50] = "Historical Drama"
subcategories[51] = "Hockey"
subcategories[52] = "Holiday"
subcategories[53] = "Holiday Special"
subcategories[54] = "Home and Garden"
subcategories[55] = "Horror"
subcategories[56] = "Horse"
subcategories[57] = "Housewares"
subcategories[58] = "How To"
subcategories[59] = "International"
subcategories[60] = "Interview"
subcategories[61] = "Jewelry"
subcategories[62] = "Lacrosse"
subcategories[63] = "Magazine"
subcategories[64] = "Martial Arts"
subcategories[65] = "Medical"
subcategories[66] = "Motor Sport"
subcategories[67] = "Motorcycles"
subcategories[69] = "Music"
subcategories[70] = "Musical"
subcategories[71] = "Mystery and Suspense"
subcategories[72] = "Natural World"
subcategories[73] = "News"
subcategories[74] = "Olympics"
subcategories[75] = "Opera"
subcategories[76] = "Outdoors"
subcategories[77] = "Public Affairs"
subcategories[78] = "Racquetball"
subcategories[79] = "Reality"
subcategories[80] = "Religious"
subcategories[81] = "Rodeo"
subcategories[82] = "Romance"
subcategories[83] = "Romantic Comedy"
subcategories[84] = "Rugby"
subcategories[85] = "Running"
subcategories[86] = "Satire"
subcategories[87] = "Science"
subcategories[88] = "Science Fiction"
subcategories[89] = "Self Help"
subcategories[90] = "Shopping"
subcategories[91] = "Situation"
subcategories[92] = "Skating"
subcategories[93] = "Skiing"
subcategories[94] = "Sled Dogs"
subcategories[95] = "Snow Sports"
subcategories[96] = "Soap"
subcategories[97] = "Football"
subcategories[98] = "Softball"
subcategories[99] = "Spanish"
subcategories[100] = "Specials"
subcategories[101] = "Sports"
subcategories[102] = "Sports News"
subcategories[103] = "Sports Talk"
subcategories[104] = "Suspense"
subcategories[105] = "Swimming and Diving"
subcategories[106] = "Talk"
subcategories[107] = "Talk Show"
subcategories[108] = "Tennis"
subcategories[109] = "Theatre"
subcategories[110] = "Thriller"
subcategories[111] = "Track and Field"
subcategories[112] = "Travel"
subcategories[113] = "Variety"
subcategories[114] = "Volleyball"
subcategories[115] = "War"
subcategories[116] = "Water Sports"
subcategories[117] = "Weather"
subcategories[118] = "Western"
subcategories[119] = "Wrestling"
subcategories[121] = "Christmas"
subcategories[122] = "Easter"
subcategories[123] = "Thanksgiving"
subcategories[124] = "Fourth of July"
subcategories[125] = "Yom Kippur"
subcategories[126] = "Labor Day"
subcategories[127] = "New Year's Eve"
subcategories[128] = "New Year's Day"
subcategories[129] = "Hanukkah"
subcategories[130] = "Valentine's Day"
subcategories[131] = "Halloween"
subcategories[132] = "St. Patrick's Day"

var group = new Array(17)
group[0] = new Array()
group[1] = new Array(1, 2, 4, 16, 22, 25, 30, 33, 34, 35, 39, 43, 50, 55, 64, 70, 71, 80, 82, 83, 87, 88, 99, 104, 109, 110, 115, 118)
group[2] = new Array(101, 7, 11, 12, 14, 15, 17, 18, 19, 20, 31, 41, 42, 46, 47, 51, 56, 62, 64, 66, 67, 74, 76, 78, 81, 84, 85, 92, 93, 94, 95, 97, 98, 102, 103, 105, 108, 111, 114, 116, 119)
group[3] = new Array(1, 29, 64)
group[4] = new Array(5, 6, 9, 8, 10, 13, 24, 27, 32, 34, 36, 38, 40, 43, 44, 48, 52, 53, 54, 57, 58, 59, 60, 61, 63, 65, 69, 75, 76, 77, 79, 80, 89, 90, 99, 109, 112, 113, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132)
group[5] = new Array(4, 22, 25, 35, 36, 45, 52, 63, 70, 72, 100)
group[6] = new Array(4, 25, 83, 86, 91)
group[7] = new Array(45, 96, 107, 113)
group[8] = new Array(3, 16, 33, 34, 49, 60)
group[9] = new Array(28, 30, 35, 33, 50, 65, 79, 82)
group[10] = new Array(3, 16, 26, 34, 36, 37, 49, 72, 87)
group[11] = new Array(71, 104, 110)
group[12] = new Array(21, 59, 60, 63, 73, 77, 102, 106, 117)
group[13] = new Array(3, 26, 36, 37, 63, 72, 87)
group[14] = new Array(39, 88)
group[15] = new Array(25, 63, 69, 73, 77, 96, 103, 106, 107, 113)
group[16] = new Array(1)
group[16][0] = 118

function loadgenre(x, y) {
   var cat = document.search.cat
   var scat = document.search.scat
   var m,i

   for (m = cat.options.length - 1; m > 0; m--)
      cat.options[m] = null
   cat.options[0] = new Option("All", 0)
   for (i = 0; i < categories.length; i++) {
      cat.options[i+1] = new Option(categories[i], categoriesval[i])
      if (categoriesval[i] == x) { 
         cat.options[i+1].selected = true
         loadscat(i + 1)
      }
   }
   if (x == 0) {
      cat.options[0].selected = true
   } else {
      for (m = scat.options.length - 1; m > 0; m--) {
         if (scat.options[m].value == y)
            scat.options[m].selected = true
      }
   }

}

function loadscat(x) {
   var scat = document.search.scat
   var m,i 
   var y = scat.value

   for (m = scat.options.length - 1; m > 0; m--)
      scat.options[m] = null
   scat.options[0] = new Option("Don't specify a sub-category", 0)
   scat.options[0].selected = true
   for (i = 0; i < group[x].length; i++) {
      scat.options[i+1] = new Option(subcategories[group[x][i]], group[x][i])
      if (scat.options[i+1].value == y) {
        scat.options[i+1].selected = true
      }
   }
}

