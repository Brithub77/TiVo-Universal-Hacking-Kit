*** YAC: Yet Another Caller ID Program ***
***  Copyright (C) 2002 Jensen Harris  ***
***            Version 0.16            ***


WELCOME

Thanks for checking out YAC for Windows.  YAC is a Caller ID system
that uses the modem in your computer to monitor incoming phone calls.
When a phone call is received, YAC displays the Caller ID info on the
computer screen.  YAC also contacts any "YAC Listeners" on the network
and sends them Caller ID information as well.

You can also use YAC to send short text messages which are displayed
by any YAC listeners on your network.


SYSTEM REQUIREMENTS - YAC SERVER

YAC requires Windows 2000 or later and a Caller ID-compatible modem.
Most modems sold since 1998 support Caller ID, however some do not.
If in doubt, contact your modem manufacturer or check their web site.
In some cases, you might need to download an updated modem driver from
the manufacturer's web site to enable Caller ID.

You will also need to subscribe to Caller ID with your local phone
company.

If you want to broadcast to YAC listeners on the network, you will need
to be connected to a network.


SYSTEM REQUIREMENTS - YAC LISTENER

The YAC listener requires Windows 98, Windows NT 4.0, or later.


GETTING STARTED

To install YAC, simply run SETUP.EXE.  The setup program will walk
you through the process of installing YAC.

YAC is licensed and distributed under the GNU General Public License.
Be sure to read the LICENSE.TXT file before proceeding.


HOW TO USE YAC SERVER

Once setup is complete, click on the Start menu and find the YAC program
group.  You will see two shortcuts: YAC and YAC Listener.  Open YAC.

YAC should present you with a list of TAPI-compatible devices on your
computer, including your modem.  Select the modem or telephone device that
is connected to the phone line.  If you do not see your modem listed, it
might not be TAPI compliant.  Check your modem manufacturer's web site for
a driver upgrade.

You will see a new icon appear in the notifications area of the Windows
taskbar (the area near the clock).  You can click on this icon to access
various YAC actions, or to exit YAC.

When an incoming phone call with Caller ID comes in, a notification window
will appear on your screen, letting you know the name and number of the
person calling.  If no Caller ID information is available on your line,
YAC will remain silent.

To send a short text message to YAC listeners on your network, click the
YAC icon and choose "Send Text Message".

If you want YAC to be always running when your computer is on, add YAC to
your Windows Startup folder.


LISTENERS

A "listener" is another computer or device on your network that you want
to display Caller ID on.  For instance, you might have an additional
computer in another room and you want Caller ID information to pop up on
each computer.  Or, you might have a networked TiVo Personal Video Recorder
hooked up to your TV, and you want Caller ID info to appear on your TV
screen.

When YAC receives Caller ID information, it can forward this information to
up to 10 YAC listeners.  Each of these listeners then displays the Caller ID
information in the appropriate way.  The only computer that needs to have a
modem connected to the phone line is the computer running the full-blown
YAC program ("YAC" from the Start Menu).  The listeners only need to run the
"listener" software to listen for the signal from the main YAC program.
For instance, if you had a second Windows computer you wanted to also display
Caller ID information on, you would run "YAC" on the computer that is connected
to the phone line and "YAC Listener" on the secondary computer.

If your listener receives a text message that is too long to display in the
YAC popup window, simply click anywhere in the window to see the entire
message.

There's no need to run YAC Listener and YAC Server on the same computer at
the same time.


HOW TO SETUP LISTENERS FROM THE YAC SERVER

Setting up listeners from the YAC main program is easy.  Click the YAC icon,
and then click "Select Listeners..." on the menu that appears.  You will see
a dialog that gives you places to enter up to 10 listeners.  For each
listener, enter the hostname or IP address of the computer or other device
on the network.

  Examples of hostnames:
                          192.168.1.200
                          mycomputer3
                          mycomputer3.mynetwork.com

Make sure you can connect to the computer via 'ping' before entering the
hostname into YAC.  If you cannot get the hostname to work, try entering the
IP address.

To test the addresses you have entered, click the "Test Listeners" button at
the bottom of the dialog.  YAC will send a test call to each of the devices
you have entered information for.  If the YAC notification shows up on the
computer running YAC Listener, you are good to go.


DOWNLOADING OTHER LISTENERS

The YAC Listener for Windows is included in the normal YAC Windows
distribution.

Other listeners, such as the TiVo listener, can be downloaded from
http://www.sunflowerhead.com/software/yac/.


LOG FILE

YAC keeps a log file of incoming calls and messages in your YAC program
folder (usually C:\Program Files\YAC).  This file is called
"yac-log.txt" and can be opened in Notepad by double-clicking it.  If
you want to reset the log, just throw the existing log file away.  YAC
will start a new log file next time it is needed.

To open the log file while YAC is running, click the YAC icon and choose
"Open Log File".

If you don't want to keep a log file at all, you can turn it off on the
YAC Preferences menu.


NAME SUBSTITUTIONS

You can easily specify a custom name to be displayed for a telephone number
instead of the one Caller ID reports.  Select "Name Substitutions..."
from the YAC menu to get started.

The Name Substitutions dialog box shows you what custom names you have
specified for incoming phone numbers.  To add to this list, simply type
a phone number (digits only), the name you would like to be displayed,
and click Add.

To remove an item from the list, select the item and click the "Remove
selected entry" button.

You can add as many substitutions as you like.  The number you enter must
match the Caller ID information exactly, including area code.  In my area,
all numbers come in as 10 digit numbers, but local calls might not in your
area.  If in doubt, you could enter the number both with and without area
codes.


PHONE NUMBER FORMATS

YAC can be used in many different countries around the world, each of them
with one or more distinct phone number formats.  YAC lets you decide how
to display incoming phone numbers.  You can specify formatting for phone
numbers based on the number of digits in the number.  To change the list
of formats, click "Phone Number Formats" on the YAC menu.


BUGS, CONTACT INFO, AND TROUBLESHOOTING

You can contact the author with questions or problems, and I will make a best
effort to help you.  However, you might find that you get more timely help by
posting a message on the TiVo Community Forum Underground message board.

You can find out all the relevant contact information in the "About YAC"
dialog in the YAC program itself, or use this shorter list:

Web: http://www.sunflowerhead.com/software/yac/
E-mail: jensen@sunflowerhead.com
TiVo Community Forum: http://www.tivocommunity.com/ (TiVo Underground)


QUESTIONS AND ANSWERS

Q: Is the source code to YAC available?
A: Yes.  It is licensed and distributed under the terms of the GNU General
   Public License.  See the YAC web site to download it.

Q: Where do I type in my modem's AT initialization strings?
A: YAC uses TAPI, the native telephony API built into Windows.  TAPI makes it
   possible to use a wide range of modems and telephone devices without the
   user needing to manually enter cryptic strings like AT codes.
   Unfortunately, a few modem manufacturers are still producing buggy modem
   drivers that are not quite TAPI-compliant.  Check your manufacturer's web
   site for an updated driver if you are in this unfortunate minority.

Q: My modem gets Caller ID information in HyperTerminal, but it does not seem
   to work with YAC.  Do you have any suggestions?
A: Many modems have bugs in their TAPI drivers.  Check out this web page:

             http://www.talkingcallerid.com/ModemDriver.htm

   This page details a popular class of modems and how to work around problems
   with their installation routines.

Q: What's a listener?
A: A listener is simply a program that listens to a specific TCP port (in
   YAC's default case, this is port 10629), accepts connections, and then
   displays whatever text was sent to the port in whatever way makes sense
   to the device.  For instance, the YAC TiVo listener monitors port
   10629, waits for a connection, and then displays on the TV screen any
   text that is sent from the YAC server.

Q: I'm trying to send text messages to my TiVo, but it's displaying nothing
   or garbage on my TV screen.
A: You need to download the YAC TiVo Listener version 0.15 or later from
   http://www.sunflowerhead.com.

Q: Can I write a listener for my platform/device?
A: Sure.  You can find a short SDK titled, appropriately, "YAC Software
   Developer's Kit" on the YAC web site.  If you do write a new listener,
   let me know and I'll post it on the YAC web site.

Q: Can I control how long the YAC call notification window stays up?
A: Sure, as long as you're using the YAC user interface and not the old-style
   balloon option available in Win2K and XP.  Open the registry key
   HKEY_LOCAL_MACHINE\Software\YAC, and set:
   DisplayTime = [time in milliseconds].  The default is 20000 (20 seconds).

Q: Can YAC use a different port?
A: Yes.  Open HKEY_LOCAL_MACHINE\Software\YAC, and set Port = [PortNumber].  This
   key needs to be a string of type REG_SZ.  The default is TCP port 10629.

Q: What should I do if YAC is not telling me about incoming calls?
A: Does your modem support Caller ID?  Check with your manufacturer.  If you
   think that it does, there are various other Caller ID programs available on
   the web (for instance on http://www.download.com/).  If one of these programs
   presents Caller ID information and YAC doesn't on the same system, I'd love to
   know about it.