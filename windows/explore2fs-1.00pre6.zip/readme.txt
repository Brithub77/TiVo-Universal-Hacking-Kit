    explore2fs, the Linux file system utility for Windows NT
    Copyright (C) 2000  John Newbigin

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

NOTE: This is a pre-release version.  I will get round to a real release soon (I hope).
      Util then, enjoy the new features, and keep sending in bug reports.

!!! W A R N I N G !!!
---------------------

Use write access at your own risk!  Although it seems to work for me, it is 
possible that a bug could cause your filesystem or even disk to become unusable!
Now, with that out of the way, make sure read support is working, then when you 
are feeling clam and collected, try write support.  Test it first on a file
before you try it on a partition if you must.  What ever you do, make sure you 
know how to restore your system should anything go wrong.  That includes both Linux
and NT, and any other partitions you may happen to have.  It is a very good idea to
do a backup before you begin.


What is this program?

This is an explorer like program which can read and interpret the ex2fs filesystem.  


Why is it written in Delphi?

I like Delphi.  It allows great user interfaces to be designed in a very short 
amount of time.  The problem is however that processing large amounts of data, or 
performing pointer arithmetic is difficult and clumsy.  So I decided that I would take 
the challenge and write a useful program in Delphi.


Why is this not a filesystem driver?

I have started development of an IFS for NT.  When I have something working I will
release it but at the moment I am just working out the basic structure of the driver.

I do not have the IFS development kit which costs $1000US so I am still open to donations.


What OS does it run on?

Initaly I wrote this program for Windows NT.  There were calls for Win95 support so I
eventualy came up with a solution.  It is far from elegant but should work on most
systems.  Currently Explore2fs will run on Windows NT, Windows 2000, Windows 95 and Windows 98.
It does not work under Win32s and probably never will.


Has it been tested?

Read support has been extensivly tested on many machines, IDE and SCSI.  It works with all
blocks sizes, 1k, 2k and 4k.

Some people have problems under 95.  Please read the section on Windows 95 further down.

I have tested write support but there are still bugs.  I need people however to allert me to
them before I can fix them :).  If you are keen you could track them down for me.

I have received more frequent reports of problems with the write support so make sure that
you have a backup of your system before you play with it.  Do not use it on a production
system.  (Why would you have a dual boot production system?)

I something doesn't seem to be working, enable full debugging and send me a copy of the 
debug log along with a description of the problem and I will try and fix it.


What doesn't work?

Nothing?

For a more complete list of features, look at the changes file.

Windows 95
----------

As of 1.00 pre2, there is support for extended int 13.  This should solve problems with
large disks under 95/98.  

This also requires that the disk contain a boot sector.  For hard disks this will not be a
problem, but if you have a linux floppy, you will have to copy a standard MSDOS boot sector
onto it.  This can be done by the following commands:
- Insert a dos disk in fd0 (or whatever your floppy drive is)
- type: dd if=/dev/fd0 of=/tmp/bootsector.dos bs=512 count=1
- Insert your Linux disk, or type: mke2fs /dev/fd0 (to create a new one)
- type: dd of=/dev/fd0 if=/tmp/bootsector.dos bs=512 count=1

And you should be right.

Note: DO NOT DO THIS TO YOUR HARD DISK! or you will end up crying.

Windows NT
----------

As of version 1.00 pre4 there is support for NT Native IO.  This bypasses the Win32 API
and uses NTDLL.DLL directly.  This means that the partition devices used internaly by NT
can be used.  This means that my parition scan code is not used which should solve problems
people have with Partition Magic.  The down side is that you don't know the partition type,
number or size.  This means that the partitions are labeled wrong (or at least differently)
to the previous method.  I have also dissable write support using this method for the moment
as I have not had a chance to test it.

Using user names and group names
--------------------------------
If you want to display user names and group names instead of id's, you can select a passwd file
and group file from the options dialog.  First you should export the appropriate files from you
linux partition.  If you don't want to use this feature, remove the file names in the options
dialog.

Note that the same user names and gropus are used for all partitions.

Floppy support
--------------
If you want to use floppy support, you will have to make sure that floppy support is selected
under the general options.  The floppy drive will show up as fda0. If you have a LS-120 drive, 
or other non-floppy floppy drive (ie. not on the floppy bus (meaning IDE or SCSI)) then you may
have it partitioned.  If partitions are found, they will show up as fda1, fda2 etc.



Where do I find the latest version?

There is a homepage at http://uranus.it.swin.edu.au/~jn/linux/
This page will contain the latest information and versions.

How do I contact the author?

I can be contacted by e-mail: jn@it.swin.edu.au
or snail-mail
  John Newbigin
  8 Robinson Ct.
  North Bayswater  3151
  Vic   Australia

