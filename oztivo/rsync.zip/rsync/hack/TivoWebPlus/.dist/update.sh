#!/bin/bash
#
################################################################
# Script is called from $source_dir/.. (eg /var/hack)          #
################################################################
#
# Should keep this very simple as we do not know what binaries
# are available on the destination system.  The script only
# requires that cpio is in the PATH.
#
################################################################

file="$1"
dist="TivoWebPlus/.dist"
conf=${TWP_DATA_DIR:-TivoWebPlus}

error() {
  echo "update.sh: $1"
  rm -f "$file" $dist/config.cpio
  exit 1
}

################################################################
#
# Check that there is a TivoWebPlus subdirectory, containing
# a distribution directory
#
################################################################
if test ! -d TivoWebPlus; then
  error "Could not locate the existing TivoWebPlus directory"
fi
if test ! -d $dist; then
  error "Could not locate the distribution directory"
fi

################################################################
#
# Check that the bundle can be found
#
################################################################
if test ! -f "$file"; then
  error "Could not locate the bundle: $file"
fi

################################################################
#
# Check that the required binaries could be found in the PATH
#
################################################################
if ! cpio --version >/dev/null 2>&1; then
  error "Could not find the cpio binary (PATH=$PATH)"
fi

################################################################
#
# Backup the exiting configuration files, just in case they
# contain customisations
#
################################################################
echo " - Backup existing configuration files"
cat $dist/update-config.lst |\
cpio -o --quiet -O $dist/config.cpio 2>/dev/null

################################################################
#
# Extract the new TivoWebPlus software from the bundle
#
################################################################
old_ver=`cat $dist/version`
echo " - Extract new software"
cpio -idum --quiet -H tar 'TivoWebPlus/*' < "$file"
rm -f "$file"
new_ver=`cat $dist/version`

#
# Cleanup any modules that may exist during a downgrade
#
rm -f TivoWebPlus/libs/index.itcl
rm -f TivoWebPlus/libs/http.itcl
rm -f TivoWebPlus/libs/ui.itcl
rm -f TivoWebPlus/load.tcl
rm -f TivoWebPlus/modules/confirm.itcl
rm -f TivoWebPlus/modules/thumbs.itcl
rm -f TivoWebPlus/modules/ui_*.itcl
rm -f TivoWebPlus/modules/*.tcl


################################################################
#
# Check that the update was successful
#
################################################################
if test "$old_ver" = "$new_ver"; then
  echo " * WARNING: The software version did not change"
  echo " *          It is still '$old_ver'"
else
  echo " - Software updated from '$old_ver' to '$new_ver'"
fi

################################################################
#
# Restore the previously backed up configuration files
#
################################################################
echo " - Restore previous configuration files"
cpio -idum --quiet -I $dist/config.cpio 2>/dev/null
rm -f $dist/config.cpio

################################################################
#
# Check to see if we are "upgrading" from v1.4.0 to 1.3.1
#
################################################################
if test -f "$conf/config/tivoweb.cfg"; then
  echo " - Restore tivoweb.cfg from v1.4.0 config directory"
  cp "$conf/config/tivoweb.cfg" TivoWebPlus/tivoweb.cfg
  rm -rf "$conf/config"
fi

################################################################
#
# Schedule the software to restart in 10 seconds
#
################################################################
echo " - TivoWebPlus restarting in 10 seconds"
LOG=TivoWebPlus/.dist/restart.log
(sleep 10; rm -f $0; cd TivoWebPlus; ./tivoweb restart) </dev/null >$LOG 2>&1 &

