#!/bin/bash
#
################################################################
# Usage: extract.sh <source_dir> <package name>                #
################################################################
#
# This script is responsible for extracting the update script
# from the package and then executing it from the correct
# working directory ($source_dir/..)
#
################################################################
#
# Should keep this very simple as we do not know what binaries
# are available on the destination system.  The script only
# requires that gzip and cpio are in the PATH.
#
################################################################

source_dir="$1"
file="$2"

error() {
  echo "extract.sh: $1"
  exit 1
}

################################################################
#
# Check that the installation is in the TivoWebPlus directory
#
################################################################
if test ! -d $source_dir/../TivoWebPlus; then
  rm -f "$file"
  error "Could not locate the TivoWebPlus directory"
fi

################################################################
#
# Check that the bundle we were provided can be found
#
################################################################
if test ! -f "$file"; then
  rm -f "$file"
  error "Could not locate the bundle: $file"
fi

################################################################
#
# Check that the required binaries could be found in the PATH
#
################################################################
if ! cpio --version >/dev/null 2>&1; then
  rm -f "$file"
  error "Could not find the cpio binary (PATH=$PATH)"
fi
if ! gzip --version >/dev/null 2>&1; then
  rm -f "$file"
  error "Could not find the gzip binary (PATH=$PATH)"
fi

################################################################
#
# Check that we have enough available disk space
#
################################################################
function nthword () {
  n=0
  for foo in $* ; do
    if [ $n -eq $1 ]
    then
      echo $foo
    fi
    n=$(($n+1))
  done
}

dfspace=$(df -Pk $source_dir/.dist)
if test -n "$dfspace"; then
  spaceavail=$(nthword 11 $dfspace)
  if test -n "$spaceavail"; then
    if test $spaceavail -lt 2048; then
      rm -f "$file"
      error "There is not enough free disk space (${spaceavail}k)"
    fi
  else
    echo " * WARNING: Unable to determine available disk space"
  fi
else
  echo " * WARNING: Unable to determine free disk space"
fi

################################################################
#
# Decompress the software bundle
#
################################################################
gzip -cd "$file" > $source_dir/.dist/software.tar
rm -f "$file"

################################################################
#
# Change into the parent directory ready for software extraction
#
################################################################
cd $source_dir/..

# variable holding the location of the distribution directory
dist="TivoWebPlus/.dist"

################################################################
#
# Extract the update script from the software bundle
#
################################################################
echo " - Extract update script"
rm -f $dist/update.sh
cpio -idum --quiet -H tar $dist/update.sh < $dist/software.tar
if test ! -x $dist/update.sh; then
  rm -f $dist/software.tar
  error "The bundle did not contain an update script"
fi

################################################################
#
# Rename the script so that the extraction of the bundle
# software will not overwrite the currently executing script.
#
################################################################
cp $dist/update.sh $dist/update1.sh
exec $dist/update1.sh $dist/software.tar

