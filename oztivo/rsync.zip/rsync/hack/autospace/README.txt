autospace is an automatic on screen free space indicator for Series 1 TiVos


Version V1.1 (01/16/2004)

Disclaimer:

This program should have no adverse effects on your TiVo, but please make
a backup of whatever you care about *before* running any code for the first
time.  Opening unit voids warranty...the usual stuff.  If you mess it up,
it ain't my fault.

This program uses the smallest footprint I could devise.  It checks for
screen (context) change events and it's own events.  If none of these are
received, it won't do anything.  When it does get activated, it gets the
data it needs, displays it, and waits for a new event.  This program also
sets it's priority to the lowest possible (fifo 1).

All that said, I make no guarantees that this program will work at all.  I
don't have any machines running < version 3, but thanks to sanderton, support
for all versions of software on Series 1 is now built in.  Since the Series 2
OSD is different from the Series 1, it cannot work on a Series 2.

No modifications are made to MFS by this program, but you still cannot use
kill to shut it down.  tivosh gets upset and reboots the TiVo if you kill
a tivosh script that ever does dbopen.  I've solved this issue by using the
event facility to signal shutdown.  The event number used isn't in use by
the normal TiVo software.  However, if it does get used by other software in
the future, this program can use any free event number.

osdcons is a C program to control the on screen display for a series 1 with
something resembling VT100 style escape codes.  I didn't put the source in
the distribution, but the source is available under GPL.

If there is a bug in the program, the error log is in /tmp/autospace.log
The errors from any crash will show up there, but the file is nulled every
time the program is started normally.  Save a copy of the output if it
crashes before you restart it.

Anyway, if all this works for you, great.  If not, sorry.


Operation:

Once started, the program waits for the TiVo to go to the Now Showing screen.
Upon entry of that screen (After the TiVo populates the screen), the top of
the screen is overwritten with 'Getting Data.'  There are 3 steps to get the
space data and another '.' is written after each to verify progress.  Once
done, the space information is displayed on the top 2 lines.  After the space
information is retrieved, the cached data will be used for up to 30 minutes.
To refresh the data immediately, go to TiVo Central (or DirecTv Central) and
then re-enter Now Showing (or Now Playing).  Every time you go directly from
TiVo Central to Now Showing, the data is immediately recalculated.  Any other
entry to Now Showing is subject to the 30 minute timeout.  The theory here is
that Now Showing is usually slow enough.  Most functions to do with recorded
programming have to visit Now Showing every so often (deleting, watching...)
However, going to the main TiVo menu and back again isn't normally done all
too often.  When it is done, the space information will be up to date.

Descriptions of included data:

Top Center: Total Count.  This is the total count of programs on the Now
                          Showing screen.
Top Right: Counts.        This is the total in each category.  Cyan is
                          Permanent Shows (Save until I delete).  Yellow is
                          normal shows.  Grey is suggestions.  These 3 fields
                          should total to the Total Count field.
Bottom Middle: Graph.     Space used in 2% increments.  Uses the following
                          color scheme:
Over Graph: Percent Used. This is the precentage of space used to hold content.
                          Suggestions and free space are not included.

  Red:    Live Buffers / Recording Buffers / Overhead.  Anything not otherwise
          counted in the next fields that is in use is placed here.
  Cyan:   Save unil I delete recordings.
  Yellow: Any other requested recording regardless of expiration status.
  Grey:   Suggestions
  None:   Deleted recordings / Free space

Bottom Right:            Now Recording Indicatior.  Indicates what is currently
                         being recorded according to the following color
                         scheme:

  Red:    Hidden Program (TiVo Service Data)
  Cyan:   Save until I delete recordings
  Yellow: Requested Recording
  Grey:   Suggestion


Installation:

Put the following files somewhere on your TiVo (in the same directory).  They
can also reside in the $PATH.  This directory will be referenced as <directory>

 autospace.tcl
 osdcons
 setpri

Make sure everything is executable:

 cd <directory>
 chmod 755 autospace.tcl
 chmod 755 osdcons
 chmod 755 setpri

autospace is now installed.

Usage: /<directory>/autospace.tcl
 Args:       <none>  - Start daemon
             start   - Start daemon without checking for previous one already running
             status  - Determine status of daemon
             restart - Terminate and restart daemon
             exit    - Terminate daemon

Running:

bash-2.02# /<directory>/autospace.tcl
INFO: osdcons started (Pid: 123, Priority: fifo 1)
INFO: daemon started, output is in /tmp/autospace.log

Automating the startup:

Put the following in /etc/rc.d/rc.sysinit or rc.sysinit.author

/<directory>/autospace.tcl start >/dev/null 2>&1

[ You can put a trailing & in the above line, but it isn't needed.  It backgrounds itself ]

