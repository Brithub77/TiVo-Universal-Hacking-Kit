function moveOption(selectObj, direction)
      {
        if(selectObj.selectedIndex != -1)
        {
          if(direction < 0)
          {
            for(i = 0; i < selectObj.options.length; i++)
            {
              swapValue = (i == 0 || selectObj.options[i + direction].selected) ? null : selectObj.options[i + direction].value;
              swapText = (i == 0 || selectObj.options[i + direction].selected) ? null : selectObj.options[i + direction].text;
              if(selectObj.options[i].selected && swapValue != null && swapText != null)
              {
                thisValue = selectObj.options[i].value;
                thisText = selectObj.options[i].text;
                selectObj.options[i].value = swapValue;
                selectObj.options[i].text = swapText;
                selectObj.options[i + direction].value = thisValue;
                selectObj.options[i + direction].text = thisText;
                selectObj.options[i].selected = false;
                selectObj.options[i + direction].selected = true;
              }
            }
          }
          else
          {
            for(i = selectObj.options.length - 1; i >= 0; i--)
            {
              swapValue = (i == selectObj.options.length - 1 || selectObj.options[i + direction].selected) ? null : selectObj.options[i + direction].value;
              swapText = (i == selectObj.options.length - 1 || selectObj.options[i + direction].selected) ? null : selectObj.options[i + direction].text;
              if(selectObj.options[i].selected && swapValue != null && swapText != null)
              {
                thisValue = selectObj.options[i].value;
                thisText = selectObj.options[i].text;
                selectObj.options[i].value = swapValue;
                selectObj.options[i].text = swapText;
                selectObj.options[i + direction].value = thisValue;
                selectObj.options[i + direction].text = thisText;
                selectObj.options[i].selected = false;
                selectObj.options[i + direction].selected = true;
              }
            }
          }
        }
      }
  
function selectAll(selectObj)
      {
        for(i = 0; i < selectObj.options.length; i++)
        {
          selectObj.options[i].selected = true;
        }
        return false;
      }
      
function moveOptionVar(selectObj, direction, slots)
            {
              if(selectObj.selectedIndex != -1)
              {
                for(x = 0; x < slots; x++)
                {
                if(direction < 0)
                {
                  for(i = 0; i < selectObj.options.length; i++)
                  {
                    swapValue = (i == 0 || selectObj.options[i + direction].selected) ? null : selectObj.options[i + direction].value;
                    swapText = (i == 0 || selectObj.options[i + direction].selected) ? null : selectObj.options[i + direction].text;
                    if(selectObj.options[i].selected && swapValue != null && swapText != null)
                    {
                      thisValue = selectObj.options[i].value;
                      thisText = selectObj.options[i].text;
                      selectObj.options[i].value = swapValue;
                      selectObj.options[i].text = swapText;
                      selectObj.options[i + direction].value = thisValue;
                      selectObj.options[i + direction].text = thisText;
                      selectObj.options[i].selected = false;
                      selectObj.options[i + direction].selected = true;
                    }
                  }
                }
                else
                {
                  for(i = selectObj.options.length - 1; i >= 0; i--)
                  {
                    swapValue = (i == selectObj.options.length - 1 || selectObj.options[i + direction].selected) ? null : selectObj.options[i + direction].value;
                    swapText = (i == selectObj.options.length - 1 || selectObj.options[i + direction].selected) ? null : selectObj.options[i + direction].text;
                    if(selectObj.options[i].selected && swapValue != null && swapText != null)
                    {
                      thisValue = selectObj.options[i].value;
                      thisText = selectObj.options[i].text;
                      selectObj.options[i].value = swapValue;
                      selectObj.options[i].text = swapText;
                      selectObj.options[i + direction].value = thisValue;
                      selectObj.options[i + direction].text = thisText;
                      selectObj.options[i].selected = false;
                      selectObj.options[i + direction].selected = true;
                    }
                  }
                }
              }
              }
      }
      
      
      function moveOptionAllWay(selectObj, direction)
                  {
                    if(selectObj.selectedIndex != -1)
                    {
                      for(x = 0; x < selectObj.options.length; x++)
                      {
                      if(direction < 0)
                      {
                        for(i = 0; i < selectObj.options.length; i++)
                        {
                          swapValue = (i == 0 || selectObj.options[i + direction].selected) ? null : selectObj.options[i + direction].value;
                          swapText = (i == 0 || selectObj.options[i + direction].selected) ? null : selectObj.options[i + direction].text;
                          if(selectObj.options[i].selected && swapValue != null && swapText != null)
                          {
                            thisValue = selectObj.options[i].value;
                            thisText = selectObj.options[i].text;
                            selectObj.options[i].value = swapValue;
                            selectObj.options[i].text = swapText;
                            selectObj.options[i + direction].value = thisValue;
                            selectObj.options[i + direction].text = thisText;
                            selectObj.options[i].selected = false;
                            selectObj.options[i + direction].selected = true;
                          }
                        }
                      }
                      else
                      {
                        for(i = selectObj.options.length - 1; i >= 0; i--)
                        {
                          swapValue = (i == selectObj.options.length - 1 || selectObj.options[i + direction].selected) ? null : selectObj.options[i + direction].value;
                          swapText = (i == selectObj.options.length - 1 || selectObj.options[i + direction].selected) ? null : selectObj.options[i + direction].text;
                          if(selectObj.options[i].selected && swapValue != null && swapText != null)
                          {
                            thisValue = selectObj.options[i].value;
                            thisText = selectObj.options[i].text;
                            selectObj.options[i].value = swapValue;
                            selectObj.options[i].text = swapText;
                            selectObj.options[i + direction].value = thisValue;
                            selectObj.options[i + direction].text = thisText;
                            selectObj.options[i].selected = false;
                            selectObj.options[i + direction].selected = true;
                          }
                        }
                      }
                    }
                    }
      }
