#!/bin/bash

# This is the example script for the runscript module (script.itcl)
# you can modify this to suit your needs so you can run all sorts
# of useful things from Tivo web.

# A free-form input box has been added to allow you to execut random
# bash commands in addition to the fixed commands as part of the default
# menu.

# This command redirects stderr to stdout so tivo shows output
exec 2>&1

# Not bad idea to include a PATH
PATH=/sbin:/bin:/devbin:/tivobin:/busybox:/usr/local/bin:/var/hack/bin:/hack/bin:/etc:/tvbin:.

main_menu() {
  # main menu here. Change to suite your needs
  cat << EOF
<b>
<font size=2>
-------------------------------
Main Script Menu 
-------------------------------

<a href="script?params=1">Click here to start mfsftp</a>
<a href="script?q=/bin/tivoftpd&params=cmd">Click here to start tivoftpd</a>
<a href="script?q=/sbin/tnlited+23+/bin/bash&params=cmd">Click here to Start telnet daemon</a>
<a href="script?params=4">Click here to Start TyServer</a>
<a href="script?params=5">Click here to Start Vserver</a>
<a href="script?q=ps+x&params=cmd">Click here to View Processes</a>
<a href="script?q=cat+/proc/modules&params=cmd">Click here to View Modules</a>

<a href="script?q=restart&params=cmd">Click here to Restart Tivo</a>

<form method="get" action="/script/">
Command:&nbsp;<input type="text" name="q">&nbsp;<input type="submit" value="Execute">	
<input type="hidden" name="params" value="cmd">
</form>
</b>
</font>
EOF
}

param=$1
q=$2

case $param in
  "")
    main_menu
    exit
    ;;
  1)
	  # execute commands for option 1
	  echo 
	  echo starting mfs_ftp
	  echo 
    cd /var/mfs_ftp
	  mfs_ftp.tcl  &
    ;;
  4)
	  echo 
	  echo Staring TyServer
	  echo 
	  /usr/tytools/tserver_mfs7_mips -s /usr/tytools/NowShowing.tcl > /dev/null 2>&1 &
  ;;
  5)
	  echo 
	  echo Staring Vserver
	  echo 
	  /var/vserver/vserver > /dev/null 2>&1 &
    ;;
  cmd)
	  echo 
	  echo Executing Command
	  echo 
    case $q in
      lsmod) cat /proc/modules;;
      *)     $q && > /dev/null 2>&1 &;;
	  esac
    ;;
  *)
	  # this is here if we receive an undefined menu option
	  echo
	  echo Hmmmmm......
	  echo
	  echo I don\'t really know what to do right now... sorry
	  echo
    ;;
esac

# provide a click-back to the main script
cat << EOF
<font size=2>
<a href="script" >Click here to Return to Main Script Menu</a>
</font>
EOF
