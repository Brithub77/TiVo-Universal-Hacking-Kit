#!/bin/bash
#
################################################################
# Script is called from $source_dir/.. (eg /var/hack)          #
################################################################
#
# Should keep this very simple as we do not know what binaries
# are available on the destination system.  The script only
# requires that cpio is in the PATH.
#
################################################################

file="$1"
dist="TivoWebPlus/.dist"
conf=${TWP_DATA_DIR:-TivoWebPlus}
test "$conf" = "./" && conf=TivoWebPlus

error() {
  echo "update.sh: $1"
  rm -f "$file" $dist/config.cpio
  exit 1
}

################################################################
#
# Check that there is a TivoWebPlus subdirectory, containing
# a distribution directory
#
################################################################
if test ! -d TivoWebPlus; then
  error "Could not locate the existing TivoWebPlus directory"
fi
if test ! -d $dist; then
  error "Could not locate the distribution directory"
fi

################################################################
#
# Check that the bundle can be found
#
################################################################
if test ! -f "$file"; then
  error "Could not locate the bundle: $file"
fi

################################################################
#
# Check that the required binaries could be found in the PATH
#
################################################################
if ! cpio --version >/dev/null 2>&1; then
  error "Could not find the cpio binary (PATH=$PATH)"
fi

################################################################
#
# Backup the exiting configuration files, just in case they
# contain customisations
#
################################################################
# echo " - Backup existing configuration files"
# cat $dist/update-config.lst |\
# cpio -o --quiet -O $dist/config.cpio 2>/dev/null


################################################################
#
# Extract the new TivoWebPlus software from the bundle
#
################################################################
old_ver=`cat $dist/version`
echo " - Extract new software"
cpio -idum --quiet -H tar 'TivoWebPlus/*' < "$file"
rm -f "$file"
new_ver=`cat $dist/version`

rm -f $conf/config/module*.cfg

#
# Cleanup any modules that we have moved
#
rm -f TivoWebPlus/modules/ui_util.tcl
rm -f TivoWebPlus/modules/ui_util.itcl
rm -f TivoWebPlus/modules/ui_new.itcl
rm -f TivoWebPlus/modules/ui_init.itcl
rm -f TivoWebPlus/modules/folders_util.tcl

rm -f TivoWebPlus/modules/debug.itcl
rm -f TivoWebPlus/modules/favicon.itcl
rm -f TivoWebPlus/modules/index.itcl
rm -f TivoWebPlus/modules/lj_utils.itcl
rm -f TivoWebPlus/modules/sched.itcl
rm -f TivoWebPlus/modules/ui.itcl
rm -f TivoWebPlus/modules/xlist.itcl
rm -f TivoWebPlus/modules/\{more\}.cfg
rm -f TivoWebPlus/modules/\{more\}.itcl

rm -f TivoWebPlus/modules/displaytext.itcl
rm -f TivoWebPlus/modules/script.sh
rm -f TivoWebPlus/modules/script.itcl


################################################################
#
# Check that the update was successful
#
################################################################
if test "$old_ver" = "$new_ver"; then
  echo " * WARNING: The software version did not change"
  echo " *          It is still '$old_ver'"
else
  echo " - Software updated from '$old_ver' to '$new_ver'"
fi

################################################################
#
# Restore the previously backed up configuration files
#
################################################################
#echo " - Restore previous configuration files"
#cpio -idum --quiet -I $dist/config.cpio 2>/dev/null
#rm -f $dist/config.cpio

################################################################
#
# Schedule the software to restart in 10 seconds
#
################################################################
#echo " - TivoWebPlus restarting in 10 seconds"
#(sleep 10; rm -f $0; cd TivoWebPlus; ./tivoweb restart) >/dev/null </dev/null &

rm -f $0
