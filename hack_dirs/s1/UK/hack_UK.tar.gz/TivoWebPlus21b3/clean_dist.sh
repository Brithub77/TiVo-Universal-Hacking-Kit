#
# Remove files only found in previous distributions
#
rm -f ./.dist/BlockFailure
rm -f ./.dist/CrashCount
rm -f ./.dist/chksum-060818.lst
rm -f ./.dist/{z}.itcl
rm -f ./config/module_cache.cfg
rm -f ./config/tvres-2.0.res
rm -f ./config/tvres-2.5.res
rm -f ./config/tvres-3.0.res
#rm -f ./modules/confresManual.cfg
rm -f ./modules/debug.itcl
rm -f ./modules/displaytext.itcl
rm -f ./modules/favicon.itcl
#rm -f ./modules/higuide.cfg
rm -f ./modules/index.itcl
rm -f ./modules/lj_utils.itcl
#rm -f ./modules/manrec.cfg
#rm -f ./modules/recoptions.cfg
rm -f ./modules/rss_util.tcl
rm -f ./modules/sched.itcl
rm -f ./modules/script.itcl
rm -f ./modules/script.sh
rm -f ./modules/ui.itcl
rm -f ./modules/xlist.itcl
rm -f ./modules/{more}.cfg
rm -f ./modules/{more}.itcl
rm -f ./scripts/genericgenre.js
rm -f ./tivoweb.cfg
