#!/bin/sh
#
############################################################################
#
# ./check_dist.sh [[-all] [-update] <tag> | [-images]]
#
#  -all     Check all files rather than just the recently modified ones
#  -update  Update the checksums with those of the existing files
#  -images  Check the PNG files in the images directory for those not used
#  -simple  Do not perform the extended checks against TCL scripts
#  <tag>    Determines which checksum file to use, defaults to oztivo
#
############################################################################
#
while test -n "$1"; do
  case "$1" in
    -all)       all="yes";;
    -update)    update="yes";;
    -update-du) update="du";;
    -simple)    simple="yes";;
    -images)    images="yes";;
    *)          break;;
  esac
  shift
done

if test "$images" = "yes"; then
  (cd images; ls -1 *png) | grep -v 'conflict[1-4].png' |\
  while read file; do
    found=`cat *tcl modules/* libs/* | grep -c "$file"`
    if test $found -eq 0; then
      echo "Image not required - $file"
    fi
  done
fi

sum --version >/dev/null 2>&1
if test $? -ne 127; then
  cut --version >/dev/null 2>&1
  if test $? -ne 127; then
    sum=sum
  else
    echo "NOTE: 'cut' not found, reverting to 'du' comparison"
    sum=du
  fi
else
  echo "NOTE: 'sum' not found, reverting to 'du' comparison"
  sum=du
fi
if test "$update" = "du"; then
  echo "NOTE: using 'du'"
  sum=du
  update=yes
fi

if test -n "$1"; then
  list=.dist/chk$sum-$1.lst
else
  list=.dist/chk$sum-oztivo.lst
fi

if test ! -r $list; then
  shopt -s extglob
  cd ${0%%+([^/])} >/dev/null 2>&1
  if test ! -r $list; then
    echo "ERROR: Can't read checksum list ($list)"
    exit
  fi
fi

if test "$update" = "yes"; then
  sed --version >/dev/null 2>&1
  if test $? -eq 127; then
    echo "NOTE: The sed binary is required for updates"
    exit
  fi
fi

find --version >/dev/null 2>&1
if test $? -eq 127; then
  echo "NOTE: The find binary is required to check the distribution"
  exit
fi

(
  if test "$all" = "yes"; then
    find . -type f
  else
    find . -type f -newer $list
  fi
) | grep -Ev '^\./(\.dist/(version|.*\.lst)|config|scripts/genericgenre.js)' |\
while read file; do
  if test "$sum" = "sum"; then
    chksum=`sum "$file"`
    savsum=`grep " $file\$" $list 2>/dev/null | cut -c 1-11`
  else
    chksum=`du -b "$file"`
    savsum=`grep "[[:space:]]$file\$" $list 2>/dev/null`
  fi
  if test -z "$savsum"; then
    echo "$file was not included in the distribution"
    if test "$update" = "yes"; then
      if test "$sum" = "sum"; then
        echo "$chksum $file" >> $list 2>/dev/null
      else
        echo "$chksum" >> $list 2>/dev/null
      fi
    fi
  else
    if test "$chksum" != "$savsum"; then
      echo "$file differs from the distribution"
      if test "$update" = "yes"; then
        if test "$sum" = "sum"; then
          sed "s,^........... $file\$,$chksum $file," $list > $list-$$
        else
          sed "s,^.*$file\$,$chksum," $list > $list-$$
        fi
        mv $list-$$ $list
      fi
    fi
  fi
  if test "$simple" != "yes"; then

    if test `echo "$file" | grep -c ".*tcl"` -ne 0; then
      if test `grep -c '' "$file"` -ne 0; then
        echo "$file contains Ctrl-M's"
      fi
      if test `grep -c '^ *	' "$file"` -ne 0; then
        echo "$file contains initial TABs"
      fi
      if test `echo "$file" | grep -Evc 'ui_init.itcl|cidrss'` -ne 0; then
        if test `grep -ic 'if .* = ' "$file"` -gt 0; then
          echo "$file has invalid comparison; '=' rather than '=='"
        fi
      fi
      if test `echo "$file" | grep -Evc '((info|ui_record|ui_season_pass|index|folders).itcl)|init.tcl'` -ne 0; then
        if test `grep -ic 'sort -integer' "$file"` -gt 0; then
          echo "$file contains 'sort -integer'"
        fi
      fi
      line=`mawk '/^[ \t*#]/ {next} /[^}"\]]$/ {if (length($0) == 79) {line=$0;getline; if (/^[^ \t#]/) {print line; exit}}}' "$file"`
      if test -n "$line"; then
        echo "$file may contain a truncated line (line follows):"
        echo "$line"
      fi
    fi
  fi
done

(
  if test "$sum" = "sum"; then
    cut -c 12- $list
  else
    cut -f 2 $list
  fi
) |\
while read file; do
  if test ! -r "$file"; then
    echo "$file is missing from your installation"
  fi
done

