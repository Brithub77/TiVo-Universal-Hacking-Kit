function CheckAll(x, y) {

  for (var i=0; i < document.form.elements.length; i++) {
          var c = document.form.elements[i];
          if ((c.name.substr(0,x.length) == x) && (c.type == 'checkbox')) {
            c.checked = y;
          }
        }
}
