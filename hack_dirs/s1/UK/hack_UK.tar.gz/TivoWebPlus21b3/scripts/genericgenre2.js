// completely rewritten, now uses raw data from genrenums and genrevals
// and loadscat() now takes the value, not the index--btux9

function init_genres() {
  var cat = document.search.cat
  var j,i,n
  //~ gindex= new Array

  //~ for (i=0; i<genres.length; i++)
    //~ gindex[genres[i]]= i
  //cat.options[0] = new Option("All", 0)
  n=0
  for (i = 0; i+1 < genrecats.length; i++) {
    j= genrecats[i]
    //~ j= gindex[i]
    //~ if (j == null) continue
    cat.options[++n] = new Option(genrevals[j], genres[j])
  }
}

function loadgenre(x, y) {
  var cat = document.search.cat
  var scat = document.search.scat
  var i

  if (cat.options[1]==null) init_genres()
  if (x == 0) {
    cat.options[0].selected = true
    loadscat(0)
    return
  }
  for (i=cat.options.length; i-->0; )
    if (cat.options[i].value == x) {
      cat.options[i].selected = true
      loadscat(i)
      break
    }
  for (i=scat.options.length; i-->0; )
    if (scat.options[i].value == y) {
      scat.options[i].selected = true
      break
    }
}

function loadscat(x) {
  var scat = document.search.scat
  var cat = document.search.cat
  var i
  var y = scat.value

  for (i = scat.options.length; i-->1;) scat.options[i] = null
  if (x==0 || x==null) return
  x= cat.selectedIndex-1

  scat.options[0].selected = true
  var j=0
  i= genrecats[x]
  if (genrevals[i]=="Genre") {
    x=0
    i=genrecats[0]
  }
  while (++i<genrecats[x+1]) {
    scat.options[++j] = new Option(genrevals[i], genres[i])
    if (genres[i] == y)
      scat.options[j].selected = true
  }
}
