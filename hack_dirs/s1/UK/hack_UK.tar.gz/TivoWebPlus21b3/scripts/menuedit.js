// MenuEdit.js
//  client-side code for menus.itcl
//  author: SteveT

setupdragtargets();

// setup drag&drop targets
function setupdragtargets() {
  var uls = document.getElementsByClassName("dragUL");
  //copy ids into array for containment
  var aryContainment = new Array();
  for (var i = 0; i < uls.length; i++) {
    aryContainment[i] = uls[i].id;
  }
  //setup each dragUL to allow drop on others
  for (var i = 0; i < uls.length; i++) {
    Sortable.create(uls[i].id,{dropOnEmpty:true, containment:aryContainment, constraint:false});
  }
}
// generate long string of values to return and place in hidden form field dnd_modlist 
function calcLists() {
  var uls = document.getElementsByClassName("dragUL");
  var s = ""; 
  var t = ""; 
  for (var i = 0; i < uls.length; i++) {
    t = Sortable.serialize(uls[i].id);
    if (t != "") {
      if (s != "") { s += "&"}
      s += t;
    }
  }
  document.f.dnd_modlist.value = s;
  return true;
}

// use Sortable functions to reorder a single list alphabetically
function SortOneList(list) {
  sortedlist = Sortable.sequence(list).sort();
  if (sortedlist != "") {
    Sortable.setSequence(list, sortedlist);
  }
}

// sort all drag targets
function SortLists() {
  var uls = document.getElementsByClassName("dragUL");
  for (var i = 0; i < uls.length; i++) {
    SortOneList(uls[i].id);
  }
}

// add a new (empty) column for a new group (rows 1,2,3) and redo target list
function AddGroup() {
	var tblBodyObj = document.getElementById("dragtable").tBodies[0];
  var newgrp = tblBodyObj.rows[1].cells.length - 1;
  var newCell = tblBodyObj.rows[1].insertCell(-1);
  newCell.innerHTML = "<INPUT TYPE=TEXT NAME='Label" + newgrp + "' SIZE=10 VALUE='Group" + newgrp + "'>";
  var newCell = tblBodyObj.rows[2].insertCell(-1);
  newCell.innerHTML = "<INPUT TYPE=TEXT NAME='Text" + newgrp + "' SIZE=16 VALUE='Group" + newgrp + "'>";
  var newCell = tblBodyObj.rows[3].insertCell(-1);
  newCell.innerHTML = "<ul id='grp" + newgrp + "' class='dragUL'></ul>";
  setupdragtargets();
}
