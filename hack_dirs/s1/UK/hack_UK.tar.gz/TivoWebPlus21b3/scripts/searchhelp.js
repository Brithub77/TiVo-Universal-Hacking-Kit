var helptxt = new Array()
helptxt[0] = "Please enter the start of the title<br>The search will match all titles starting with the text entered in \"Search For:\""
helptxt[1] = "Please enter keywords from the title or episode title<br>Append a * to any keyword to match terms starting with that keyword"
helptxt[2] = "Please enter keywords from the description<br>Append a * to any keyword to match terms starting with that keyword"
helptxt[3] = "Please enter keywords from the title, episode title, or description<br>Append a * to any keyword to match terms starting with that keyword"
helptxt[4] = "Please enter the actor's name<br>Use the form \"lastname, first\", \"lastname\" or just the start of the last name"
helptxt[5] = "Please enter the director's name<br>Use the form \"lastname, first\", \"lastname\" or just the start of the last name"

var shelp = (document.getElementById('shelp') || document.all['shelp']);
shelp.innerHTML = helptxt[document.search.searchby.value]
document.search.q.focus()

function searchhelp(x) {
  shelp.innerHTML = helptxt[x];
}

