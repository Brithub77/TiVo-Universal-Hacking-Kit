/* ********************************************************
** KEYTRAP2.JS - JS Key-Detection Library
** =====================================
** A simplified version of Rick Scott and Luan Dang's work.
** Will only work with Mozilla/Explorer based browsers.
******************************************************** */

function Key(code, action) { 
  this.code   = code;
  this.action = action;
}

var Keys = new Array(); // store Key objects in Keys[] array
var Count = 0;          // index into Keys[] 

Keys[Count++] = new Key(37, "reverse");  // Left Arrow
Keys[Count++] = new Key(219, "reverse"); // '['

Keys[Count++] = new Key(39, "forward");  // Right Arrow
Keys[Count++] = new Key(221, "forward"); // ']'

Keys[Count++] = new Key(38, "play"); // Up Arrow
Keys[Count++] = new Key(13, "play"); // Enter

Keys[Count++] = new Key(32, "pause"); // space key
Keys[Count++] = new Key(80, "pause"); // 'p'

Keys[Count++] = new Key(191, "replay"); // '/'
Keys[Count++] = new Key(8, "replay");   // 'backspace'

Keys[Count++] = new Key(40, "catchup"); // Down Arrow
Keys[Count++] = new Key(65, "catchup"); // 'A'

Keys[Count++] = new Key(70, "forward,forward,forward"); // 'F'
Keys[Count++] = new Key(82, "reverse,reverse,reverse"); // 'R'

function keyDown(evt) { 
  var keycode=0;
  if (document.all) {
    var evt=window.event;
    keycode=evt.keyCode;
  } else keycode = evt.which;

  for (var i=0; i<Keys.length; i++) { 
    if (keycode == Keys[i].code) {
      location = Keys[i].action;
      return;
    }
  } 
}

document.onkeydown = keyDown;
