//Issues to not forget:
// id_summary is NOT generic.  Maybe pass it in?


// This function is called when a dropdown box changes
function twp_filter(tableID, filterCol, filterText, summaryID)
{
        var table = document.getElementById(tableID);

        var firstRow = 1;

	// set up a regular expression that will select anything in <> brackets, so they can be ignored
	var re = /<.*?>/gi  

	// first set all rows to be displayed
	for(var i = firstRow; i < table.rows.length; i++) {
		table.rows[i].style.display = "";
	}

	var iRows = i - 1;
	var iShown = iRows;
	
	// Apply or turn off the filter 
	if (filterText != "(all)") {	
  		iShown = 0;
		for(var j = firstRow; j < table.rows.length; j++) {
			var row = table.rows[j];


//			if(row.style.display != "none") {
				var cellText = row.cells[filterCol].innerHTML.replace(re,"").toLowerCase();
				if(filterText != cellText) {
					row.style.display = "none";
				} else {
					iShown++;
				}
//			}
		}
	}
	stripetable(table);

	if (summaryID != "") { 
	        document.getElementById(summaryID).innerHTML = iRows + " Rows Found, " + iShown + " Rows Displayed.<BR>";
	}
}

// This function is called when a date-based dropdown box changes
function twp_filter_lt_date(tableID, filterCol, filterText, summaryID)
{
        var table = document.getElementById(tableID);
        var firstRow = 1;

	// first set all rows to be displayed
	for(var i = firstRow; i < table.rows.length; i++) {
		table.rows[i].style.display = "";
	}

	var iRows = i - 1;
	var iShown = iRows;

	// build comparison date based on selection
	var datCompare = new Date();
	datCompare.setDate(datCompare.getDate() + parseInt(filterText));
	var y = String(datCompare.getYear());
	y = y.substr(y.length-2,2);
        var m = String(datCompare.getMonth() + 1);
        if (m.length == 1) m = '0'+m;
        var d = String(datCompare.getDate());
        if (d.length == 1) d = '0'+d;
	var strCompare = y+m+d;

	// Apply or turn off the filter 
	if (filterText != "(all)") {	
  		iShown = 0;
		for(var j = firstRow; j < table.rows.length; j++) {
			var row = table.rows[j];
//			if(row.style.display != "none") {
				//flip the date to yymmdd for comparison
				var yymmdd = row.cells[filterCol].innerHTML;
				yymmdd = yymmdd.substr(6,2) + yymmdd.substr(0,2) + yymmdd.substr(3,2)
				if(yymmdd < strCompare) {
					row.style.display = "";
					iShown++;
				} else {
					row.style.display = "none";
				}
//			}
		}
	}

	stripetable(table);

	if (summaryID != "") { 
	        document.getElementById(summaryID).innerHTML = iRows + " Rows Found, " + iShown + " Rows Displayed.<BR>";
	}
}

function CheckAllVisible(namePrefix, newValue) {
  var lg = namePrefix.length;
  for (var i=0; i < document.form.elements.length; i++) {
        var c = document.form.elements[i];
        if ((c.type == 'checkbox') && (c.name.substr(0,lg) == namePrefix)) {

	  // only change if row is not hidden (assume row is checkbox's grandpa)
	  if (c.parentNode.parentNode.style.display != "none") {
            c.checked = newValue;
          }
        }
  }
}

// Fills the [selectID] drop-down with values from column [filterCol] in [tableID] 
function twp_populateFilter(selectID, tableID, filterCol)
{

        var table = document.getElementById(tableID);
        var firstRow = 1;

	// set up a regular expression that will select anything in <> brackets, so they can be ignored
	var re = /<.*?>/g

	// set up a regular expression to replace &amp; with & in human-readable list
	var reamp = /&amp;/g

	// Get a reference to the dropdownbox.
	var opt = document.getElementById(selectID);
	

	var values = new Array();
		
	// put all strings in the values array after removing html
	for(var i = firstRow; i < table.rows.length; i++)
	{
		var row = table.rows[i];
		if(row.style.display != "none" && row.className != "noFilter")
		{
			values.push(row.cells[filterCol].innerHTML.replace(re,""));
		}
	}
	values.sort();
	
	//add each unique string to the dropdownbox
	var value;
	for(var i = 0; i < values.length; i++)
	{
		if(values[i] != value)
		{
			value = values[i];
			opt.options.add(new Option(values[i].replace(reamp,"&"), values[i].toLowerCase()));
		}
	}

}

