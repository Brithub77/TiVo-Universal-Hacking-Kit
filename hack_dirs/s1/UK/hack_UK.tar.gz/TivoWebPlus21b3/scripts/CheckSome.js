function CheckSome(x, y) {
  var boxes=document.getElementsByTagName("input")
  var i=0;
  for (; i<boxes.length; i++) {
    if (boxes[i]==y) {break;}
  }
  var l=x.length
  var c= boxes[i++]
  for (; i<boxes.length; i++) {
    c= boxes[i]
    if (c.type != 'checkbox') {continue;}
    if (c.name.substr(0,l)!=x) {break;}
    c.checked=y.checked;
  }
}
