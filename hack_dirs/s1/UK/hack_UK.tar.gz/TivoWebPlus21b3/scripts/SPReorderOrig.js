function compareNumbers(a, b) {
  return a - b;
}

function ReorderPrio(sobj) {
  var oldprio = 0;
  var newprio = sobj.value;
  var numprios = document.form.spcount.value;
  var plist = new Array();
  var j = 0;
  for (var i=0; i < document.form.elements.length; i++) {
    var c = document.form.elements[i];
    if ((c.name.substr(0,5) == 'fsid_') && (c.type == 'select-one')) {
      if (c.name != sobj.name) {
        plist[j] = c.value;
       j++
      }
    }
  }
  plist.sort(compareNumbers);
  for (var i=0; i < plist.length; i++) {
    if (plist[i] != i + 1) {
      oldprio = i + 1;
      break;
    }
  }
  if (oldprio == 0 && plist[i] != numprios) {
    oldprio = numprios;
  }
  plist.push(oldprio);
  plist.sort(compareNumbers);
  var valid = 1;
  for (var i=0; i < numprios - 1; i++) {
    if (plist[i] != i + 1) {
      valid = 0;
    }
  }
  if (valid && oldprio != 0) {
    for (var i=0; i < document.form.elements.length; i++) {
      var c = document.form.elements[i];
      if ((c.name.substr(0,5) == 'fsid_') && (c.type == 'select-one')) {
        if (c.name != sobj.name) {
          var cval = Number(c.value);
          if (newprio < oldprio) {
            if (cval >= newprio && cval <= oldprio) {
              c.value = cval + 1;
            }
          } else {
            if (cval <= newprio && cval >= oldprio) {
              c.value = cval - 1;
            }
          }
        }
      }
    }
  }
}
