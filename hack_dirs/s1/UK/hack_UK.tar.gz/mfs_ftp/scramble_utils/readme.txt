#!/bin/bash
cat readme.txt ; exit
# scrambling issue basics

currently the only format to save/restore scrambled recordings is tmf


Archiving: use mfs_ftp to extract as tmf. be sure to backup the tivo
DiskConfigurationKey (DC_key.xml) with the get_DC_key.tcl utility

Restore: use mfs_ftp or mbm's import.tcl to restore tmf archives

Decryption: it's possible to decrypt a scramble into regular ty either
during extraction or in-place on the tivo. more info soon - in the meantime
back 'em up as tmf & make sure you have a copy of the corresponding
DC_key.xml


Limitations: currently 3 things must match to play or decrypt a scrambled
recording

1) CommercialSkipOffset keys (stored in ty+ or tmf archives)

2) tivo hard drive DiskConfigurationKey

3) tivo motherboard crypto chip

if the DiskConfigurationKey has changed for any reason (re-imaged the drive
- sw update - clear & delete) the correct DiskConfigurationKey (DC_key.xml)
must be restored
