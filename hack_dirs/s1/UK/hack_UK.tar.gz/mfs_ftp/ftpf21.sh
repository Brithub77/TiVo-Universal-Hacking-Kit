mfs_ftp.tcl 21
tail -f port.21.log