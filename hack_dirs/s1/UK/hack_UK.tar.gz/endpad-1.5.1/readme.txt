EndPad
(c) Stuart Anderton, 2005
Version 1.5.1, 14 Mar 2006

Program to add padding at the start and end of every programme if it does not
cause a clash. Padding is added a few minutes before it is needed to minimise
the possibility of clashes being caused by the padding. It runs in the
background, 24/7.

This code may be distributed freely so long as this header is not changed
and no-one gets charged for it. Distribution on disks or ISOs sold on eBay or
elsewhere is specifically prohibited.

EndPad is free, but next time its saves you a verbal beating thanks
to a caught ending that would otherwise be missed, why not consider an
appropriate donation to CLIC, the children's leukeamia charity. I believe
in America the Pediatric Cancer Research Foundation does similar work.

  http://www.clic.org.uk/
  http://www.pcrf-kids.com/


INSTALLATION AND EXAMPLE USAGE
==============================

Copy endpad.tcl to the TiVo using binary-mode FTP. Then:

  chmod 755 endpad.tcl

It can be run with, eg.,

  ./endpad.tcl -e 10

In this case, EndPad will try to add 10 minutes padding to the end of all
programmes, but only if this does not cause a clash with another scheduled
recording.

Stop with:

  ./endpad.tcl -stop

To start EndPad every time the TiVo starts up, add the following line
to /etc/rc.d/rc.sysinit.author:-

  /var/hack/endpad.tcl -e 10 -auto >> /dev/null &


USAGE DETAILS
=============

EndPad can be started with any of the following options:-

  endpad.tcl -s X -e Y -n W -f Q -sugqual Z -sugeq -config F -tz T -auto -debug

or stopped with

  endpad.tcl -stop

All arguments are optional:-

  -s X        Start padding X minutes
  -e Y        End padding Y minutes
  -n W        Negative start padding W minutes
  -f Q        Q=0 or 1. If 1, force negative padding even if no channel change
  -sugqual Z  Force suggestions to quality Z (0, 40, 75, or 100)
  -sugeq      Do not cancel suggestions to pad other suggestions
  -config F   Read detailed settings from file F (default=endpad.config)
  -tz T       Timezone (+/-hours) for config and displayed times (default=00:00)
  -auto       Use if run from startup script (otherwise stops previous EndPad)
  -debug      Don't put in background and print messages to screen
  -stop       Stop existing endpad.tcl process
  -help       Display help message


CONFIGURATION FILE
==================

The optional endpad.config file can be used to specify most of the command-line
options, as well as specifying channel, time, or programme-specific settings.
The default file does nothing (it's all just comments). A different file
location can be specified with the -config option.

Each endpad.config line contains one or more of the following keywords:-

  timezone hh:mm   Set the timezone (don't use this on ozTiVo)
  channel N   This line's settings apply to channel N only.
  validity hh:mm-hh:mm   This line's settings only apply if the programme's
              start time is within the specified interval. The times can be
              specified as hh, hh:mm, or hh:mm:ss and may be limited to one
              day of the week with Day/hh:mm etc. Note that the interval
              can wrap around midnight.
  program P   This line's settings apply if the name of the program matches
              the supplied pattern, P (may be quoted using {} or "").
  programme P As above, but with British spelling!
  startpad X  Start padding X minutes
  endpad Y    End padding Y minutes
  negpad W    Start the following program late to allow W minutes endpad
  maxneg M    Maximum late starting for matching program is M minutes
  sugqual Z   The recording quality for suggested recordings
              Basic = 0, Medium = 40, High = 75, Best = 100, default = -1
  sugeq       Padding of suggestions on this channel does not cause subsequent
              suggestions on other channels to be cancelled.

Keywords can be abbreviated as follows: c(hannel), p(rogram), v(alidity),
s(tartpad), e(ndpad), n(egpad), m(axneg), tz (timezone)
Keywords may optionally be preceded by "-". Comments start with "#".

Example (UK):
  startpad 1 endpad 3                    # global default (same as -s 1 -e 3)
  channel BBC1STH,BBC2STH,BBC4 endpad 15 # override endpad for the BBC
  channel C4 validity 18-5 endpad 10     # endpad for 6pm to 5am on Channel 4
  programme Buffy endpad 20              # endpad for Buffy the Vampire Slayer
  validity Sat/19:30-05:00 endpad 20     # Saturday 7:30pm to Sunday 5am

Example (Oz):
  startpad 1 endpad 10  # Global defaults
# Hi-5 is almost always on time, and I don't want my child watching next prog
  channel Nine-Mel program {Hi-5} -s 0 -e 0
# Temptation always runs over, see the end rather than start of the next prog
  channel Nine-Mel program {^Temptation$} negpad 4
# Never take off start of any CSI program
  channel Nine-Mel program CSI maxneg 0


CREDITS
=======

See changes.txt for details of recent changes to EndPad.


EndPad was created by Stuart Anderton

Thanks to Dibblah and ccwf for suggestions and refinements

Log rotation code courtesy of LJ

Subs quality change code by Milhouse

Config file, channel-specific, time-dependent settings, additional
documentation, and other changes by maxwells_daemon.

Title matching, auto reload, negpad integration by tym, using manual recording
code adapated from manrec.itcl 0.2.0 by Christopher R. Wingert

Portions adapted from code published on the O'Reilly site from "TiVo Hacks"

Other bits based on noreddot.tcl by LJ, as well as the TivoWeb code


SUPPORT
=======

Questions, suggestions, and bug reports to the TiVo UK Forum on
www.tivocommunity.com:

  http://www.tivocommunity.com/tivo-vb/showthread.php?t=286631
