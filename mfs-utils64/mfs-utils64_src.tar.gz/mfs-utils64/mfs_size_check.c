/*
  media-filesystem diagnostic utility
  tridge@samba.org, January 2001
  released under the Gnu GPL v2
*/

#include "mfs.h"

#include <assert.h>

static char *prog="";
static void usage(void)
{
	fprintf(stderr,"\n\
usage: %s [options] [<path|fsid>]\n\
\n\
   options:\n\
", prog );
	credits();
	exit(1);
}

/*
  +  * Find actual size of a recording
  +  * For series 3 systems we count based on the # of recorded chunks in
  +  * an FSID.
  +  * For older tivo systems, we count based on the # of allocated chunks.
  +  */
#define MASTER_HEADER_PEEK_LEN 16
#define MFS_S1S2_OBJTYPE	2	/* "MFS_FILE_STREAM" */
#define MFS_S3_OBJTYPE		3
#define MASTER_CHUNK_MAGIC 0xf5467abd	/* master chunk at start of each
 					   FSID of an unscrambled recording */
 typedef struct {
     u32 magic;
     u32 objtype;
     u32 chunksize;
     u32 chunkcnt;
 } ty_master_hdr_t;
 
 u64 mfs_fsid_recsize(int fsid)
 {
     ty_master_hdr_t master;
     u32 chunkcnt;
     u64 allocsize;
 
     allocsize = mfs_fsid_size(fsid);
     mfs_fsid_pread(fsid, &master, 0, sizeof(master));
     byte_swap(&master, "i4");
     if (master.magic != MASTER_CHUNK_MAGIC) {
	     return 0;
     }
     switch (master.objtype) {
     default:
 	return allocsize;
     case MFS_S1S2_OBJTYPE:
     case MFS_S3_OBJTYPE:
 	break;
     }
     chunkcnt = master.chunkcnt - 4;
     chunkcnt /= 256;
     /* Convert from chunk count to bytes */
     return ((u64)chunkcnt) << 17;
}
 
void check_inode_fn(struct mfs_inode *inode, void *data)
{
	u64 asize, usize, rsize;

	if (inode->type != MFS_TYPE_STREAM) return;
	asize = mfs_fsid_size(inode->id);

	switch (inode->used_units) {
	case 0: usize=inode->used_size; break;
	case 0x20000: usize=((u64)inode->used_size) << 17; break;
	default: fprintf( stderr, "unexpected used_units in fsid %d: %d\n",
			  inode->id, inode->used_units );
		usize = 0;
	}
	
	rsize = mfs_fsid_recsize(inode->id);
	if (usize != rsize)
		printf( "%8d\t%8lld\t%8lld\t%8lld\n", inode->id, 
			asize, usize, rsize  );
}

static void stream_scan()
{
	// Walk through ALL fsid's and note the sizes of tyStream fsids.
	mfs_all_inodes( check_inode_fn, (void *)0 );
}


int main(int argc, char *argv[])
{
	int c;

	while ((c = getopt(argc, argv, "hfsT::")) != -1 ){
		switch (c) {
		case 'h':
			usage();
			break;
		}
	}

	argc -= optind;
	argv += optind;

	mfs_init();
	stream_scan();
	return 0;
}
