/*
  media-filesystem diagnostic utility
  tridge@samba.org, January 2001
  released under the Gnu GPL v2
*/

#include "mfs.h"
#include <stdio.h>
#include <assert.h>

int main(int argc, char *argv[])
{
	mfs_init();
	while (--argc > 0) {
		struct mfs_inode inode;
		u32 fsid = mfs_resolve(*++argv);
		mfs_load_inode(fsid, &inode);
		printf( "%s\n", mfs_type_string(inode.type) );
	}
	return 0;
}
