#include <stdio.h>

void credits(void)
{
	fprintf(stderr, "\n\
Released under the Gnu GPL v2\n\
Original mfs_* package by tridge at samba.org, January 2001\n\
Modifications by:\n\
	adh, jamie, jbuehl, jdiner, jonbig, mbm, musclenerd, ppchacker\n\
	Daniel Gimpelevich (aka sn9), maxwells_daemon, JB6783, vandebo,\n\
        and possibly others...\n\
\n\
	A support thread is in the forums at dealdatabase.com\n\
");
}
