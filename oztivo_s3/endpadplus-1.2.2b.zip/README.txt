EndPadPlus * for all your padding needs
==========================================

   Adds padding at the start and end of every program as long as it does not
 conflict with another recording.

   This script was derived from sanderton's EndPad 1.3.3. The most notable
 improvement is the addition of dual tuner support. Other refinements
 include modularization of code, improved command line handling, improved
 and verbose logging, suggestion equalization, and more.

   Thanks to sanderton for allowing me to start from his existing code and
 to splitsec for helping during the debugging process. Some thanks from the
 original EndPad include Dibblah and ccwf for suggestions and refinements and
 LJ for log rotation code. Additionally, some portions of the new code were
 based upon code taken from TivoWebPlus, which is a collaborative effort.

 Latest release: 1.2.2b
 Release timestamp: February 8, 2009 @ 2:50pm CST

=======================================
Latest improvements/fixes:
-- fixed minor bug (for some TiVos) introduced in 1.2.2a (falcontx)

=======================================
Features:
 -- user-defined start and end padding
 -- dual tuner support
 -- optional suggestion equalization
 -- optional back-to-back exemption

Compatibility:
 -- All series
 -- All models
 -- All software versions

=======================================
Basic Installation:

 Copy to the TiVo and make executable with following command:

     chmod 755 endpadplus.tcl

 Run with:

    endpadplus.tcl s e [options]
      s = the number of minutes of start padding to add
      e = the number of end padding to add

      options:
        -seq         suggestion equalization
                       (padding a suggestion will not delete another suggestion)
	-shd         record only HD suggestions
        -nob2b       back-to-back exemption
                       (second tuner will not be used to add padding to
	                back-to-back recordings on the same channel)
        -noverbose   less detail in logs
        -auto        silent start (use when starting from a script)

 Stop with:

     endpadplus.tcl -stop 

 Run from rc.sysinit.author with the auto flag:

     endpadplus.tcl s e -auto &

=======================================

 Please see the following thread for the most up to date information:
 http://www.dealdatabase.com/forum/showthread.php?t=31854