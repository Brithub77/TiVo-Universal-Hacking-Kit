#!/bin/bash
cat readme.txt ; exit
################################################################################
# mfs_ftp - Copyright (C) 2001-2003  Riley Cassel<RC3105@dealdatabase.net>
# This is a basic tivo ftp server to backup & restore recordings.
# TERMS OF USE: personal (noncommercial) fair-use backup & restore
# This software may not be used for copywright infringment or any illegal
# purpose, bundled with any product, sold, distributed or redistributed
# under any circumstances on any media without express written consent.
################################################################################

this server is VIDEO ONLY and has NO security.

I REPEAT - VIDEO ONLY & NO SECURITY.

this dynamically maps recordings stored in mfs onto virtual files.  
the directory chosen determins the extraction format.  during
insertion the recording archive is parsed & the pieces are stored
appropriatly.  extended recording info is available as txt or xml
formatted text.  supported formats are tmf, ty+ or ty

this util is intended for use on a private network.  tcp being what
it is, if your tivo has broadband access ANYONE can diddle your
recordings.  it's a VERY bad idea to expose the tivo to the net since
even a simple portscan will crash it.  if the daily call runs via
nat/firewall/router please be VERY sure it's setup properly.

this server supports 1 data channel transfer at a time.  control channels are
simply telnet connections and "EXIT" or "exit" on the control channel shuts
down the program entirely.  ABOR is not implemented yet but simply closing
the connection(s) & opening another works fine.  if the data channel is
closed/lost prematurely during transfer the associated control channel may
hang.  In any case, simply close the control connection, start another &
all is well.

the default ftp port is 3105.  the usage "mfs_ftp.tcl xx" sets an alternate
portnum.  multiple control connections are supported but only 1 data channel.
if your ftp client or download accelerator does multi-threaded transfers
that feature must be disabled.  activity is logged to
/var/mfs_ftp/port.port#.log (i.e. /var/mfs_ftp/port.3105.log)

passive transfers run slowly due to a tivo tcp bug.  generally passive
mode is only required when there are firewall issues.

to simplify archiving, recording names are formatted this way
{Title}{OriginalAirDate}{Episode}{Time&DateRecorded}{chan_callsign}.filetype

################################################################################

What's New:

program location:

mfs_ftp will auto-detect it's own directory & should run from any accessable 
filesystem as long as it's rw accessable


settings file:

the first few lines of mfs_ftp.tcl contain the defaults that determine
program operation.  the file "settings.tcl" contains the same settings
and is sourced at startup or phoenix.  the defaults should work for
everyone, edit settings.tcl to suit your preference

filename options:  info(name_detail)  - range 0-5, default 5
0 = "fsid"
1 = "fsid - Title - EpisodeTitle"
2 = "{Title}{EpisodeTitle}"
3 = "{Title}{EpisodeTitle}{CallSign}"
4 = "{Title}{originalairdate}{EpisodeTitle}{}{CallSign}"
5 = "{Title}{originalairdate}{EpisodeTitle}{rec_time&date}{CallSign}"
6 = "{Title}{originalairdate}{EpisodeTitle}{rec_time&date}{CallSign}{fsid}"
X = "{Title}{EpisodeTitle}"

the X option, as in Xbox, trims filenames to 42 chars so they can
be stored in a fatx partion.  if there is no EpisodeTitle then the
original air + recorded dates are substituted

for you cmd line fanatics I've enabled retrieval by recobject fsid.
"get 12345.tmf" or "get 12345.ty" will retrieve the entire recording.
the number needs to be the fsid# for the recording object itself, not of
any individual part.  (think filename options 0 & 1)

info(dbl):  sets the level of logging, range is 0 (least) to 5 (everything)

info(saveuntil):  determines how a recording is stored.  options are
suggestion (expires in a week) & delete (save until I delete)

info(multithreaded):  0 by default, 1 forks a new copy whenver a 
transfer is initiated.  if you don't see why that might be usefull 
don't worry about it

info(bjuggle): 0 by default, 1 enables the streamview "shuffle".  still
in development.  try it or not, whichever

info(active): changes the mfs path to /Recording/Active  this lets you see
deleted recodings & undelete anything that hasn't been overwritten
yet.  don't use this if you have lots of drive space or many MANY small
recordings since more than about 350 NowPlaying items begins to cause
problems (if you have lots of swap space give it a try)

info(ac_interval): sets the abortcheck pingpong delay (in seconds)

resume(e): 0/1, default 0 (disabled). enables resume for ty extracts
resume requires a fifo in mfs_ftp's working directory


New filetypes:

asx: contains the tivo ip + recording object id & will auto launch
windows media player.  if you have d7o's windows directshow filter 
installed and vserver running in the tivo you can stream the recording 
directly off the tivo to windows media player
http://www.dealdatabase.com/forum/showthread.php?s=&threadid=27399

bat files: also contain the tivo ip + recobj id.  if cygwin mplayer
is in your path these will streamview directly off the tivo
http://www.dealdatabase.com/forum/showthread.php?s=&threadid=22972

(note - either type of asx/bat link can be parsed by an associated 
script under MacOS-X or linux to launch mplayer.  if you're a *nix 
head writing that script should be a snap)


space issues: if needed mfs_ftp will reclaim space from deleted-but-
recoverable recordings.  if there aren't any it'll delete suggestions
as necesary.  it will NOT delete anything besides a suggestion.  if the 
tivo is truly full it will abort the transfer & put this msg into the log

"unable to allocate space for recording, you MUST delete something from 
Now Playing"

this is normal tivoapp behavior, when you tell it to record something it 
makes room if possible.  while insertion isn't strictly recording it's
the same deal - you told it to put a show in NowPlaying.  if it was
allready full something had to go to make room.


other issues:

abortcheck pingpongs every 15 minutes & updates the cached recording info
every 30 mins.  this minimal activity doesn't eat cpu time or interfere
with recording.  basically it's a not-quite-braindead coma good for
maintaining the xml & pts stored in /var/mfs_ftp/cache.  those files
allow you to retrieve recordings by connecting the drive to a pc like so
http://www.dealdatabase.com/forum/showthread.php?s=&threadid=23192
this can be a lifesaver if the drive goes unrecoverable GSOD but still
works.  if you're recovering scrambled recordings you'll also need
/var/mfs_ftp/DC_key.xml & the utility to restore it from
http://alt.org/forum/index.php?t=getfile&id=126&rid=24

scrambled recordings can only be extracted/restored as tmf, can
only be restored to the same tivo for later viewing, and the
DiskConfiguratin keys must correct.  see this thread for details
http://www.dealdatabase.com/forum/showthread.php?s=&postid=107356

scrambled tmf CANNOT be watched until insertion is complete.  attempting to
streamview a scramble will reboot the tivo.

################################################################################

Easy Install:  requires a working copy of tar in your path

shutdown any previous version of mfs_ftp running in the tivo

unzip mfs_ftp.tar.zip to mfs_ftp.tar on your pc

open mfs_ftp.tar & extract readme.txt - READ IT!

transfer mfs_ftp.tar to /var in the tivo

backup the old mfs_ftp dir: "mv /var/mfs_ftp /var/mfs_ftp.bak"

unpack "tar -xvf /var/mfs_ftp.tar"

start from bash "/var/mfs_ftp/mfs_ftp.tcl" or load from a startup script

enjoy

################################################################################

Detailed Installation Instructions:

tar should put everything where it needs to go, if you're curious or 
hardheaded here's the long way 'round

make sure you have the current version of all files from post #1 of
http://www.dealdatabase.com/forum/showthread.php?s=&threadid=21915

make sure the directories /var/mfs_ftp & /var/mfs_ftp/cache exist with this
command "mkdir /var/mfs_ftp/cache"

put mfs_ftp.tcl.gz and the support files, mfs_tarstream, mfs_stdinsert,
mfs_stream, mfs_export, setpri and tzoffset.tcl.tgz into /var/mfs_ftp/

unzip mfs_ftp.xxx.tcl.gz with "gzip -d mfs_ftp.tcl.gz"
rename it with "mv mfs_ftp.xxx.tcl mfs_ftp.tcl"

unzip tzoffset.tcl.gz with "gzip -d tzoffset.tcl.gz"

make everything executable with "chmod +x /var/mfs_ftp/*"

start mfs_ftp from bash or rc.sysinit like this
"/var/mfs_ftp/mfs_ftp.tcl &" or "/var/mfs_ftp/mfs_ftp.tcl port# &"

mfs_ftp will automatically background itself, commands & status msgs are 
echoed to /var/mfs_ftp/port.port#.log

for performance throttling an executable copy of mbm's setpri should exist 
in /var/mfs_ftp

"tail -f port.port#.log" can be used from bash to watch the log as it grows

for each recording xml and parts data is cached to
/var/mfs_ftp/cache/recording_filename.xml
/var/mfs_ftp/cache/recording_filename.pts
this allows you to extract easily with the drive mounted in a pc

################################################################################

support file info:

mfs_stdinsert	inserts video data into the mfs partition

mfs_stream	streams video data from mfs to ty or ty+ files

mfs_tarstream	streams video data from mfs to tmf files

tzoffset.tcl	retrieves the time zone offset & caches it in 
		/var/mfs_ftp/tzoffset.txt

mfs_export	used when resuming interrupted extracts

################################################################################

abortcheck "heartbeat"

if you kill a tivosh script that accesses the mfs db it forces a reboot.  
mfs_ftp has a ping_pong "heartbeat" that shuts down the program if 
/var/mfs_ftp/abort.txt exists.  the default interval is 15 mins.  abortcheck 
is also called whenever a new control channel is opened.  if abort.txt exists 
& mfs_ftp does not shutdown in 15 minutes, tivosh has become unstable and 
the tivo should be rebooted anyway (as soon as is convenient)

################################################################################

directories & export formats.

tmf	best format for archiving or sharing

ty	a regular mfs_stream .ty file with this text appended to the end 
	"512*#, xml, 512*#" tystudio/tytool/mplayer can open/process these. 
	the xml allows them to be inserted & is availaible for dvd
	authoring utils.  there's normally junk at the end of tyfiles 
	anyway so the #xml# appended to the end will NOT affect conversion

ty+	same as ty, just given the ty+ suffix.  usefull for housekeeping if
	you extract ty with other utils that don't include the xml

xml 	the nowshowing info for a recording as an xml formatted text file.
	generally about 5k.

txt	a plain text file that lets you browse recording descriptions.
	also includes the xml and ip/gateway address of the tivo

shutdown 	trying to dl this file shuts down mfs_ftp

pheonix 	mfs_ftp shuts down but spawns a copy on the same port
		caches are refreshed

################################################################################

by editing the mfs_ftp.tcl file you can change some program settings

DON'T ATTEMPT THIS IF YOU DON'T KNOW WHAT YOU'RE DOING USING JOE OR VI!!!

info(ithrottle) the range is -1 to 10 and the defaults are 0

-1 == direct fcopy, no throttle whatsoever.  not reccomended but possible
0 == segmented transfers of 1 chunk (128k) at a time with 0 ms delay between
chunks.  each throttle increment adds 10 milliseconds delay.  most graphical 
ftp cliets have a maximum transfer rate setting so if you need to throttle
pc -> tivo transfers I suggest changing that setting instead

this setting applies to ALL inserts so it's more usefull for tuning fxp
speeds.  tivo <-> tivo transfers are usually limited by the tcp passive bug,
but if insert interferes with menu responsiveness increase info(ithrottle)

 
info(insert_priority) range is 1 to 99.  lets you adjust the insert 
process priority.  tweak this if needed to accelerate inserts.  only 
available if an executable copy of setpri (or symbolic link to one)
exists in /var/mfs_ftp


tmf's can be streamviewed from start to finish as they're inserted with
only a minor playback glitch at each fsid boundry.  the tivo will jump
into the nowplaying list for a few seconds then continue normally.  this
ONLY occurs when watching an insert as it's transferring and does not
interfere with background recording.  enable by changing
"set info(bjuggle) 0" to "set info(bjuggle) 1"
this feature currently relies on /tmf/mwstate. tivo sw 2.x
has a mwstate bug that can be fixed with these steps
http://www.dealdatabase.com/forum/showthread.php?s=&threadid=27366


changing "set info(multithreaded) 0" to "set info(multithreaded) 1" will
phoenix a new copy of mfs_ftp whenever an insert or extract is started.
the copy that the transfer was initiated under will complete the transfer
then exit, the new copy will run normally.  this allows for multiple
transfers but can drastically slow things down.


set info(path) "/var/mfs_ftp"  selects the location for mfs_ftp & it's 
files/directories


set info(gatewayip) "127.0.0.1" & set info(gatewayport) "3105"
these change the info included in the txt files.  with a properly
configured router you could e-mail these txt files and use them as
link for remote access (if that's greek to you don't even worry 'bout it)

################################################################################

Client Software:

smart_ftp	has a good interface & can coordinate / initiate direct 
		fxp (tivo-tivo) transfers.

WS_FTP		works ok.  I don't care for the interface but oh well

fetch		fetch 2.x & 3.x work here from mac os 7-10

filezilla	fast & free but no fxp

if you find something that works better / faster please let us know. 

################################################################################

How to transfer a show directly from one tivo to another:

this is how it works with w98/smartftp 1.0.  other platforms / clients will
differ but figuring them out it up to you.  this is just what I generally use

open a connection to each tivo & drag a .tmf from one remote file list window
to the other

you can hit play as soon as the recording appears in the recieving tivo 
nowshowing list (about 10-15 seconds) and watch it as it streams across.

transfers between tivonet/dtivos here generally run about 900k/sec.  ymmv.
the speed of the pc running smart-ftp makes NO difference since fxp transfers
are DIRECT and the pc just initiates the transfer

################################################################################

misc notes:

s2 issues.  don't have one so I can't support them.  see the dd thread
http://www.dealdatabase.com/forum/showthread.php?s=&threadid=29459
for s2 issues (binaries, info, etc)

sw versions.  I have 1.x - 3.x S1 SA & dtivos.  mfs_ftp supports 2.x & 3.x

this simplifies achiving & restore of recordings as well as scheduled batch 
extraction via scripts that invoke cmd line ftp

tmf recordings from mfs_ftp are nearly identical to those produced by
tivodvlpr's tivoweb-tarserver (the xml format has evolved a smidgen) ty's
are regular old mfs_stream streams with 512 #'s, the xml txt and another
512 #'s appended to the end. this DOES NOT interfere with conversion to
mpeg and the xml is available for building tmf files or automatic
indexing / sorting of archived recordings

on insert only some xml data is restored into the newly created recording. 
just what's critical (title / date /etc).  the full xml text is stored
in the mfs_ftp/cache dir & retrieved on extraction though so you get back
the same tmf or ty+ that went in

recordings from 2.x & 3.x sw can be interchanged between 2.x & 3.x tivos

################################################################################

direct bug-reports / questions / requests to:

http://www.dealdatabase.com/forum/showthread.php?s=&threadid=21915

################################################################################

credits:	including code, utilizing binaries from or based on works by

Tridge		the promethius of the tivo-verse

TivoDvlpr 	portions of the tytar server, mfs_tarstream, mfs_import

MBM		the tcl xml dumper routine & general info/help on many aspects

Alphawolf	the bee in our collective bonnet that got insertion going

Olaf		inspired me to share this with the rest of the world

dtype		pre-built tivo X-compiler runs great under RH, BIG timesaver

digitalair	pre-built tivo native compiler, also very handy

inubus		kernel guru with the patience of a saint

tivoweb-peeps	mapped out tons of info making this possible w/o losing 
		what's left of my mind...

thanks to everyone contributing info & code to develpment on alt.org & irc

################################################################################

mfs_ftp - Copyright (C) 2001-2003  Riley Cassel <RC3105@dealdatabase.net>

################################################################################

still reading?  wow, such determination...

feel free to poke through & see how things work.  if you want to tweak 
please do it via patches that redefine procedures. (p1.tcl, p2.tcl & 
p3.tcl will load automatically if found) that makes troubleshooting SO much
easier

the restrictive licence is the result of a headache from lots of variations 
& bad howto's posted on dd.  I'm a firm believer in GPL, but not in cleaning
up somebody else's mess

suggestions, patches & constructive criticism are welcome