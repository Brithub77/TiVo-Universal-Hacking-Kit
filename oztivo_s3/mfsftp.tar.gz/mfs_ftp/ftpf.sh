mfs_ftp.tcl
tail -f port.3105.log