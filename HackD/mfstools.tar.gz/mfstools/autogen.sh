#!/bin/sh

autoreconf -vfi
